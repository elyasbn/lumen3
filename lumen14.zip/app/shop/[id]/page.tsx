"use client"

import { useState } from "react"
import { ArrowLeft, Star, Heart, ShoppingCart, Share2, Minus, Plus, Truck, Shield, RotateCcw } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import Image from "next/image"
import Link from "next/link"

// Mock product data - in a real app, this would come from a database or API
const getProductData = (id: string) => {
  const products = {
    "professional-dance-mat": {
      id: "professional-dance-mat",
      name: "Professional Dance Mat",
      brand: "DanceFloor Pro",
      productCode: "DFP-MAT-001",
      price: 89.99,
      originalPrice: 119.99,
      rating: 4.8,
      reviewCount: 124,
      images: [
        "/placeholder.svg?height=600&width=600",
        "/placeholder.svg?height=600&width=600",
        "/placeholder.svg?height=600&width=600",
        "/placeholder.svg?height=600&width=600",
      ],
      colors: [
        { name: "Black", value: "#000000" },
        { name: "Gray", value: "#808080" },
        { name: "Blue", value: "#0066CC" },
      ],
      sizes: ["Small (4x4 ft)", "Medium (6x6 ft)", "Large (8x8 ft)"],
      inStock: true,
      stockCount: 15,
      description:
        "Professional-grade dance mat designed for serious dancers and studios. Features non-slip surface, shock absorption, and easy portability.",
      features: [
        "Non-slip surface for maximum safety",
        "Shock-absorbing foam core",
        "Easy to clean and maintain",
        "Portable and lightweight design",
        "Professional studio quality",
      ],
      specifications: {
        Material: "High-density foam with vinyl surface",
        Thickness: "1.5 inches",
        Weight: "12-25 lbs (depending on size)",
        Care: "Wipe clean with damp cloth",
        Warranty: "2 years manufacturer warranty",
      },
      reviews: [
        {
          name: "Sarah M.",
          rating: 5,
          date: "2 weeks ago",
          comment:
            "Amazing quality! Perfect for my home dance practice. The grip is excellent and it's very comfortable.",
        },
        {
          name: "Dance Studio Pro",
          rating: 5,
          date: "1 month ago",
          comment:
            "We bought 6 of these for our studio. Students love them and they're holding up great with heavy use.",
        },
        {
          name: "Jennifer K.",
          rating: 4,
          date: "2 months ago",
          comment: "Great mat, very professional quality. Only wish it came in more color options.",
        },
      ],
      relatedProducts: ["ballet-shoes-professional", "yoga-mat-premium", "resistance-bands-set"],
      perfectFor: ["Ballet classes", "Contemporary dance", "Home practice", "Studio use"],
    },
    "ballet-costume-set": {
      id: "ballet-costume-set",
      name: "Ballet Dance Costume Set",
      brand: "Elegance Dancewear",
      productCode: "ED-BALLET-SET-001",
      price: 159.99,
      rating: 4.9,
      reviewCount: 89,
      images: [
        "/placeholder.svg?height=600&width=600",
        "/placeholder.svg?height=600&width=600",
        "/placeholder.svg?height=600&width=600",
      ],
      colors: [
        { name: "Pink", value: "#FFB6C1" },
        { name: "White", value: "#FFFFFF" },
        { name: "Black", value: "#000000" },
      ],
      sizes: ["XS", "S", "M", "L", "XL"],
      inStock: true,
      stockCount: 8,
      description:
        "Complete ballet costume set including tutu, leotard, and matching accessories. Perfect for performances and recitals.",
      features: [
        "Professional-grade tutu with multiple layers",
        "Comfortable stretch leotard",
        "Matching hair accessories included",
        "Available in classic colors",
        "Suitable for performances and recitals",
      ],
      specifications: {
        Material: "Polyester tulle and spandex blend",
        Includes: "Tutu, leotard, hair bow, arm bands",
        Care: "Hand wash cold, air dry",
        Fit: "True to size with stretch",
        "Age Range": "Suitable for ages 8-18",
      },
      reviews: [
        {
          name: "Ballet Mom",
          rating: 5,
          date: "1 week ago",
          comment: "Beautiful costume! My daughter looked amazing in her recital. Quality is excellent.",
        },
        {
          name: "Dance Teacher",
          rating: 5,
          date: "3 weeks ago",
          comment: "Ordered multiple sets for our studio. Great quality and the kids love them!",
        },
      ],
      relatedProducts: ["ballet-shoes-professional", "dance-hair-accessories"],
      perfectFor: ["Ballet recitals", "Performances", "Competitions", "Photo shoots"],
    },
  }

  return products[id as keyof typeof products] || null
}

const relatedProductsData = {
  "ballet-shoes-professional": {
    name: "Ballet Shoes - Professional",
    price: 79.99,
    image: "/placeholder.svg?height=200&width=200",
  },
  "yoga-mat-premium": {
    name: "Premium Yoga Mat",
    price: 69.99,
    image: "/placeholder.svg?height=200&width=200",
  },
  "resistance-bands-set": {
    name: "Resistance Bands Set",
    price: 29.99,
    image: "/placeholder.svg?height=200&width=200",
  },
  "dance-hair-accessories": {
    name: "Dance Hair Accessories Kit",
    price: 34.99,
    image: "/placeholder.svg?height=200&width=200",
  },
}

export default function ProductPage({ params }: { params: { id: string } }) {
  const product = getProductData(params.id)
  const [selectedImage, setSelectedImage] = useState(0)
  const [selectedColor, setSelectedColor] = useState("")
  const [selectedSize, setSelectedSize] = useState("")
  const [quantity, setQuantity] = useState(1)
  const [activeTab, setActiveTab] = useState("description")

  if (!product) {
    return (
      <div className="min-h-screen bg-white">
        <Header />
        <div className="container mx-auto px-4 py-20 text-center">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Product Not Found</h1>
          <p className="text-xl text-gray-600 mb-8">The product you're looking for doesn't exist.</p>
          <Link href="/shop">
            <Button className="bg-[#949f7d] hover:bg-[#949f7d]/90 text-white">Back to Shop</Button>
          </Link>
        </div>
        <Footer />
      </div>
    )
  }

  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }, (_, i) => (
      <Star
        key={i}
        className={`w-5 h-5 ${i < Math.floor(rating) ? "fill-yellow-400 text-yellow-400" : "text-gray-300"}`}
      />
    ))
  }

  const relatedProducts = product.relatedProducts.map((id) => ({
    id,
    ...relatedProductsData[id as keyof typeof relatedProductsData],
  }))

  return (
    <div className="min-h-screen bg-white">
      <Header />

      {/* Breadcrumb */}
      <section className="py-4 bg-gray-50">
        <div className="container mx-auto px-4">
          <nav className="text-sm text-gray-600">
            <Link href="/" className="hover:text-[#949f7d] transition-colors">
              Home
            </Link>
            <span className="mx-2">&gt;</span>
            <Link href="/shop" className="hover:text-[#949f7d] transition-colors">
              Shop
            </Link>
            <span className="mx-2">&gt;</span>
            <span className="text-[#949f7d]">{product.name}</span>
          </nav>
        </div>
      </section>

      {/* Back Button */}
      <section className="py-4">
        <div className="container mx-auto px-4">
          <Link href="/shop">
            <Button
              variant="outline"
              size="sm"
              className="border-[#949f7d] text-[#949f7d] hover:bg-[#949f7d] hover:text-white bg-transparent"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Shop
            </Button>
          </Link>
        </div>
      </section>

      {/* Product Details */}
      <section className="py-8">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Product Images */}
            <div className="space-y-4">
              <div className="relative overflow-hidden rounded-lg bg-gray-100">
                <Image
                  src={product.images[selectedImage] || "/placeholder.svg"}
                  alt={product.name}
                  width={600}
                  height={600}
                  className="w-full h-auto object-cover"
                  priority
                />
              </div>

              <div className="grid grid-cols-4 gap-4">
                {product.images.map((image, index) => (
                  <button
                    key={index}
                    onClick={() => setSelectedImage(index)}
                    className={`relative overflow-hidden rounded-lg border-2 transition-colors ${
                      selectedImage === index ? "border-[#949f7d]" : "border-gray-200 hover:border-gray-300"
                    }`}
                  >
                    <Image
                      src={image || "/placeholder.svg"}
                      alt={`${product.name} ${index + 1}`}
                      width={150}
                      height={150}
                      className="w-full h-24 object-cover"
                    />
                  </button>
                ))}
              </div>
            </div>

            {/* Product Info */}
            <div className="space-y-6">
              <div>
                <p className="text-sm text-gray-500 mb-2">
                  {product.brand} • {product.productCode}
                </p>
                <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">{product.name}</h1>

                <div className="flex items-center space-x-4 mb-4">
                  <div className="flex items-center space-x-1">
                    {renderStars(product.rating)}
                    <span className="text-sm text-gray-600 ml-2">
                      {product.rating} ({product.reviewCount} reviews)
                    </span>
                  </div>
                </div>

                <div className="flex items-center space-x-3 mb-6">
                  <span className="text-3xl font-bold text-[#949f7d]">${product.price}</span>
                  {product.originalPrice && (
                    <span className="text-xl text-gray-500 line-through">${product.originalPrice}</span>
                  )}
                  {product.originalPrice && (
                    <span className="bg-red-100 text-red-800 px-2 py-1 rounded-full text-sm font-medium">
                      Save ${(product.originalPrice - product.price).toFixed(2)}
                    </span>
                  )}
                </div>

                <p className="text-gray-600 leading-relaxed">{product.description}</p>
              </div>

              {/* Color Selection */}
              {product.colors && product.colors.length > 0 && (
                <div>
                  <h3 className="font-medium text-gray-900 mb-3">Color: {selectedColor}</h3>
                  <div className="flex space-x-3">
                    {product.colors.map((color) => (
                      <button
                        key={color.name}
                        onClick={() => setSelectedColor(color.name)}
                        className={`w-10 h-10 rounded-full border-2 transition-colors ${
                          selectedColor === color.name ? "border-[#949f7d] ring-2 ring-[#949f7d]/20" : "border-gray-300"
                        }`}
                        style={{ backgroundColor: color.value }}
                        title={color.name}
                      />
                    ))}
                  </div>
                </div>
              )}

              {/* Size Selection */}
              {product.sizes && product.sizes.length > 0 && (
                <div>
                  <h3 className="font-medium text-gray-900 mb-3">Size</h3>
                  <Select value={selectedSize} onValueChange={setSelectedSize}>
                    <SelectTrigger className="w-full border-gray-300 focus:border-[#949f7d] focus:ring-[#949f7d]">
                      <SelectValue placeholder="Select size" />
                    </SelectTrigger>
                    <SelectContent>
                      {product.sizes.map((size) => (
                        <SelectItem key={size} value={size}>
                          {size}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}

              {/* Quantity */}
              <div>
                <h3 className="font-medium text-gray-900 mb-3">Quantity</h3>
                <div className="flex items-center space-x-3">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="w-10 h-10 p-0"
                  >
                    <Minus className="w-4 h-4" />
                  </Button>
                  <span className="w-12 text-center font-medium">{quantity}</span>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setQuantity(quantity + 1)}
                    className="w-10 h-10 p-0"
                  >
                    <Plus className="w-4 h-4" />
                  </Button>
                </div>
              </div>

              {/* Stock Status */}
              <div className="flex items-center space-x-2">
                {product.inStock ? (
                  <>
                    <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                    <span className="text-green-700 font-medium">In Stock ({product.stockCount} available)</span>
                  </>
                ) : (
                  <>
                    <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                    <span className="text-red-700 font-medium">Out of Stock</span>
                  </>
                )}
              </div>

              {/* Action Buttons */}
              <div className="space-y-4">
                <div className="flex space-x-4">
                  <Button
                    size="lg"
                    className="flex-1 bg-[#949f7d] hover:bg-[#949f7d]/90 text-white"
                    disabled={!product.inStock}
                  >
                    <ShoppingCart className="w-5 h-5 mr-2" />
                    Add to Cart
                  </Button>
                  <Button size="lg" variant="outline" className="w-12 h-12 p-0 bg-transparent">
                    <Heart className="w-5 h-5" />
                  </Button>
                  <Button size="lg" variant="outline" className="w-12 h-12 p-0 bg-transparent">
                    <Share2 className="w-5 h-5" />
                  </Button>
                </div>

                <Button
                  size="lg"
                  variant="outline"
                  className="w-full border-[#949f7d] text-[#949f7d] hover:bg-[#949f7d] hover:text-white bg-transparent"
                  disabled={!product.inStock}
                >
                  Buy Now
                </Button>
              </div>

              {/* Shipping Info */}
              <div className="border-t pt-6 space-y-3">
                <div className="flex items-center space-x-3 text-sm text-gray-600">
                  <Truck className="w-5 h-5 text-[#949f7d]" />
                  <span>Free shipping on orders over $75</span>
                </div>
                <div className="flex items-center space-x-3 text-sm text-gray-600">
                  <Shield className="w-5 h-5 text-[#949f7d]" />
                  <span>2-year manufacturer warranty</span>
                </div>
                <div className="flex items-center space-x-3 text-sm text-gray-600">
                  <RotateCcw className="w-5 h-5 text-[#949f7d]" />
                  <span>30-day return policy</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Product Information Tabs */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="max-w-4xl mx-auto">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="description">Description</TabsTrigger>
              <TabsTrigger value="specifications">Specifications</TabsTrigger>
              <TabsTrigger value="reviews">Reviews ({product.reviewCount})</TabsTrigger>
              <TabsTrigger value="shipping">Shipping</TabsTrigger>
            </TabsList>

            <TabsContent value="description" className="mt-8">
              <Card>
                <CardContent className="p-8">
                  <h3 className="text-2xl font-bold text-gray-900 mb-6">Product Description</h3>
                  <p className="text-gray-700 leading-relaxed mb-6">{product.description}</p>

                  <h4 className="text-lg font-semibold text-gray-900 mb-4">Key Features</h4>
                  <ul className="space-y-2">
                    {product.features.map((feature, index) => (
                      <li key={index} className="flex items-start space-x-2">
                        <div className="w-2 h-2 bg-[#949f7d] rounded-full mt-2 flex-shrink-0"></div>
                        <span className="text-gray-700">{feature}</span>
                      </li>
                    ))}
                  </ul>

                  {product.perfectFor && (
                    <div className="mt-6">
                      <h4 className="text-lg font-semibold text-gray-900 mb-4">Perfect For</h4>
                      <div className="flex flex-wrap gap-2">
                        {product.perfectFor.map((use, index) => (
                          <span
                            key={index}
                            className="bg-[#949f7d]/10 text-[#949f7d] px-3 py-1 rounded-full text-sm font-medium"
                          >
                            {use}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="specifications" className="mt-8">
              <Card>
                <CardContent className="p-8">
                  <h3 className="text-2xl font-bold text-gray-900 mb-6">Specifications</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {Object.entries(product.specifications).map(([key, value]) => (
                      <div key={key} className="border-b border-gray-200 pb-3">
                        <dt className="font-medium text-gray-900">{key}</dt>
                        <dd className="text-gray-600 mt-1">{value}</dd>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="reviews" className="mt-8">
              <Card>
                <CardContent className="p-8">
                  <div className="flex items-center justify-between mb-6">
                    <h3 className="text-2xl font-bold text-gray-900">Customer Reviews</h3>
                    <div className="flex items-center space-x-2">
                      {renderStars(product.rating)}
                      <span className="text-lg font-medium">{product.rating}</span>
                      <span className="text-gray-600">({product.reviewCount} reviews)</span>
                    </div>
                  </div>

                  <div className="space-y-6">
                    {product.reviews.map((review, index) => (
                      <div key={index} className="border-b border-gray-200 pb-6 last:border-b-0">
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center space-x-3">
                            <span className="font-medium text-gray-900">{review.name}</span>
                            <div className="flex items-center space-x-1">{renderStars(review.rating)}</div>
                          </div>
                          <span className="text-sm text-gray-500">{review.date}</span>
                        </div>
                        <p className="text-gray-700">{review.comment}</p>
                      </div>
                    ))}
                  </div>

                  <div className="mt-8 pt-6 border-t">
                    <Button className="bg-[#949f7d] hover:bg-[#949f7d]/90 text-white">Write a Review</Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="shipping" className="mt-8">
              <Card>
                <CardContent className="p-8">
                  <h3 className="text-2xl font-bold text-gray-900 mb-6">Shipping Information</h3>

                  <div className="space-y-6">
                    <div>
                      <h4 className="font-semibold text-gray-900 mb-2">Delivery Options</h4>
                      <ul className="space-y-2 text-gray-700">
                        <li>• Standard Shipping (5-7 business days): $5.99</li>
                        <li>• Express Shipping (2-3 business days): $12.99</li>
                        <li>• Overnight Shipping (1 business day): $24.99</li>
                        <li>• Free Standard Shipping on orders over $75</li>
                      </ul>
                    </div>

                    <div>
                      <h4 className="font-semibold text-gray-900 mb-2">Return Policy</h4>
                      <p className="text-gray-700">
                        We offer a 30-day return policy for all items in original condition. Items must be unworn and in
                        original packaging with tags attached.
                      </p>
                    </div>

                    <div>
                      <h4 className="font-semibold text-gray-900 mb-2">International Shipping</h4>
                      <p className="text-gray-700">
                        We ship internationally to most countries. International shipping rates and delivery times vary
                        by destination.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </section>

      {/* Related Products */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-gray-900 text-center mb-12">You Might Also Like</h2>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {relatedProducts.map((relatedProduct) => (
              <Card
                key={relatedProduct.id}
                className="group hover:shadow-xl transition-all duration-300 border-0 shadow-lg"
              >
                <div className="relative overflow-hidden">
                  <Image
                    src={relatedProduct.image || "/placeholder.svg"}
                    alt={relatedProduct.name}
                    width={200}
                    height={200}
                    className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                </div>
                <CardContent className="p-4">
                  <h3 className="font-semibold text-gray-900 mb-2 line-clamp-2">{relatedProduct.name}</h3>
                  <p className="text-lg font-bold text-[#949f7d] mb-3">${relatedProduct.price}</p>
                  <Link href={`/shop/${relatedProduct.id}`}>
                    <Button size="sm" className="w-full bg-[#949f7d] hover:bg-[#949f7d]/90 text-white">
                      View Product
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      <Footer />
    </div>
  )
}
