"use client"

import { useState } from "react"
import { Search, Filter, Star, Heart, ShoppingCart, Eye, Grid, List } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import Image from "next/image"
import Link from "next/link"

const products = [
  {
    id: "professional-dance-mat",
    name: "Professional Dance Mat",
    brand: "DanceFloor Pro",
    price: 89.99,
    originalPrice: 119.99,
    rating: 4.8,
    reviewCount: 124,
    image: "/placeholder.svg?height=300&width=300",
    category: "Equipment",
    colors: ["Black", "Gray", "Blue"],
    sizes: ["Small", "Medium", "Large"],
    badge: "Sale",
    inStock: true,
    description: "Non-slip professional dance mat perfect for home practice",
  },
  {
    id: "ballet-costume-set",
    name: "Ballet Dance Costume Set",
    brand: "Elegance Dancewear",
    price: 159.99,
    rating: 4.9,
    reviewCount: 89,
    image: "/placeholder.svg?height=300&width=300",
    category: "Dancewear",
    colors: ["Pink", "White", "Black"],
    sizes: ["XS", "S", "M", "L", "XL"],
    badge: "Featured",
    inStock: true,
    description: "Complete ballet costume set with tutu and accessories",
  },
  {
    id: "ballet-shoes-professional",
    name: "Ballet Shoes - Professional",
    brand: "Prima Ballerina",
    price: 79.99,
    originalPrice: 99.99,
    rating: 4.7,
    reviewCount: 156,
    image: "/placeholder.svg?height=300&width=300",
    category: "Shoes",
    colors: ["Pink", "Black", "White"],
    sizes: ["5", "6", "7", "8", "9", "10"],
    badge: "Sale",
    inStock: true,
    description: "Professional ballet shoes with superior comfort and durability",
  },
  {
    id: "zumba-fitness-set",
    name: "Zumba Fitness Set",
    brand: "FitDance",
    price: 49.99,
    rating: 4.6,
    reviewCount: 203,
    image: "/placeholder.svg?height=300&width=300",
    category: "Dancewear",
    colors: ["Neon Pink", "Purple", "Orange"],
    sizes: ["S", "M", "L", "XL"],
    badge: "New",
    inStock: true,
    description: "Vibrant Zumba outfit designed for high-energy workouts",
  },
  {
    id: "resistance-bands-set",
    name: "Resistance Bands Set",
    brand: "FlexFit",
    price: 29.99,
    originalPrice: 39.99,
    rating: 4.5,
    reviewCount: 87,
    image: "/placeholder.svg?height=300&width=300",
    category: "Equipment",
    colors: ["Multi-color"],
    sizes: ["One Size"],
    badge: "Sale",
    inStock: true,
    description: "Complete resistance bands set for strength training",
  },
  {
    id: "dance-water-bottle",
    name: "Dance Water Bottle",
    brand: "HydrateDance",
    price: 24.99,
    rating: 4.4,
    reviewCount: 67,
    image: "/placeholder.svg?height=300&width=300",
    category: "Accessories",
    colors: ["Pink", "Blue", "Purple", "Black"],
    sizes: ["500ml", "750ml"],
    badge: "Featured",
    inStock: true,
    description: "Insulated water bottle perfect for dance classes",
  },
  {
    id: "yoga-mat-premium",
    name: "Premium Yoga Mat",
    brand: "ZenFlow",
    price: 69.99,
    rating: 4.8,
    reviewCount: 145,
    image: "/placeholder.svg?height=300&width=300",
    category: "Equipment",
    colors: ["Purple", "Teal", "Pink", "Black"],
    sizes: ["Standard", "Extra Long"],
    badge: "Best Seller",
    inStock: true,
    description: "Eco-friendly premium yoga mat with superior grip",
  },
  {
    id: "dance-hair-accessories",
    name: "Dance Hair Accessories Kit",
    brand: "StyleDance",
    price: 34.99,
    rating: 4.6,
    reviewCount: 92,
    image: "/placeholder.svg?height=300&width=300",
    category: "Accessories",
    colors: ["Multi-color"],
    sizes: ["One Size"],
    badge: "New",
    inStock: true,
    description: "Complete hair accessories kit for all dance styles",
  },
  {
    id: "gift-card-50",
    name: "Studio Gift Card - $50",
    brand: "Veritas Dance Studio",
    price: 50.0,
    rating: 5.0,
    reviewCount: 23,
    image: "/placeholder.svg?height=300&width=300",
    category: "Gift Cards",
    colors: ["Gold"],
    sizes: ["Digital"],
    badge: "Perfect Gift",
    inStock: true,
    description: "Digital gift card for classes and merchandise",
  },
]

const categories = ["All Products", "Dancewear", "Shoes", "Accessories", "Equipment", "Gift Cards"]
const brands = [
  "All Brands",
  "DanceFloor Pro",
  "Elegance Dancewear",
  "Prima Ballerina",
  "FitDance",
  "FlexFit",
  "HydrateDance",
  "ZenFlow",
  "StyleDance",
]
const priceRanges = [
  { label: "Under $25", min: 0, max: 25 },
  { label: "$25 - $50", min: 25, max: 50 },
  { label: "$50 - $100", min: 50, max: 100 },
  { label: "$100+", min: 100, max: 1000 },
]

export default function ShopPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("All Products")
  const [selectedBrand, setSelectedBrand] = useState("All Brands")
  const [priceRange, setPriceRange] = useState([0, 200])
  const [sortBy, setSortBy] = useState("popularity")
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid")
  const [showFilters, setShowFilters] = useState(false)

  const filteredProducts = products.filter((product) => {
    const matchesSearch =
      product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      product.brand.toLowerCase().includes(searchQuery.toLowerCase()) ||
      product.description.toLowerCase().includes(searchQuery.toLowerCase())

    const matchesCategory = selectedCategory === "All Products" || product.category === selectedCategory
    const matchesBrand = selectedBrand === "All Brands" || product.brand === selectedBrand
    const matchesPrice = product.price >= priceRange[0] && product.price <= priceRange[1]

    return matchesSearch && matchesCategory && matchesBrand && matchesPrice
  })

  const sortedProducts = [...filteredProducts].sort((a, b) => {
    switch (sortBy) {
      case "price-low":
        return a.price - b.price
      case "price-high":
        return b.price - a.price
      case "rating":
        return b.rating - a.rating
      case "newest":
        return b.badge === "New" ? 1 : -1
      default:
        return b.reviewCount - a.reviewCount
    }
  })

  const getBadgeColor = (badge: string) => {
    switch (badge) {
      case "Sale":
        return "bg-red-500 text-white"
      case "New":
        return "bg-green-500 text-white"
      case "Featured":
        return "bg-[#949f7d] text-white"
      case "Best Seller":
        return "bg-blue-500 text-white"
      case "Perfect Gift":
        return "bg-purple-500 text-white"
      default:
        return "bg-gray-500 text-white"
    }
  }

  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }, (_, i) => (
      <Star
        key={i}
        className={`w-4 h-4 ${i < Math.floor(rating) ? "fill-yellow-400 text-yellow-400" : "text-gray-300"}`}
      />
    ))
  }

  return (
    <div className="min-h-screen bg-white">
      <Header />

      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-br from-[#e5d5bc]/20 to-white">
        <div className="container mx-auto px-4 text-center">
          <nav className="text-sm text-gray-600 mb-6">
            <Link href="/" className="hover:text-[#949f7d] transition-colors">
              Home
            </Link>
            <span className="mx-2">&gt;</span>
            <span className="text-[#949f7d]">Shop</span>
          </nav>
          <h1 className="text-5xl md:text-6xl font-bold text-gray-900 mb-4">Dance Shop</h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">Everything You Need for Your Dance Journey</p>
        </div>
      </section>

      {/* Search and Controls */}
      <section className="py-8 bg-white border-b">
        <div className="container mx-auto px-4">
          <div className="flex flex-col lg:flex-row gap-6 items-center justify-between">
            {/* Search */}
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <Input
                placeholder="Search products..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 border-gray-300 focus:border-[#949f7d] focus:ring-[#949f7d]"
              />
            </div>

            {/* Controls */}
            <div className="flex items-center space-x-4">
              <Button
                variant="outline"
                onClick={() => setShowFilters(!showFilters)}
                className="lg:hidden border-[#949f7d] text-[#949f7d] hover:bg-[#949f7d] hover:text-white"
              >
                <Filter className="w-4 h-4 mr-2" />
                Filters
              </Button>

              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger className="w-48 border-gray-300 focus:border-[#949f7d] focus:ring-[#949f7d]">
                  <SelectValue placeholder="Sort by" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="popularity">Popularity</SelectItem>
                  <SelectItem value="price-low">Price: Low to High</SelectItem>
                  <SelectItem value="price-high">Price: High to Low</SelectItem>
                  <SelectItem value="rating">Highest Rated</SelectItem>
                  <SelectItem value="newest">Newest</SelectItem>
                </SelectContent>
              </Select>

              <div className="flex border rounded-lg">
                <Button
                  variant={viewMode === "grid" ? "default" : "ghost"}
                  size="sm"
                  onClick={() => setViewMode("grid")}
                  className={viewMode === "grid" ? "bg-[#949f7d] hover:bg-[#949f7d]/90" : ""}
                >
                  <Grid className="w-4 h-4" />
                </Button>
                <Button
                  variant={viewMode === "list" ? "default" : "ghost"}
                  size="sm"
                  onClick={() => setViewMode("list")}
                  className={viewMode === "list" ? "bg-[#949f7d] hover:bg-[#949f7d]/90" : ""}
                >
                  <List className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-8">
        <div className="container mx-auto px-4">
          <div className="flex gap-8">
            {/* Filters Sidebar */}
            <div className={`w-80 flex-shrink-0 ${showFilters ? "block" : "hidden lg:block"}`}>
              <div className="sticky top-24 space-y-6">
                {/* Category Filter */}
                <Card className="p-6">
                  <h3 className="font-bold text-gray-900 mb-4">Categories</h3>
                  <div className="space-y-2">
                    {categories.map((category) => (
                      <button
                        key={category}
                        onClick={() => setSelectedCategory(category)}
                        className={`block w-full text-left px-3 py-2 rounded-lg transition-colors ${
                          selectedCategory === category ? "bg-[#949f7d] text-white" : "text-gray-600 hover:bg-gray-100"
                        }`}
                      >
                        {category}
                      </button>
                    ))}
                  </div>
                </Card>

                {/* Price Range */}
                <Card className="p-6">
                  <h3 className="font-bold text-gray-900 mb-4">Price Range</h3>
                  <div className="space-y-4">
                    <Slider value={priceRange} onValueChange={setPriceRange} max={200} step={5} className="w-full" />
                    <div className="flex justify-between text-sm text-gray-600">
                      <span>${priceRange[0]}</span>
                      <span>${priceRange[1]}</span>
                    </div>
                  </div>
                </Card>

                {/* Brand Filter */}
                <Card className="p-6">
                  <h3 className="font-bold text-gray-900 mb-4">Brands</h3>
                  <div className="space-y-2">
                    {brands.map((brand) => (
                      <button
                        key={brand}
                        onClick={() => setSelectedBrand(brand)}
                        className={`block w-full text-left px-3 py-2 rounded-lg transition-colors ${
                          selectedBrand === brand ? "bg-[#949f7d] text-white" : "text-gray-600 hover:bg-gray-100"
                        }`}
                      >
                        {brand}
                      </button>
                    ))}
                  </div>
                </Card>
              </div>
            </div>

            {/* Products Grid */}
            <div className="flex-1">
              <div className="mb-6">
                <p className="text-gray-600">
                  Showing {sortedProducts.length} of {products.length} products
                </p>
              </div>

              {sortedProducts.length === 0 ? (
                <div className="text-center py-16">
                  <p className="text-xl text-gray-600 mb-4">No products found matching your criteria.</p>
                  <Button
                    onClick={() => {
                      setSearchQuery("")
                      setSelectedCategory("All Products")
                      setSelectedBrand("All Brands")
                      setPriceRange([0, 200])
                    }}
                    className="bg-[#949f7d] hover:bg-[#949f7d]/90 text-white"
                  >
                    Clear Filters
                  </Button>
                </div>
              ) : (
                <div
                  className={
                    viewMode === "grid"
                      ? "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
                      : "space-y-6"
                  }
                >
                  {sortedProducts.map((product) => (
                    <Card
                      key={product.id}
                      className={`group hover:shadow-xl transition-all duration-300 border-0 shadow-lg overflow-hidden ${
                        viewMode === "list" ? "flex" : ""
                      }`}
                    >
                      <div className={`relative overflow-hidden ${viewMode === "list" ? "w-48 flex-shrink-0" : ""}`}>
                        <Image
                          src={product.image || "/placeholder.svg"}
                          alt={product.name}
                          width={300}
                          height={300}
                          className={`object-cover group-hover:scale-105 transition-transform duration-300 ${
                            viewMode === "list" ? "w-full h-48" : "w-full h-64"
                          }`}
                        />
                        <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors duration-300"></div>

                        {product.badge && (
                          <div
                            className={`absolute top-3 left-3 px-2 py-1 rounded-full text-xs font-bold ${getBadgeColor(product.badge)}`}
                          >
                            {product.badge}
                          </div>
                        )}

                        <div className="absolute top-3 right-3 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                          <Button size="sm" variant="secondary" className="w-8 h-8 p-0 rounded-full">
                            <Heart className="w-4 h-4" />
                          </Button>
                        </div>

                        <div className="absolute bottom-3 right-3 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex space-x-2">
                          <Link href={`/shop/${product.id}`}>
                            <Button size="sm" variant="secondary" className="w-8 h-8 p-0 rounded-full">
                              <Eye className="w-4 h-4" />
                            </Button>
                          </Link>
                          <Button size="sm" className="w-8 h-8 p-0 rounded-full bg-[#949f7d] hover:bg-[#949f7d]/90">
                            <ShoppingCart className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>

                      <CardContent className={`p-4 ${viewMode === "list" ? "flex-1" : ""}`}>
                        <div className="mb-2">
                          <p className="text-sm text-gray-500">{product.brand}</p>
                          <Link href={`/shop/${product.id}`}>
                            <h3 className="font-semibold text-gray-900 hover:text-[#949f7d] transition-colors line-clamp-2">
                              {product.name}
                            </h3>
                          </Link>
                        </div>

                        <div className="flex items-center space-x-1 mb-2">
                          {renderStars(product.rating)}
                          <span className="text-sm text-gray-500">({product.reviewCount})</span>
                        </div>

                        <div className="flex items-center space-x-2 mb-3">
                          <span className="text-lg font-bold text-[#949f7d]">${product.price}</span>
                          {product.originalPrice && (
                            <span className="text-sm text-gray-500 line-through">${product.originalPrice}</span>
                          )}
                        </div>

                        {viewMode === "list" && (
                          <p className="text-sm text-gray-600 mb-4 line-clamp-2">{product.description}</p>
                        )}

                        <div className="flex space-x-2">
                          <Link href={`/shop/${product.id}`} className="flex-1">
                            <Button
                              size="sm"
                              variant="outline"
                              className="w-full border-[#949f7d] text-[#949f7d] hover:bg-[#949f7d] hover:text-white bg-transparent"
                            >
                              Quick View
                            </Button>
                          </Link>
                          <Button size="sm" className="flex-1 bg-[#949f7d] hover:bg-[#949f7d]/90 text-white">
                            Add to Cart
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Newsletter Section */}
      <section className="py-16 bg-gradient-to-r from-[#949f7d] to-[#949f7d]/80">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Free Shipping Over $75</h2>
          <p className="text-xl text-white/90 mb-8 max-w-2xl mx-auto">
            Get your dance essentials delivered free when you spend $75 or more. Plus, join our newsletter for exclusive
            deals!
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center max-w-md mx-auto">
            <Input
              placeholder="Your email address"
              className="flex-1 border-white/20 bg-white/10 text-white placeholder:text-white/70"
            />
            <Button className="bg-white text-[#949f7d] hover:bg-gray-100">Subscribe</Button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  )
}
