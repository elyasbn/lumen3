"use client"

import { useState, useEffect } from "react"
import { ArrowLeft, Calendar, Award, Globe, BookOpen, Star, Clock } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import Image from "next/image"
import Link from "next/link"
import { useParams } from "next/navigation"

interface Coach {
  id: number
  name: string
  email: string
  phone: string | null
  specialties: string[] | null
  experience: string | null
  rating: number | null
  students: number | null
  status: string
  avatar: string | null
  bio: string | null
  certifications: string[] | null
  joinedAt: string
  socialMedia: any
}

interface Class {
  id: number
  name: string
  description: string | null
  instructor: string
  instructorId: number
  schedule: string | null
  duration: number | null
  capacity: number | null
  enrolled: number | null
  price: number | null
  status: string
  level: string | null
  image: string | null
  createdAt: string
  updatedAt: string
}

export default function CoachProfilePage() {
  const params = useParams()
  const slug = params.slug as string
  
  const [coach, setCoach] = useState<Coach | null>(null)
  const [coachClasses, setCoachClasses] = useState<Class[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const fetchCoachData = async () => {
      try {
        setLoading(true)
        
        // Fetch coaches
        const coachesResponse = await fetch('/api/coaches')
        if (!coachesResponse.ok) {
          throw new Error('Failed to fetch coaches')
        }
        const coaches: Coach[] = await coachesResponse.json()
        
        // Find coach by slug (assuming slug is derived from name)
        const coachItem = coaches.find(c => 
          c.name.toLowerCase().replace(/\s+/g, '-') === slug ||
          c.name.toLowerCase().replace(/\s+/g, '-').includes(slug)
        )
        
        if (!coachItem) {
          setError('Coach not found')
          return
        }
        
        setCoach(coachItem)
        
        // Fetch classes taught by this coach
        const classesResponse = await fetch('/api/classes')
        if (classesResponse.ok) {
          const classes: Class[] = await classesResponse.json()
          const instructorClasses = classes.filter(c => 
            c.instructorId === coachItem.id && c.status === 'active'
          )
          setCoachClasses(instructorClasses)
        }
      } catch (err) {
        setError(err instanceof Error ? err.message : 'An error occurred')
      } finally {
        setLoading(false)
      }
    }

    if (slug) {
      fetchCoachData()
    }
  }, [slug])

  // Generate slug from coach name
  const generateSlug = (name: string) => {
    return name.toLowerCase().replace(/\s+/g, '-')
  }

  // Loading state
  if (loading) {
    return (
      <div className="min-h-screen bg-white">
        <Header />
        <div className="container mx-auto px-4 py-16">
          <div className="max-w-4xl mx-auto">
            <div className="animate-pulse">
              <div className="h-96 bg-gray-200 rounded-lg mb-8"></div>
              <div className="h-8 bg-gray-200 rounded mb-4"></div>
              <div className="h-4 bg-gray-200 rounded mb-2"></div>
              <div className="h-4 bg-gray-200 rounded mb-2"></div>
              <div className="h-4 bg-gray-200 rounded w-3/4"></div>
            </div>
          </div>
        </div>
        <Footer />
      </div>
    )
  }

  // Error state
  if (error || !coach) {
    return (
      <div className="min-h-screen bg-white">
        <Header />
        <div className="container mx-auto px-4 py-20 text-center">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Coach Not Found</h1>
          <p className="text-xl text-gray-600 mb-8">{error || "The instructor you're looking for doesn't exist."}</p>
          <Link href="/coaches">
            <Button className="bg-[#949f7d] hover:bg-[#949f7d]/90 text-white">Back to All Coaches</Button>
          </Link>
        </div>
        <Footer />
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-white">
      <Header />

      {/* Hero Section */}
      <section className="relative py-20 bg-gradient-to-br from-[#e5d5bc]/20 to-white">
        <div className="container mx-auto px-4">
          <nav className="text-sm text-gray-600 mb-6">
            <Link href="/" className="hover:text-[#949f7d] transition-colors">
              Home
            </Link>
            <span className="mx-2">&gt;</span>
            <Link href="/coaches" className="hover:text-[#949f7d] transition-colors">
              Coaches
            </Link>
            <span className="mx-2">&gt;</span>
            <span className="text-[#949f7d]">{coach.name}</span>
          </nav>

          <div className="flex items-center space-x-4 mb-8">
            <Link href="/coaches">
              <Button
                variant="outline"
                size="sm"
                className="border-[#949f7d] text-[#949f7d] hover:bg-[#949f7d] hover:text-white bg-transparent"
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to All Coaches
              </Button>
            </Link>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-12 items-start">
            {/* Coach Photo */}
            <div className="lg:col-span-1">
              <div className="relative">
                <div className="w-full max-w-md mx-auto rounded-2xl overflow-hidden shadow-2xl">
                  <Image
                    src={coach.avatar || "/placeholder.svg"}
                    alt={coach.name}
                    width={400}
                    height={400}
                    className="w-full h-auto object-cover"
                    priority
                  />
                </div>
              </div>
            </div>

            {/* Coach Info */}
            <div className="lg:col-span-2">
              <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">{coach.name}</h1>
              <p className="text-xl text-[#949f7d] font-medium mb-6">
                {coach.specialties ? coach.specialties.join(" & ") : "Dance Instructor"}
              </p>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                <div className="flex items-center space-x-3">
                  <div className="w-12 h-12 bg-[#949f7d] rounded-full flex items-center justify-center">
                    <Calendar className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Experience</p>
                    <p className="font-semibold text-gray-900">{coach.experience || "Professional"}</p>
                  </div>
                </div>

                <div className="flex items-center space-x-3">
                  <div className="w-12 h-12 bg-[#949f7d] rounded-full flex items-center justify-center">
                    <Award className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Certifications</p>
                    <p className="font-semibold text-gray-900">
                      {coach.certifications ? coach.certifications.length : 0} Credentials
                    </p>
                  </div>
                </div>

                <div className="flex items-center space-x-3">
                  <div className="w-12 h-12 bg-[#949f7d] rounded-full flex items-center justify-center">
                    <Star className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Rating</p>
                    <p className="font-semibold text-gray-900">
                      {coach.rating ? `${coach.rating}/5` : "New Instructor"}
                    </p>
                  </div>
                </div>
              </div>

              <div className="flex flex-wrap gap-4">
                <Button size="lg" className="bg-[#949f7d] hover:bg-[#949f7d]/90 text-white">
                  Book a Class with {coach.name.split(" ")[0]}
                </Button>
                <Button
                  size="lg"
                  variant="outline"
                  className="border-[#949f7d] text-[#949f7d] hover:bg-[#949f7d] hover:text-white bg-transparent"
                >
                  Schedule Consultation
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            {/* Biography */}
            <div className="mb-16">
              <h2 className="text-3xl font-bold text-gray-900 mb-8">About {coach.name.split(" ")[0]}</h2>
              <div className="prose prose-lg max-w-none">
                <p className="text-gray-700 leading-relaxed mb-6">
                  {coach.bio || `Meet ${coach.name}, a passionate dance instructor who brings years of experience and dedication to our studio. ${coach.name} specializes in ${coach.specialties ? coach.specialties.join(", ") : "various dance styles"} and is committed to helping students of all levels achieve their dance goals.`}
                  </p>
              </div>
            </div>

            {/* Details Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
              {/* Certifications */}
              <Card className="p-6 shadow-lg">
                <div className="flex items-center space-x-3 mb-6">
                  <div className="w-10 h-10 bg-[#949f7d] rounded-full flex items-center justify-center">
                    <Award className="w-5 h-5 text-white" />
                  </div>
                  <h3 className="text-xl font-bold text-gray-900">Certifications & Qualifications</h3>
                </div>
                {coach.certifications && coach.certifications.length > 0 ? (
                <ul className="space-y-3">
                  {coach.certifications.map((cert, index) => (
                    <li key={index} className="flex items-start space-x-2">
                      <Star className="w-4 h-4 text-[#949f7d] mt-1 flex-shrink-0" />
                      <span className="text-gray-700">{cert}</span>
                    </li>
                  ))}
                </ul>
                ) : (
                  <p className="text-gray-600">Certifications coming soon...</p>
                )}
              </Card>

              {/* Specialties */}
              <Card className="p-6 shadow-lg">
                <div className="flex items-center space-x-3 mb-6">
                  <div className="w-10 h-10 bg-[#949f7d] rounded-full flex items-center justify-center">
                    <Star className="w-5 h-5 text-white" />
                  </div>
                  <h3 className="text-xl font-bold text-gray-900">Specialties & Skills</h3>
                </div>
                {coach.specialties && coach.specialties.length > 0 ? (
                <ul className="space-y-3">
                    {coach.specialties.map((specialty, index) => (
                    <li key={index} className="flex items-start space-x-2">
                      <Award className="w-4 h-4 text-[#949f7d] mt-1 flex-shrink-0" />
                        <span className="text-gray-700">{specialty}</span>
                    </li>
                  ))}
                </ul>
                ) : (
                  <p className="text-gray-600">Specialties coming soon...</p>
                )}
              </Card>
            </div>

            {/* Classes */}
            <div className="mb-16">
              <h2 className="text-3xl font-bold text-gray-900 mb-8">Classes with {coach.name.split(" ")[0]}</h2>
              {coachClasses.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {coachClasses.map((classItem) => (
                    <Card key={classItem.id} className="p-6 shadow-lg hover:shadow-xl transition-all duration-300">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="text-xl font-bold text-gray-900">{classItem.name}</h3>
                      <span className="bg-[#949f7d] text-white px-3 py-1 rounded-full text-sm font-medium">
                          {classItem.level || "All Levels"}
                      </span>
                    </div>
                    <div className="flex items-center space-x-4 text-gray-600 mb-4">
                      <div className="flex items-center space-x-1">
                        <Clock className="w-4 h-4" />
                          <span className="text-sm">{classItem.duration ? `${classItem.duration} min` : "60 min"}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <BookOpen className="w-4 h-4" />
                          <span className="text-sm">
                            {classItem.enrolled || 0}/{classItem.capacity || "∞"} students
                          </span>
                        </div>
                      </div>
                      <p className="text-gray-600 mb-4 line-clamp-2">
                        {classItem.description || `Join ${coach.name} for an amazing ${classItem.name} class!`}
                      </p>
                      <Link href={`/classes/${generateSlug(classItem.name)}`}>
                      <Button className="w-full bg-[#949f7d] hover:bg-[#949f7d]/90 text-white">Book This Class</Button>
                    </Link>
                  </Card>
                ))}
              </div>
              ) : (
                <div className="text-center py-12">
                  <p className="text-gray-600 mb-4">No classes available with {coach.name.split(" ")[0]} at the moment.</p>
                  <Link href="/classes">
                    <Button className="bg-[#949f7d] hover:bg-[#949f7d]/90 text-white">View All Classes</Button>
                  </Link>
                </div>
              )}
            </div>

            {/* Contact Section */}
            <Card className="p-8 bg-gradient-to-r from-[#949f7d]/10 to-[#e5d5bc]/10 text-center">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">Ready to Start Dancing?</h2>
              <p className="text-gray-600 mb-6 max-w-2xl mx-auto">
                Book a class with {coach.name.split(" ")[0]} and experience their expert instruction and passionate
                teaching style firsthand.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button size="lg" className="bg-[#949f7d] hover:bg-[#949f7d]/90 text-white">
                  Book a Class Now
                </Button>
                <Link href="/coaches">
                  <Button
                    size="lg"
                    variant="outline"
                    className="border-[#949f7d] text-[#949f7d] hover:bg-[#949f7d] hover:text-white bg-transparent"
                  >
                    View All Instructors
                  </Button>
                </Link>
              </div>
            </Card>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  )
}
