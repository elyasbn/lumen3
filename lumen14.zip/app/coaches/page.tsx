"use client"

import { useState, useEffect } from "react"
import { Search, Filter, Star, Calendar, Award, Users } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import Image from "next/image"
import Link from "next/link"

interface Coach {
  id: number
  name: string
  email: string
  phone: string | null
  specialties: string[] | null
  experience: string | null
  rating: number | null
  students: number | null
  status: string
  avatar: string | null
  bio: string | null
  certifications: string[] | null
  joinedAt: string
  socialMedia: any
}

// Generate slug from coach name
const generateSlug = (name: string) => {
  return name.toLowerCase().replace(/\s+/g, '-')
}

export default function CoachesPage() {
  const [coaches, setCoaches] = useState<Coach[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedSpecialization, setSelectedSpecialization] = useState("All Instructors")

  useEffect(() => {
    const fetchCoaches = async () => {
      try {
        setLoading(true)
        const response = await fetch('/api/coaches')
        if (!response.ok) {
          throw new Error('Failed to fetch coaches')
        }
        const coachesData: Coach[] = await response.json()
        setCoaches(coachesData)
      } catch (err) {
        setError(err instanceof Error ? err.message : 'An error occurred')
      } finally {
        setLoading(false)
      }
    }

    fetchCoaches()
  }, [])

  // Get unique specializations from coaches data
  const specializations = ["All Instructors", ...Array.from(new Set(
    coaches.flatMap(coach => coach.specialties || [])
  ))]

  const filteredCoaches = coaches.filter((coach) => {
    const matchesSearch =
      coach.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (coach.specialties && coach.specialties.some(specialty => 
        specialty.toLowerCase().includes(searchQuery.toLowerCase())
      )) ||
      (coach.bio && coach.bio.toLowerCase().includes(searchQuery.toLowerCase()))

    const matchesSpecialization =
      selectedSpecialization === "All Instructors" ||
      (coach.specialties && coach.specialties.some(specialty => 
        specialty.toLowerCase().includes(selectedSpecialization.toLowerCase())
      ))

    return matchesSearch && matchesSpecialization && coach.status === 'active'
  })

  // For now, we'll consider coaches with high ratings as featured
  const featuredCoaches = filteredCoaches.filter((coach) => 
    coach.rating && coach.rating >= 4.5
  )
  const regularCoaches = filteredCoaches.filter((coach) => 
    !coach.rating || coach.rating < 4.5
  )

  // Loading state
  if (loading) {
    return (
      <div className="min-h-screen bg-white">
        <Header />
        <div className="container mx-auto px-4 py-16">
          <div className="animate-pulse">
            <div className="h-8 bg-gray-200 rounded mb-4"></div>
            <div className="h-4 bg-gray-200 rounded mb-2"></div>
            <div className="h-4 bg-gray-200 rounded w-3/4 mx-auto"></div>
          </div>
        </div>
        <Footer />
      </div>
    )
  }

  // Error state
  if (error) {
    return (
      <div className="min-h-screen bg-white">
        <Header />
        <div className="container mx-auto px-4 py-20 text-center">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Error Loading Coaches</h1>
          <p className="text-xl text-gray-600 mb-8">{error}</p>
          <Button 
            onClick={() => window.location.reload()} 
            className="bg-[#949f7d] hover:bg-[#949f7d]/90 text-white"
          >
            Try Again
          </Button>
        </div>
        <Footer />
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-white">
      <Header />

      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-br from-[#e5d5bc]/20 to-white">
        <div className="container mx-auto px-4 text-center">
          <nav className="text-sm text-gray-600 mb-6">
            <Link href="/" className="hover:text-[#949f7d] transition-colors">
              Home
            </Link>
            <span className="mx-2">&gt;</span>
            <span className="text-[#949f7d]">Coaches</span>
          </nav>
          <h1 className="text-5xl md:text-6xl font-bold text-gray-900 mb-4">Meet Our Instructors</h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">Expert Teachers, Passionate Artists</p>
        </div>
      </section>

      {/* Search and Filters */}
      <section className="py-8 bg-white border-b">
        <div className="container mx-auto px-4">
          <div className="flex flex-col lg:flex-row gap-6 items-center justify-between">
            {/* Search */}
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <Input
                placeholder="Search instructors..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 border-gray-300 focus:border-[#949f7d] focus:ring-[#949f7d]"
              />
            </div>

            {/* Filters */}
            <div className="flex flex-wrap gap-4 items-center">
              <div className="flex items-center space-x-2">
                <Filter className="w-4 h-4 text-gray-600" />
                <span className="text-sm font-medium text-gray-600">Specialization:</span>
              </div>

              <div className="flex flex-wrap gap-2">
                {specializations.map((specialization) => (
                  <button
                    key={specialization}
                    onClick={() => setSelectedSpecialization(specialization)}
                    className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
                      selectedSpecialization === specialization
                        ? "bg-[#949f7d] text-white shadow-lg"
                        : "bg-gray-100 text-gray-600 hover:bg-gray-200"
                    }`}
                  >
                    {specialization}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Instructors */}
      {featuredCoaches.length > 0 && (
        <section className="py-16 bg-[#e5d5bc]/10">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-gray-900 text-center mb-12">Featured Instructors</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
              {featuredCoaches.map((coach) => (
                <Card
                  key={coach.id}
                  className="group hover:shadow-2xl transition-all duration-300 border-0 shadow-lg text-center relative overflow-hidden"
                >
                  <div className="absolute top-4 right-4 bg-[#949f7d] text-white px-3 py-1 rounded-full text-xs font-bold flex items-center space-x-1">
                    <Star className="w-3 h-3" />
                    <span>Featured</span>
                  </div>

                  <CardContent className="p-8">
                    <div className="relative mb-6">
                      <div className="w-32 h-32 mx-auto rounded-full overflow-hidden border-4 border-[#949f7d]/20 group-hover:border-[#949f7d] transition-colors duration-300">
                        <Image
                          src={coach.avatar || "/placeholder.svg"}
                          alt={coach.name}
                          width={128}
                          height={128}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                        />
                      </div>
                    </div>

                    <h3 className="text-xl font-bold text-gray-900 mb-2">{coach.name}</h3>
                    <p className="text-[#949f7d] font-medium mb-2">
                      {coach.specialties ? coach.specialties.join(" & ") : "Dance Instructor"}
                    </p>
                    <p className="text-gray-600 text-sm mb-4">
                      {coach.bio || `Meet ${coach.name}, a passionate dance instructor.`}
                    </p>

                    <div className="flex items-center justify-center space-x-4 text-sm text-gray-500 mb-6">
                      <div className="flex items-center space-x-1">
                        <Calendar className="w-4 h-4" />
                        <span>{coach.experience || "Professional"}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Users className="w-4 h-4" />
                        <span>{coach.students || 0} students</span>
                      </div>
                      {coach.rating && (
                        <div className="flex items-center space-x-1">
                          <Star className="w-4 h-4" />
                          <span>{coach.rating}/5</span>
                        </div>
                      )}
                    </div>

                    <Link href={`/coaches/${generateSlug(coach.name)}`}>
                      <Button className="w-full bg-[#949f7d] hover:bg-[#949f7d]/90 text-white">
                        Meet {coach.name.split(" ")[0]}
                      </Button>
                    </Link>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* All Instructors */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          {featuredCoaches.length > 0 && (
            <h2 className="text-3xl font-bold text-gray-900 text-center mb-12">All Instructors</h2>
          )}

          {filteredCoaches.length === 0 ? (
            <div className="text-center py-16">
              <p className="text-xl text-gray-600 mb-4">No instructors found matching your criteria.</p>
              <Button
                onClick={() => {
                  setSearchQuery("")
                  setSelectedSpecialization("All Instructors")
                }}
                className="bg-[#949f7d] hover:bg-[#949f7d]/90 text-white"
              >
                Clear Filters
              </Button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              {(featuredCoaches.length > 0 ? regularCoaches : filteredCoaches).map((coach) => (
                <Card
                  key={coach.id}
                  className="group hover:shadow-xl transition-all duration-300 border-0 shadow-lg text-center"
                >
                  <CardContent className="p-6">
                    <div className="relative mb-6">
                      <div className="w-24 h-24 mx-auto rounded-full overflow-hidden border-4 border-[#949f7d]/20 group-hover:border-[#949f7d] transition-colors duration-300">
                        <Image
                          src={coach.avatar || "/placeholder.svg"}
                          alt={coach.name}
                          width={96}
                          height={96}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                        />
                      </div>
                    </div>

                    <h3 className="text-lg font-bold text-gray-900 mb-1">{coach.name}</h3>
                    <p className="text-[#949f7d] font-medium text-sm mb-2">
                      {coach.specialties ? coach.specialties.join(" & ") : "Dance Instructor"}
                    </p>
                    <p className="text-gray-600 text-xs mb-4">
                      {coach.bio || `Meet ${coach.name}, a passionate dance instructor.`}
                    </p>

                    <div className="flex items-center justify-center space-x-3 text-xs text-gray-500 mb-4">
                      <div className="flex items-center space-x-1">
                        <Calendar className="w-3 h-3" />
                        <span>{coach.experience || "Professional"}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Award className="w-3 h-3" />
                        <span>{coach.certifications ? coach.certifications.length : 0}</span>
                      </div>
                      {coach.rating && (
                        <div className="flex items-center space-x-1">
                          <Star className="w-3 h-3" />
                          <span>{coach.rating}</span>
                        </div>
                      )}
                    </div>

                    <Link href={`/coaches/${generateSlug(coach.name)}`}>
                      <Button size="sm" className="w-full bg-[#949f7d] hover:bg-[#949f7d]/90 text-white text-sm">
                        Meet {coach.name.split(" ")[0]}
                      </Button>
                    </Link>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Join Our Team CTA */}
      <section className="py-16 bg-gradient-to-r from-[#949f7d] to-[#949f7d]/80">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Join Our Team</h2>
          <p className="text-xl text-white/90 mb-8 max-w-2xl mx-auto">
            Are you a passionate dance instructor? We're always looking for talented teachers to join our growing
            family.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="bg-white text-[#949f7d] hover:bg-gray-100 px-8 py-3">
              Apply Now
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="border-white text-white hover:bg-white hover:text-[#949f7d] px-8 py-3 bg-transparent"
            >
              Learn More
            </Button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  )
}
