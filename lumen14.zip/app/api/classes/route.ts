import { NextResponse } from "next/server"
import { PrismaClient } from "@prisma/client"

const prisma = new PrismaClient()

export async function GET() {
  try {
    const classes = await prisma.class.findMany({
      orderBy: {
        createdAt: 'desc'
      }
    })
    return NextResponse.json(classes)
  } catch (error) {
    console.error("Error fetching classes:", error)
    return NextResponse.json({ error: "Failed to load classes" }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()
    
    // Validate required fields
    const { name, instructor, instructorId, status } = body
    
    if (!name || !instructor || !instructorId || !status) {
      return NextResponse.json(
        { error: "Missing required fields: name, instructor, instructorId, and status are required" },
        { status: 400 }
      )
    }

    // Validate numeric fields
    const { duration, capacity, enrolled, price } = body
    
    if (duration && (isNaN(duration) || duration <= 0)) {
      return NextResponse.json(
        { error: "Duration must be a positive number" },
        { status: 400 }
      )
    }

    if (capacity && (isNaN(capacity) || capacity <= 0)) {
      return NextResponse.json(
        { error: "Capacity must be a positive number" },
        { status: 400 }
      )
    }

    if (enrolled && (isNaN(enrolled) || enrolled < 0)) {
      return NextResponse.json(
        { error: "Enrolled must be a non-negative number" },
        { status: 400 }
      )
    }

    if (price && (isNaN(price) || price < 0)) {
      return NextResponse.json(
        { error: "Price must be a non-negative number" },
        { status: 400 }
      )
    }

    // Create new class
    const newClass = await prisma.class.create({
      data: {
        name,
        description: body.description || null,
        instructor,
        instructorId,
        schedule: body.schedule || null,
        duration: body.duration ? parseInt(body.duration) : null,
        capacity: body.capacity ? parseInt(body.capacity) : null,
        enrolled: body.enrolled ? parseInt(body.enrolled) : 0,
        price: body.price ? parseFloat(body.price) : null,
        status,
        level: body.level || null,
        image: body.image || null
      }
    })

    return NextResponse.json(newClass, { status: 201 })
  } catch (error) {
    console.error("Error creating class:", error)
    return NextResponse.json({ error: "Failed to create class" }, { status: 500 })
  }
}
