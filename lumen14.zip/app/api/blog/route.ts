import { NextResponse } from "next/server"
import { PrismaClient } from "@prisma/client"

const prisma = new PrismaClient()

export async function GET() {
  try {
    const posts = await prisma.blog.findMany({
      orderBy: {
        publishedAt: 'desc'
      }
    })
    return NextResponse.json(posts)
  } catch (error) {
    console.error("Error fetching blog posts:", error)
    return NextResponse.json({ error: "Failed to load blog posts" }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()
    console.log("Received blog post data:", body)
    
    // Validate required fields
    const { title, slug, author, authorId, content, excerpt, category, tags, readTime, image, featured, seo, status, publishedAt } = body
    
    if (!title || !slug || !author || authorId === undefined || authorId === null) {
      return NextResponse.json(
        { error: "Missing required fields: title, slug, author, and authorId are required" },
        { status: 400 }
      )
    }

    // Validate authorId is a number
    if (isNaN(parseInt(authorId.toString()))) {
      return NextResponse.json(
        { error: "authorId must be a valid number" },
        { status: 400 }
      )
    }

    // Check if slug already exists
    const existingPost = await prisma.blog.findUnique({
      where: { slug }
    })

    if (existingPost) {
      return NextResponse.json(
        { error: "A blog post with this slug already exists" },
        { status: 409 }
      )
    }

    // Parse publishedAt date
    let publishedDate = new Date()
    if (publishedAt) {
      publishedDate = new Date(publishedAt)
      if (isNaN(publishedDate.getTime())) {
        return NextResponse.json(
          { error: "Invalid publishedAt date format" },
          { status: 400 }
        )
      }
    }

    // Create new blog post
    const newPost = await prisma.blog.create({
      data: {
        title: title.trim(),
        slug: slug.trim(),
        author: author.trim(),
        authorId: parseInt(authorId.toString()),
        content: content?.trim() || null,
        excerpt: excerpt?.trim() || null,
        publishedAt: publishedDate,
        updatedAt: new Date(),
        status: status || 'published',
        category: category?.trim() || null,
        tags: tags || null,
        readTime: readTime || null,
        views: 0,
        featured: featured || false,
        image: image || null,
        seo: seo || null
      }
    })

    console.log("Created blog post:", newPost)
    return NextResponse.json(newPost, { status: 201 })
  } catch (error) {
    console.error("Error creating blog post:", error)
    return NextResponse.json({ 
      error: "Failed to create blog post", 
      details: error instanceof Error ? error.message : "Unknown error"
    }, { status: 500 })
  }
}
