import { NextResponse } from "next/server"
import { PrismaClient } from "@prisma/client"

const prisma = new PrismaClient()

export async function PUT(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const productId = parseInt(params.id)
    
    if (isNaN(productId)) {
      return NextResponse.json(
        { error: "Invalid product ID" },
        { status: 400 }
      )
    }

    const body = await request.json()
    
    // Validate required fields
    const { name, slug, price, stock, status } = body
    
    if (!name || !slug || !price || !stock || !status) {
      return NextResponse.json(
        { error: "Missing required fields: name, slug, price, stock, and status are required" },
        { status: 400 }
      )
    }

    // Validate numeric fields
    const { originalPrice, sold, rating, reviewCount } = body
    
    if (originalPrice && (isNaN(originalPrice) || originalPrice < 0)) {
      return NextResponse.json(
        { error: "Original price must be a non-negative number" },
        { status: 400 }
      )
    }

    if (sold && (isNaN(sold) || sold < 0)) {
      return NextResponse.json(
        { error: "Sold count must be a non-negative number" },
        { status: 400 }
      )
    }

    if (rating && (isNaN(rating) || rating < 0 || rating > 5)) {
      return NextResponse.json(
        { error: "Rating must be a number between 0 and 5" },
        { status: 400 }
      )
    }

    if (reviewCount && (isNaN(reviewCount) || reviewCount < 0)) {
      return NextResponse.json(
        { error: "Review count must be a non-negative number" },
        { status: 400 }
      )
    }

    // Check if product exists
    const existingProduct = await prisma.product.findUnique({
      where: { id: productId }
    })

    if (!existingProduct) {
      return NextResponse.json(
        { error: "Product not found" },
        { status: 404 }
      )
    }

    // Check if slug is unique (excluding current product)
    const slugExists = await prisma.product.findFirst({
      where: { 
        slug,
        id: { not: productId }
      }
    })

    if (slugExists) {
      return NextResponse.json(
        { error: "A product with this slug already exists" },
        { status: 409 }
      )
    }

    // Update product
    const updatedProduct = await prisma.product.update({
      where: { id: productId },
      data: {
        name,
        slug,
        category: body.category || null,
        price: parseFloat(price),
        originalPrice: originalPrice ? parseFloat(originalPrice) : null,
        stock: parseInt(stock),
        sold: sold ? parseInt(sold) : null,
        rating: rating ? parseFloat(rating) : null,
        reviewCount: reviewCount ? parseInt(reviewCount) : null,
        status,
        featured: body.featured || false,
        badge: body.badge || null,
        image: body.image || null,
        images: body.images || null,
        description: body.description || null,
        features: body.features || null,
        sizes: body.sizes || null,
        colors: body.colors || null,
        tags: body.tags || null
      }
    })

    return NextResponse.json(updatedProduct)
  } catch (error) {
    console.error("Error updating product:", error)
    return NextResponse.json({ error: "Failed to update product" }, { status: 500 })
  }
}

export async function DELETE(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const productId = parseInt(params.id)
    
    if (isNaN(productId)) {
      return NextResponse.json(
        { error: "Invalid product ID" },
        { status: 400 }
      )
    }

    // Check if product exists
    const existingProduct = await prisma.product.findUnique({
      where: { id: productId }
    })

    if (!existingProduct) {
      return NextResponse.json(
        { error: "Product not found" },
        { status: 404 }
      )
    }

    // Delete product
    await prisma.product.delete({
      where: { id: productId }
    })

    return NextResponse.json({ message: "Product deleted successfully" })
  } catch (error) {
    console.error("Error deleting product:", error)
    return NextResponse.json({ error: "Failed to delete product" }, { status: 500 })
  }
}
