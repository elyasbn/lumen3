import { NextResponse } from "next/server"
import { PrismaClient } from "@prisma/client"

const prisma = new PrismaClient()

export async function GET() {
  try {
    const products = await prisma.product.findMany({
      orderBy: {
        id: 'desc'
      }
    })
    return NextResponse.json(products)
  } catch (error) {
    console.error("Error fetching products:", error)
    return NextResponse.json({ error: "Failed to load products" }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()
    
    // Validate required fields
    const { name, slug, price, stock, status } = body
    
    if (!name || !slug || !price || !status) {
      return NextResponse.json(
        { error: "Missing required fields: name, slug, price, stock, and status are required" },
        { status: 400 }
      )
    }

    // Validate numeric fields
    const { price: priceValue, originalPrice, stock: stockValue, sold, rating, reviewCount } = body
    
    if (isNaN(priceValue) || priceValue < 0) {
      return NextResponse.json(
        { error: "Price must be a non-negative number" },
        { status: 400 }
      )
    }

    if (originalPrice && (isNaN(originalPrice) || originalPrice < 0)) {
      return NextResponse.json(
        { error: "Original price must be a non-negative number" },
        { status: 400 }
      )
    }

    if (isNaN(stockValue) || stockValue < 0) {
      return NextResponse.json(
        { error: "Stock must be a non-negative number" },
        { status: 400 }
      )
    }

    if (sold && (isNaN(sold) || sold < 0)) {
      return NextResponse.json(
        { error: "Sold count must be a non-negative number" },
        { status: 400 }
      )
    }

    if (rating && (isNaN(rating) || rating < 0 || rating > 5)) {
      return NextResponse.json(
        { error: "Rating must be a number between 0 and 5" },
        { status: 400 }
      )
    }

    if (reviewCount && (isNaN(reviewCount) || reviewCount < 0)) {
      return NextResponse.json(
        { error: "Review count must be a non-negative number" },
        { status: 400 }
      )
    }

    // Check if slug already exists
    const existingProduct = await prisma.product.findUnique({
      where: { slug }
    })

    if (existingProduct) {
      return NextResponse.json(
        { error: "A product with this slug already exists" },
        { status: 409 }
      )
    }

    // Create new product
    const newProduct = await prisma.product.create({
      data: {
        name,
        slug,
        category: body.category || null,
        price: parseFloat(priceValue),
        originalPrice: originalPrice ? parseFloat(originalPrice) : null,
        stock: parseInt(stockValue),
        sold: sold ? parseInt(sold) : 0,
        rating: rating ? parseFloat(rating) : null,
        reviewCount: reviewCount ? parseInt(reviewCount) : null,
        status,
        featured: body.featured || false,
        badge: body.badge || null,
        image: body.image || null,
        images: body.images || null,
        description: body.description || null,
        features: body.features || null,
        sizes: body.sizes || null,
        colors: body.colors || null,
        tags: body.tags || null
      }
    })

    return NextResponse.json(newProduct, { status: 201 })
  } catch (error) {
    console.error("Error creating product:", error)
    return NextResponse.json({ error: "Failed to create product" }, { status: 500 })
  }
}
