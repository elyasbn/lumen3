import { NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { prisma } from "@/lib/prisma"

export async function POST(req: Request) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) {
    return NextResponse.json({ message: "Unauthorized" }, { status: 401 })
  }
  const body = await req.json().catch(() => null)
  const { goals, experience, preferences } = body || {}
  if (!goals || !experience) {
    return NextResponse.json({ message: "Missing required fields" }, { status: 400 })
  }
  const created = await (prisma as any).workoutRequest.create({
    data: {
      userId: Number(session.user.id),
      goals,
      experience,
      preferences,
    },
    select: { id: true },
  })
  return NextResponse.json({ id: created.id, message: "Created" }, { status: 201 })
}


