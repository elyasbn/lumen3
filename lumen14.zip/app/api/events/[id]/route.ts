import { NextResponse } from "next/server"
import { PrismaClient } from "@prisma/client"

const prisma = new PrismaClient()

export async function PUT(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const eventId = parseInt(params.id)
    
    if (isNaN(eventId)) {
      return NextResponse.json(
        { error: "Invalid event ID" },
        { status: 400 }
      )
    }

    const body = await request.json()
    
    // Validate required fields
    const { title, slug, date, status } = body
    
    if (!title || !slug || !date || !status) {
      return NextResponse.json(
        { error: "Missing required fields: title, slug, date, and status are required" },
        { status: 400 }
      )
    }

    // Validate date format
    const eventDate = new Date(date)
    if (isNaN(eventDate.getTime())) {
      return NextResponse.json(
        { error: "Invalid date format" },
        { status: 400 }
      )
    }

    // Validate numeric fields
    const { capacity, registered, price } = body
    
    if (capacity && (isNaN(capacity) || capacity <= 0)) {
      return NextResponse.json(
        { error: "Capacity must be a positive number" },
        { status: 400 }
      )
    }

    if (registered && (isNaN(registered) || registered < 0)) {
      return NextResponse.json(
        { error: "Registered count must be a non-negative number" },
        { status: 400 }
      )
    }

    if (price && (isNaN(price) || price < 0)) {
      return NextResponse.json(
        { error: "Price must be a non-negative number" },
        { status: 400 }
      )
    }

    // Check if event exists
    const existingEvent = await prisma.event.findUnique({
      where: { id: eventId }
    })

    if (!existingEvent) {
      return NextResponse.json(
        { error: "Event not found" },
        { status: 404 }
      )
    }

    // Check if slug is unique (excluding current event)
    const slugExists = await prisma.event.findFirst({
      where: { 
        slug,
        id: { not: eventId }
      }
    })

    if (slugExists) {
      return NextResponse.json(
        { error: "An event with this slug already exists" },
        { status: 409 }
      )
    }

    // Update event
    const updatedEvent = await prisma.event.update({
      where: { id: eventId },
      data: {
        title,
        slug,
        date: eventDate,
        time: body.time || null,
        endTime: body.endTime || null,
        location: body.location || null,
        address: body.address || null,
        type: body.type || null,
        capacity: capacity ? parseInt(capacity) : null,
        registered: registered ? parseInt(registered) : null,
        price: price ? parseFloat(price) : null,
        status,
        featured: body.featured || false,
        description: body.description || null,
        image: body.image || null,
        instructors: body.instructors || null,
        tags: body.tags || null
      }
    })

    return NextResponse.json(updatedEvent)
  } catch (error) {
    console.error("Error updating event:", error)
    return NextResponse.json({ error: "Failed to update event" }, { status: 500 })
  }
}

export async function DELETE(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const eventId = parseInt(params.id)
    
    if (isNaN(eventId)) {
      return NextResponse.json(
        { error: "Invalid event ID" },
        { status: 400 }
      )
    }

    // Check if event exists
    const existingEvent = await prisma.event.findUnique({
      where: { id: eventId }
    })

    if (!existingEvent) {
      return NextResponse.json(
        { error: "Event not found" },
        { status: 404 }
      )
    }

    // Delete event
    await prisma.event.delete({
      where: { id: eventId }
    })

    return NextResponse.json({ message: "Event deleted successfully" })
  } catch (error) {
    console.error("Error deleting event:", error)
    return NextResponse.json({ error: "Failed to delete event" }, { status: 500 })
  }
}
