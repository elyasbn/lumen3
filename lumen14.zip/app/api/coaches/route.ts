import { NextResponse } from "next/server"
import { PrismaClient } from "@prisma/client"

const prisma = new PrismaClient()

export async function GET() {
  try {
    const coaches = await prisma.coach.findMany({
      orderBy: {
        joinedAt: 'desc'
      }
    })
    return NextResponse.json(coaches)
  } catch (error) {
    console.error("Error fetching coaches:", error)
    return NextResponse.json({ error: "Failed to load coaches" }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()
    
    // Validate required fields
    const { name, email, status, joinedAt } = body
    
    if (!name || !email || !status || !joinedAt) {
      return NextResponse.json(
        { error: "Missing required fields: name, email, status, and joinedAt are required" },
        { status: 400 }
      )
    }

    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if (!emailRegex.test(email)) {
      return NextResponse.json(
        { error: "Invalid email format" },
        { status: 400 }
      )
    }

    // Validate numeric fields
    const { rating, students } = body
    
    if (rating && (isNaN(rating) || rating < 0 || rating > 5)) {
      return NextResponse.json(
        { error: "Rating must be a number between 0 and 5" },
        { status: 400 }
      )
    }

    if (students && (isNaN(students) || students < 0)) {
      return NextResponse.json(
        { error: "Students count must be a non-negative number" },
        { status: 400 }
      )
    }

    // Check if email already exists
    const existingCoach = await prisma.coach.findFirst({
      where: { email }
    })

    if (existingCoach) {
      return NextResponse.json(
        { error: "A coach with this email already exists" },
        { status: 409 }
      )
    }

    // Create new coach
    const newCoach = await prisma.coach.create({
      data: {
        name,
        email,
        phone: body.phone || null,
        specialties: body.specialties || null,
        experience: body.experience || null,
        rating: rating ? parseFloat(rating) : null,
        students: students ? parseInt(students) : null,
        status,
        avatar: body.avatar || null,
        bio: body.bio || null,
        certifications: body.certifications || null,
        joinedAt: new Date(joinedAt),
        socialMedia: body.socialMedia || null
      }
    })

    return NextResponse.json(newCoach, { status: 201 })
  } catch (error) {
    console.error("Error creating coach:", error)
    return NextResponse.json({ error: "Failed to create coach" }, { status: 500 })
  }
}
