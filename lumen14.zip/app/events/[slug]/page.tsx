"use client"

import { useEffect, useState } from "react"
import { useParams } from "next/navigation"
import Link from "next/link"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Calendar, Clock, MapPin, DollarSign, ArrowLeft, ImageIcon } from "lucide-react"

type EventItem = {
  id: number
  title: string
  slug: string
  date: string
  time?: string
  endTime?: string
  location?: string
  address?: string
  type?: string
  price?: number
  status: string
  description?: string
  image?: string
}

export default function EventSinglePage() {
  const params = useParams<{ slug: string }>()
  const [event, setEvent] = useState<EventItem | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const load = async () => {
      try {
        setLoading(true)
        const res = await fetch(`/api/events`)
        if (!res.ok) throw new Error("Failed to load events")
        const list: EventItem[] = await res.json()
        const found = list.find((e) => e.slug === params.slug)
        if (!found) throw new Error("Event not found")
        setEvent(found)
      } catch (e) {
        setError(e instanceof Error ? e.message : "Failed to load event")
      } finally {
        setLoading(false)
      }
    }
    if (params?.slug) load()
  }, [params])

  const statusBadge = (status: string) => {
    switch (status) {
      case "upcoming":
        return <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-100">Upcoming</Badge>
      case "completed":
        return <Badge variant="secondary">Completed</Badge>
      case "cancelled":
        return <Badge variant="destructive">Cancelled</Badge>
      default:
        return <Badge variant="outline">{status}</Badge>
    }
  }

  return (
    <div className="py-16">
      <div className="container mx-auto px-4">
        <div className="mb-6">
          <Link href="/events">
            <Button variant="ghost" className="px-0">
              <ArrowLeft className="h-4 w-4 mr-2" /> Back to Events
            </Button>
          </Link>
        </div>

        {loading ? (
          <div className="text-center">Loading event...</div>
        ) : error ? (
          <div className="text-center text-red-600">{error}</div>
        ) : !event ? (
          <div className="text-center text-muted-foreground">Event not found.</div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
            <div className="lg:col-span-2">
              <div className="w-full h-80 bg-muted flex items-center justify-center overflow-hidden rounded-lg">
                {event.image ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={event.image} alt={event.title} className="w-full h-full object-cover" />
                ) : (
                  <ImageIcon className="h-10 w-10 text-muted-foreground" />
                )}
              </div>

              <h1 className="text-4xl font-bold mt-6">{event.title}</h1>
              <div className="flex flex-wrap items-center gap-3 mt-3">
                {statusBadge(event.status)}
                <span className="flex items-center gap-1"><Calendar className="h-4 w-4" />{new Date(event.date).toLocaleDateString()}</span>
                {event.time && <span className="flex items-center gap-1"><Clock className="h-4 w-4" />{event.time}</span>}
                {event.location && <span className="flex items-center gap-1"><MapPin className="h-4 w-4" />{event.location}</span>}
                <span className="flex items-center gap-1"><DollarSign className="h-4 w-4" />{event.price ? event.price.toFixed(2) : "Free"}</span>
              </div>

              <div className="prose prose-neutral max-w-none mt-6">
                <p>{event.description || "No description provided."}</p>
              </div>
            </div>

            <aside className="space-y-4">
              <div className="p-4 border rounded-lg">
                <h2 className="font-semibold mb-2">Attend this event</h2>
                <Button className="w-full">Register</Button>
              </div>
              <div className="p-4 border rounded-lg">
                <h2 className="font-semibold mb-2">Share</h2>
                <div className="text-sm text-muted-foreground">Share this event with your friends.</div>
              </div>
            </aside>
          </div>
        )}
      </div>
    </div>
  )
}


