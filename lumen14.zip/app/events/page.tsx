"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Calendar, Clock, MapPin, DollarSign, ImageIcon } from "lucide-react"

type EventItem = {
  id: number
  title: string
  slug: string
  date: string
  time?: string
  endTime?: string
  location?: string
  type?: string
  price?: number
  status: string
  description?: string
  image?: string
}

export default function EventsArchivePage() {
  const [events, setEvents] = useState<EventItem[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const load = async () => {
      try {
        setLoading(true)
        const res = await fetch("/api/events")
        if (!res.ok) throw new Error("Failed to load events")
        const data: EventItem[] = await res.json()
        setEvents(data)
      } catch (e) {
        setError(e instanceof Error ? e.message : "Failed to load events")
      } finally {
        setLoading(false)
      }
    }
    load()
  }, [])

  const statusBadge = (status: string) => {
    switch (status) {
      case "upcoming":
        return <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-100">Upcoming</Badge>
      case "completed":
        return <Badge variant="secondary">Completed</Badge>
      case "cancelled":
        return <Badge variant="destructive">Cancelled</Badge>
      default:
        return <Badge variant="outline">{status}</Badge>
    }
  }

  return (
    <div className="py-16">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <span className="text-[#949f7d] font-medium text-lg">Events</span>
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mt-2">All Events</h1>
          <p className="text-gray-600 max-w-2xl mx-auto mt-3">Browse all studio events, workshops, and performances.</p>
        </div>

        {loading ? (
          <div className="text-center">Loading events...</div>
        ) : error ? (
          <div className="text-center text-red-600">{error}</div>
        ) : events.length === 0 ? (
          <div className="text-center text-muted-foreground">No events found.</div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {events.map((event) => (
              <Card key={event.id} className="group hover:shadow-lg transition-all border-0 shadow-sm">
                <Link href={`/events/${event.slug}`}>
                  <div className="w-full h-48 bg-muted flex items-center justify-center overflow-hidden">
                    {event.image ? (
                      // eslint-disable-next-line @next/next/no-img-element
                      <img src={event.image} alt={event.title} className="w-full h-full object-cover" />
                    ) : (
                      <ImageIcon className="h-8 w-8 text-muted-foreground" />
                    )}
                  </div>
                </Link>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-xl">
                      <Link href={`/events/${event.slug}`}>{event.title}</Link>
                    </CardTitle>
                    {statusBadge(event.status)}
                  </div>
                  <CardDescription className="flex flex-wrap items-center gap-3 mt-2">
                    <span className="flex items-center gap-1"><Calendar className="h-4 w-4" />{new Date(event.date).toLocaleDateString()}</span>
                    {event.time && <span className="flex items-center gap-1"><Clock className="h-4 w-4" />{event.time}</span>}
                    {event.location && <span className="flex items-center gap-1"><MapPin className="h-4 w-4" />{event.location}</span>}
                    <span className="flex items-center gap-1"><DollarSign className="h-4 w-4" />{event.price ? event.price.toFixed(2) : "Free"}</span>
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground line-clamp-2">{event.description || "No description."}</p>
                  <div className="mt-4">
                    <Link href={`/events/${event.slug}`}>
                      <Button variant="outline" className="bg-transparent">View Details</Button>
                    </Link>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}


