import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import { Providers } from "@/components/providers/session-provider"
import WhatsAppButton from "@/components/whatsapp-button"

const inter = Inter({
  subsets: ["latin"],
  display: "swap",
  variable: "--font-inter",
})

export const metadata: Metadata = {
  title: "Lumen Studio - Dance & Sport",
  description:
    "Professional dance studio offering belly dance, khaleej dance, latina dance, ballet, zumba, and more. Expert instructors, modern facilities, and a welcoming community.",
  keywords: "dance studio, belly dance, khaleej dance, latina dance, ballet, zumba, fitness, Qatar, West Bay",
  authors: [{ name: "Lumen Studio" }],
  creator: "Lumen Studio",
  publisher: "Lumen Studio",
  openGraph: {
    title: "Lumen Studio - Dance & Sport",
    description: "Professional dance studio offering expert instruction in various dance styles",
    url: "https://lumenstudio.com",
    siteName: "Lumen Studio",
    images: [
      {
        url: "https://images.unsplash.com/photo-1518310383802-640c2de311b2?q=80&w=1170&auto=format&fit=crop",
        width: 1170,
        height: 780,
        alt: "Lumen Dance Studio",
      },
    ],
    locale: "en_US",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Lumen Studio - Dance & Sport",
    description: "Professional dance studio offering expert instruction in various dance styles",
    images: ["https://images.unsplash.com/photo-1518310383802-640c2de311b2?q=80&w=1170&auto=format&fit=crop"],
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-video-preview": -1,
      "max-image-preview": "large",
      "max-snippet": -1,
    },
  },
  verification: {
    google: "your-google-verification-code",
  },
    generator: 'v0.app'
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className={inter.variable}>
      <body className={`${inter.className} antialiased`}>
        <Providers>
          {children}
          <WhatsAppButton />
        </Providers>
      </body>
    </html>
  )
}
