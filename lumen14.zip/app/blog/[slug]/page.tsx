"use client"

import { useState, useEffect } from "react"
import { ChevronLeft, ChevronRight, Clock, Calendar, Heart, Facebook, Twitter, Linkedin, ArrowUp } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import Image from "next/image"
import Link from "next/link"
import { useParams } from "next/navigation"

interface BlogPost {
  id: number
  title: string
  slug: string
  content: string | null
  excerpt: string | null
  author: string
  authorId: number
  publishedAt: string
  updatedAt: string
  status: string
  category: string | null
  tags: string[] | null
  readTime: string | null
  views: number
  featured: boolean
  image: string | null
  seo: any
}

interface RelatedPost {
  id: number
  title: string
  slug: string
  image: string | null
  excerpt: string | null
  publishedAt: string
}

export default function BlogPostPage() {
  const params = useParams()
  const slug = params.slug as string
  
  const [showBackToTop, setShowBackToTop] = useState(false)
  const [liked, setLiked] = useState(false)
  const [blogPost, setBlogPost] = useState<BlogPost | null>(null)
  const [relatedPosts, setRelatedPosts] = useState<RelatedPost[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const fetchBlogPost = async () => {
      try {
        setLoading(true)
        const response = await fetch('/api/blog')
        if (!response.ok) {
          throw new Error('Failed to fetch blog posts')
        }
        const posts: BlogPost[] = await response.json()
        const post = posts.find(p => p.slug === slug)
        
        if (!post) {
          setError('Blog post not found')
          return
        }
        
        setBlogPost(post)
        
        // Get related posts (exclude current post)
        const related = posts
          .filter(p => p.id !== post.id && p.status === 'published')
          .slice(0, 3)
          .map(p => ({
            id: p.id,
            title: p.title,
            slug: p.slug,
            image: p.image,
            excerpt: p.excerpt,
            publishedAt: p.publishedAt
          }))
        setRelatedPosts(related)
      } catch (err) {
        setError(err instanceof Error ? err.message : 'An error occurred')
      } finally {
        setLoading(false)
      }
    }

    if (slug) {
      fetchBlogPost()
    }
  }, [slug])

  useEffect(() => {
    const handleScroll = () => {
      setShowBackToTop(window.scrollY > 300)
    }
    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" })
  }

  const shareUrl = typeof window !== "undefined" ? window.location.href : ""

  // Loading state
  if (loading) {
    return (
      <div className="min-h-screen bg-white">
        <Header />
        <div className="container mx-auto px-4 py-16">
          <div className="max-w-4xl mx-auto">
            <div className="animate-pulse">
              <div className="h-96 bg-gray-200 rounded-lg mb-8"></div>
              <div className="h-8 bg-gray-200 rounded mb-4"></div>
              <div className="h-4 bg-gray-200 rounded mb-2"></div>
              <div className="h-4 bg-gray-200 rounded mb-2"></div>
              <div className="h-4 bg-gray-200 rounded w-3/4"></div>
            </div>
          </div>
        </div>
        <Footer />
      </div>
    )
  }

  // Error state
  if (error || !blogPost) {
    return (
      <div className="min-h-screen bg-white">
        <Header />
        <div className="container mx-auto px-4 py-16">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl font-bold text-gray-900 mb-4">Blog Post Not Found</h1>
            <p className="text-gray-600 mb-8">{error || "The blog post you're looking for doesn't exist."}</p>
            <Link href="/blog">
              <Button className="bg-[#949f7d] hover:bg-[#949f7d]/90 text-white">
                Back to Blog
              </Button>
            </Link>
          </div>
        </div>
        <Footer />
      </div>
    )
  }

  // Format date
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    })
  }

  return (
    <div className="min-h-screen bg-white">
      <Header />

      {/* Hero Section */}
      <section className="relative h-96 overflow-hidden">
        <Image 
          src={blogPost.image || "/placeholder.svg"} 
          alt={blogPost.title} 
          fill 
          className="object-cover" 
          priority 
        />
        <div className="absolute inset-0 bg-black/50"></div>
        <div className="absolute inset-0 flex items-end">
          <div className="container mx-auto px-4 pb-8">
            <nav className="text-sm text-white/80 mb-4">
              <Link href="/" className="hover:text-white transition-colors">
                Home
              </Link>
              <span className="mx-2">&gt;</span>
              <Link href="/blog" className="hover:text-white transition-colors">
                Blog
              </Link>
              <span className="mx-2">&gt;</span>
              <span className="text-[#e5d5bc]">{blogPost.title}</span>
            </nav>
            {blogPost.category && (
              <div className="bg-[#949f7d] text-white px-3 py-1 rounded-full text-sm font-medium inline-block mb-4">
                {blogPost.category}
              </div>
            )}
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-4 max-w-4xl">{blogPost.title}</h1>
            <div className="flex items-center space-x-6 text-white/90">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-white/20 rounded-full flex items-center justify-center">
                  <span className="text-sm font-medium">{blogPost.author.charAt(0)}</span>
                </div>
                <span>{blogPost.author}</span>
              </div>
              <div className="flex items-center space-x-1">
                <Calendar className="w-4 h-4" />
                <span>{formatDate(blogPost.publishedAt)}</span>
              </div>
              {blogPost.readTime && (
                <div className="flex items-center space-x-1">
                  <Clock className="w-4 h-4" />
                  <span>{blogPost.readTime}</span>
                </div>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Article Content */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="grid grid-cols-1 lg:grid-cols-4 gap-12">
              {/* Main Content */}
              <div className="lg:col-span-3">
                <div className="prose prose-lg max-w-none">
                  <div
                    dangerouslySetInnerHTML={{ __html: blogPost.content || '' }}
                    className="text-gray-700 leading-relaxed"
                  />
                </div>

                {/* Tags */}
                {blogPost.tags && blogPost.tags.length > 0 && (
                  <div className="mt-12 pt-8 border-t border-gray-200">
                    <h3 className="text-lg font-semibold text-gray-900 mb-4">Tags</h3>
                    <div className="flex flex-wrap gap-2">
                      {blogPost.tags.map((tag) => (
                        <span
                          key={tag}
                          className="px-3 py-1 bg-gray-100 text-gray-700 rounded-full text-sm hover:bg-[#949f7d] hover:text-white transition-colors cursor-pointer"
                        >
                          #{tag}
                        </span>
                      ))}
                    </div>
                  </div>
                )}

                {/* Author Bio */}
                <div className="mt-12 p-6 bg-[#e5d5bc]/10 rounded-lg">
                  <div className="flex items-start space-x-4">
                    <div className="w-20 h-20 bg-[#949f7d] rounded-full flex items-center justify-center">
                      <span className="text-2xl font-bold text-white">{blogPost.author.charAt(0)}</span>
                    </div>
                    <div>
                      <h3 className="text-xl font-bold text-gray-900 mb-2">About {blogPost.author}</h3>
                      <p className="text-gray-600">
                        {blogPost.excerpt || `Read more from ${blogPost.author} and discover their insights on dance and movement.`}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Navigation */}
                <div className="mt-12 flex justify-between items-center">
                  <Link href="/blog">
                    <Button
                      variant="outline"
                      className="border-[#949f7d] text-[#949f7d] hover:bg-[#949f7d] hover:text-white bg-transparent"
                    >
                      <ChevronLeft className="w-4 h-4 mr-2" />
                      Back to Blog
                    </Button>
                  </Link>
                  <div className="flex space-x-4">
                    <Button
                      variant="outline"
                      className="border-[#949f7d] text-[#949f7d] hover:bg-[#949f7d] hover:text-white bg-transparent"
                    >
                      <ChevronLeft className="w-4 h-4 mr-2" />
                      Previous Post
                    </Button>
                    <Button
                      variant="outline"
                      className="border-[#949f7d] text-[#949f7d] hover:bg-[#949f7d] hover:text-white bg-transparent"
                    >
                      Next Post
                      <ChevronRight className="w-4 h-4 ml-2" />
                    </Button>
                  </div>
                </div>
              </div>

              {/* Sidebar */}
              <div className="lg:col-span-1">
                <div className="sticky top-24 space-y-8">
                  {/* Social Share */}
                  <Card className="p-6">
                    <h3 className="font-bold text-gray-900 mb-4">Share This Post</h3>
                    <div className="space-y-3">
                      <Button
                        variant="outline"
                        className="w-full justify-start border-blue-200 text-blue-600 hover:bg-blue-50 bg-transparent"
                        onClick={() => window.open(`https://facebook.com/sharer/sharer.php?u=${shareUrl}`, "_blank")}
                      >
                        <Facebook className="w-4 h-4 mr-2" />
                        Facebook
                      </Button>
                      <Button
                        variant="outline"
                        className="w-full justify-start border-blue-400 text-blue-500 hover:bg-blue-50 bg-transparent"
                        onClick={() =>
                          window.open(
                            `https://twitter.com/intent/tweet?url=${shareUrl}&text=${blogPost.title}`,
                            "_blank",
                          )
                        }
                      >
                        <Twitter className="w-4 h-4 mr-2" />
                        Twitter
                      </Button>
                      <Button
                        variant="outline"
                        className="w-full justify-start border-blue-700 text-blue-700 hover:bg-blue-50 bg-transparent"
                        onClick={() =>
                          window.open(`https://linkedin.com/sharing/share-offsite/?url=${shareUrl}`, "_blank")
                        }
                      >
                        <Linkedin className="w-4 h-4 mr-2" />
                        LinkedIn
                      </Button>
                    </div>
                  </Card>

                  {/* Like Button */}
                  <Card className="p-6 text-center">
                    <Button
                      onClick={() => setLiked(!liked)}
                      className={`w-full ${liked ? "bg-red-500 hover:bg-red-600" : "bg-gray-100 hover:bg-gray-200 text-gray-700"}`}
                    >
                      <Heart className={`w-4 h-4 mr-2 ${liked ? "fill-current" : ""}`} />
                      {liked ? "Liked!" : "Like This Post"}
                    </Button>
                  </Card>

                  {/* Newsletter Signup */}
                  <Card className="p-6">
                    <h3 className="font-bold text-gray-900 mb-4">Stay Updated</h3>
                    <p className="text-gray-600 text-sm mb-4">
                      Get the latest dance tips and studio news delivered to your inbox.
                    </p>
                    <div className="space-y-3">
                      <Input
                        placeholder="Your email"
                        className="border-gray-300 focus:border-[#949f7d] focus:ring-[#949f7d]"
                      />
                      <Button className="w-full bg-[#949f7d] hover:bg-[#949f7d]/90 text-white">Subscribe</Button>
                    </div>
                  </Card>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Related Posts */}
      {relatedPosts.length > 0 && (
        <section className="py-16 bg-[#e5d5bc]/10">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-gray-900 text-center mb-12">Related Posts</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
              {relatedPosts.map((post) => (
                <Card key={post.id} className="group hover:shadow-xl transition-all duration-300 border-0 shadow-lg">
                  <div className="relative overflow-hidden rounded-t-lg">
                    <Image
                      src={post.image || "/placeholder.svg"}
                      alt={post.title}
                      width={300}
                      height={200}
                      className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                  </div>
                  <CardContent className="p-6">
                    <Link href={`/blog/${post.slug}`}>
                      <h3 className="font-bold text-lg text-gray-900 group-hover:text-[#949f7d] transition-colors cursor-pointer line-clamp-2">
                        {post.title}
                      </h3>
                    </Link>
                    {post.excerpt && (
                      <p className="text-gray-600 text-sm mt-2 line-clamp-2">{post.excerpt}</p>
                    )}
                    <Link href={`/blog/${post.slug}`}>
                      <Button
                        variant="ghost"
                        className="text-[#949f7d] hover:text-[#949f7d]/80 p-0 h-auto font-medium mt-3"
                      >
                        Read More →
                      </Button>
                    </Link>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Back to Top Button */}
      {showBackToTop && (
        <button
          onClick={scrollToTop}
          className="fixed bottom-8 right-8 z-50 bg-[#949f7d] hover:bg-[#949f7d]/90 text-white p-3 rounded-full shadow-lg transition-all duration-300"
        >
          <ArrowUp className="w-5 h-5" />
        </button>
      )}

      <Footer />
    </div>
  )
}
