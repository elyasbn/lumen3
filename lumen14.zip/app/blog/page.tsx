"use client"

import { useState, useEffect } from "react"
import { Search, Clock, ChevronLeft, ChevronRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import Image from "next/image"
import Link from "next/link"

interface BlogPost {
  id: number
  title: string
  slug: string
  content: string | null
  excerpt: string | null
  author: string
  authorId: number
  publishedAt: string
  updatedAt: string
  status: string
  category: string | null
  tags: string[] | null
  readTime: string | null
  views: number
  featured: boolean
  image: string | null
  seo: any
}

export default function BlogPage() {
  const [selectedCategory, setSelectedCategory] = useState("All Posts")
  const [searchQuery, setSearchQuery] = useState("")
  const [currentPage, setCurrentPage] = useState(1)
  const [blogPosts, setBlogPosts] = useState<BlogPost[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const postsPerPage = 6

  useEffect(() => {
    const fetchBlogPosts = async () => {
      try {
        setLoading(true)
        const response = await fetch('/api/blog')
        if (!response.ok) {
          throw new Error('Failed to fetch blog posts')
        }
        const posts: BlogPost[] = await response.json()
        setBlogPosts(posts)
      } catch (err) {
        setError(err instanceof Error ? err.message : 'An error occurred')
      } finally {
        setLoading(false)
      }
    }

    fetchBlogPosts()
  }, [])

  // Get unique categories from posts
  const categories = ["All Posts", ...Array.from(new Set(blogPosts.map(post => post.category).filter(Boolean)))]

  const filteredPosts = blogPosts.filter((post) => {
    const matchesCategory = selectedCategory === "All Posts" || post.category === selectedCategory
    const matchesSearch =
      post.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (post.excerpt && post.excerpt.toLowerCase().includes(searchQuery.toLowerCase()))
    return matchesCategory && matchesSearch && post.status === 'published'
  })

  const totalPages = Math.ceil(filteredPosts.length / postsPerPage)
  const startIndex = (currentPage - 1) * postsPerPage
  const currentPosts = filteredPosts.slice(startIndex, startIndex + postsPerPage)

  const getCategoryColor = (category: string | null) => {
    switch (category) {
      case "Dance Tips":
        return "bg-[#949f7d] text-white"
      case "Studio News":
        return "bg-blue-500 text-white"
      case "Health & Fitness":
        return "bg-green-500 text-white"
      case "Events":
        return "bg-purple-500 text-white"
      default:
        return "bg-gray-500 text-white"
    }
  }

  // Format date
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    })
  }

  // Loading state
  if (loading) {
    return (
      <div className="min-h-screen bg-white">
        <Header />
        <section className="py-20 bg-gradient-to-br from-[#e5d5bc]/20 to-white">
          <div className="container mx-auto px-4">
            <div className="text-center mb-8">
              <h1 className="text-5xl md:text-6xl font-bold text-gray-900 mb-4">Our Blog</h1>
              <p className="text-xl text-gray-600 max-w-2xl mx-auto">Dance Tips, Stories & Inspiration</p>
            </div>
          </div>
        </section>
        <section className="py-16">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {Array.from({ length: 6 }).map((_, i) => (
                <Card key={i} className="border-0 shadow-lg">
                  <div className="animate-pulse">
                    <div className="h-64 bg-gray-200 rounded-t-lg"></div>
                    <CardContent className="p-6">
                      <div className="h-4 bg-gray-200 rounded mb-2"></div>
                      <div className="h-4 bg-gray-200 rounded mb-2"></div>
                      <div className="h-4 bg-gray-200 rounded w-3/4 mb-4"></div>
                      <div className="h-3 bg-gray-200 rounded mb-2"></div>
                      <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                    </CardContent>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        </section>
        <Footer />
      </div>
    )
  }

  // Error state
  if (error) {
    return (
      <div className="min-h-screen bg-white">
        <Header />
        <section className="py-20 bg-gradient-to-br from-[#e5d5bc]/20 to-white">
          <div className="container mx-auto px-4 text-center">
            <h1 className="text-5xl md:text-6xl font-bold text-gray-900 mb-4">Our Blog</h1>
            <p className="text-xl text-red-600 mb-8">{error}</p>
            <Button 
              onClick={() => window.location.reload()} 
              className="bg-[#949f7d] hover:bg-[#949f7d]/90 text-white"
            >
              Try Again
            </Button>
          </div>
        </section>
        <Footer />
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-white">
      <Header />

      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-br from-[#e5d5bc]/20 to-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-8">
            <nav className="text-sm text-gray-600 mb-4">
              <Link href="/" className="hover:text-[#949f7d] transition-colors">
                Home
              </Link>
              <span className="mx-2">&gt;</span>
              <span className="text-[#949f7d]">Blog</span>
            </nav>
            <h1 className="text-5xl md:text-6xl font-bold text-gray-900 mb-4">Our Blog</h1>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">Dance Tips, Stories & Inspiration</p>
          </div>

          {/* Search Bar */}
          <div className="max-w-md mx-auto mb-8">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <Input
                placeholder="Search articles..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 border-gray-300 focus:border-[#949f7d] focus:ring-[#949f7d]"
              />
            </div>
          </div>

          {/* Category Filters */}
          <div className="flex flex-wrap justify-center gap-4 mb-12">
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => {
                  setSelectedCategory(category)
                  setCurrentPage(1)
                }}
                className={`px-6 py-2 rounded-full font-medium transition-all ${
                  selectedCategory === category
                    ? "bg-[#949f7d] text-white shadow-lg"
                    : "bg-white text-gray-600 hover:bg-gray-50 border border-gray-200"
                }`}
              >
                {category}
              </button>
            ))}
          </div>
        </div>
      </section>

          {/* Blog Grid */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          {currentPosts.length === 0 ? (
            <div className="text-center py-16">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">No posts found</h2>
              <p className="text-gray-600 mb-8">
                {searchQuery ? `No posts match your search for "${searchQuery}"` : "No blog posts are available at the moment."}
              </p>
              {searchQuery && (
                <Button 
                  onClick={() => setSearchQuery("")}
                  className="bg-[#949f7d] hover:bg-[#949f7d]/90 text-white"
                >
                  Clear Search
                </Button>
              )}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
              {currentPosts.map((post) => (
              <Card key={post.id} className="group hover:shadow-xl transition-all duration-300 border-0 shadow-lg">
                <div className="relative overflow-hidden rounded-t-lg">
                  <Image
                    src={post.image || "/placeholder.svg"}
                    alt={post.title}
                    width={400}
                    height={300}
                    className="w-full h-64 object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-colors duration-300"></div>
                  {post.category && (
                    <div
                      className={`absolute top-4 left-4 px-3 py-1 rounded-full text-sm font-medium ${getCategoryColor(post.category)}`}
                    >
                      {post.category}
                    </div>
                  )}
                </div>
                <CardContent className="p-6">
                  <div className="flex items-center space-x-4 mb-3 text-sm text-gray-500">
                    <div className="flex items-center space-x-2">
                      <div className="w-6 h-6 bg-[#949f7d] rounded-full flex items-center justify-center">
                        <span className="text-xs font-medium text-white">{post.author.charAt(0)}</span>
                      </div>
                      <span>{post.author}</span>
                    </div>
                    <span>•</span>
                    <span>{formatDate(post.publishedAt)}</span>
                  </div>

                  <Link href={`/blog/${post.slug}`}>
                    <h3 className="font-bold text-xl text-gray-900 mb-3 line-clamp-2 group-hover:text-[#949f7d] transition-colors cursor-pointer">
                      {post.title}
                    </h3>
                  </Link>

                  <p className="text-gray-600 mb-4 line-clamp-3">{post.excerpt || "Read more about this topic..."}</p>

                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-1 text-sm text-gray-500">
                      <Clock className="w-4 h-4" />
                      <span>{post.readTime || "5 min read"}</span>
                    </div>
                    <Link href={`/blog/${post.slug}`}>
                      <Button variant="ghost" className="text-[#949f7d] hover:text-[#949f7d]/80 p-0 h-auto font-medium">
                        Read More →
                      </Button>
                    </Link>
                  </div>
                </CardContent>
              </Card>
              ))}
            </div>
          )}

          {/* Pagination */}
          {totalPages > 1 && (
            <div className="flex items-center justify-center space-x-2">
              <Button
                variant="outline"
                onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
                disabled={currentPage === 1}
                className="border-[#949f7d] text-[#949f7d] hover:bg-[#949f7d] hover:text-white"
              >
                <ChevronLeft className="w-4 h-4 mr-1" />
                Previous
              </Button>

              {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
                <Button
                  key={page}
                  variant={currentPage === page ? "default" : "outline"}
                  onClick={() => setCurrentPage(page)}
                  className={
                    currentPage === page
                      ? "bg-[#949f7d] hover:bg-[#949f7d]/90 text-white"
                      : "border-[#949f7d] text-[#949f7d] hover:bg-[#949f7d] hover:text-white"
                  }
                >
                  {page}
                </Button>
              ))}

              <Button
                variant="outline"
                onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
                disabled={currentPage === totalPages}
                className="border-[#949f7d] text-[#949f7d] hover:bg-[#949f7d] hover:text-white"
              >
                Next
                <ChevronRight className="w-4 h-4 ml-1" />
              </Button>
            </div>
          )}
        </div>
      </section>

      {/* Newsletter Section */}
      <section className="py-16 bg-[#e5d5bc]/10">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Stay Updated</h2>
          <p className="text-gray-600 mb-8 max-w-2xl mx-auto">
            Subscribe to our newsletter for the latest dance tips, studio news, and exclusive content delivered to your
            inbox.
          </p>
          <div className="max-w-md mx-auto flex space-x-4">
            <Input
              placeholder="Your email address"
              className="flex-1 border-gray-300 focus:border-[#949f7d] focus:ring-[#949f7d]"
            />
            <Button className="bg-[#949f7d] hover:bg-[#949f7d]/90 text-white">Subscribe</Button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  )
}
