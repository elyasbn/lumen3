"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { MapPin, Phone, Mail, Clock, ArrowUp, Send, CheckCircle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Card } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import Image from "next/image"
import Link from "next/link"

const faqs = [
  {
    question: "Do I need prior dance experience to join classes?",
    answer:
      "Not at all! We welcome dancers of all levels, from complete beginners to advanced performers. Our instructors are skilled at adapting their teaching to meet each student where they are.",
  },
  {
    question: "What should I wear to my first class?",
    answer:
      "Comfortable, stretchy clothing that allows for easy movement is perfect. For most classes, athletic wear or yoga clothes work well. We'll provide specific recommendations based on the class you choose.",
  },
  {
    question: "How do I book a class?",
    answer:
      "You can book classes through our online booking system, call us directly, or visit the studio in person. We recommend booking in advance as our popular classes fill up quickly.",
  },
  {
    question: "Do you offer private lessons?",
    answer:
      "Yes! We offer private and semi-private lessons for all dance styles. Private lessons are perfect for personalized attention, wedding preparation, or accelerated learning.",
  },
  {
    question: "What are your membership options?",
    answer:
      "We offer flexible membership packages including drop-in rates, class packages, and unlimited monthly memberships. Contact us to find the option that best fits your schedule and budget.",
  },
  {
    question: "Is there parking available?",
    answer:
      "Yes, we have a dedicated parking lot with plenty of free spaces for our students. Street parking is also available on the surrounding blocks.",
  },
]

const instructors = [
  {
    name: "Sofia Martinez",
    specialization: "Latina Dance",
    image: "/placeholder.svg?height=80&width=80",
  },
  {
    name: "Amira Hassan",
    specialization: "Belly Dance",
    image: "/placeholder.svg?height=80&width=80",
  },
  {
    name: "Elena Petrov",
    specialization: "Ballet",
    image: "/placeholder.svg?height=80&width=80",
  },
  {
    name: "Maria Santos",
    specialization: "Zumba",
    image: "/placeholder.svg?height=80&width=80",
  },
]

export default function ContactPage() {
  const [showBackToTop, setShowBackToTop] = useState(false)
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    subject: "",
    message: "",
  })
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSubmitted, setIsSubmitted] = useState(false)
  const [errors, setErrors] = useState<Record<string, string>>({})

  useEffect(() => {
    const handleScroll = () => {
      setShowBackToTop(window.scrollY > 300)
    }
    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" })
  }

  const validateForm = () => {
    const newErrors: Record<string, string> = {}

    if (!formData.firstName.trim()) newErrors.firstName = "First name is required"
    if (!formData.lastName.trim()) newErrors.lastName = "Last name is required"
    if (!formData.email.trim()) {
      newErrors.email = "Email is required"
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = "Please enter a valid email"
    }
    if (!formData.subject) newErrors.subject = "Please select a subject"
    if (!formData.message.trim()) newErrors.message = "Message is required"

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!validateForm()) return

    setIsSubmitting(true)

    // Simulate form submission
    await new Promise((resolve) => setTimeout(resolve, 2000))

    setIsSubmitting(false)
    setIsSubmitted(true)

    // Reset form after 3 seconds
    setTimeout(() => {
      setIsSubmitted(false)
      setFormData({
        firstName: "",
        lastName: "",
        email: "",
        phone: "",
        subject: "",
        message: "",
      })
    }, 3000)
  }

  const handleInputChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
    if (errors[field]) {
      setErrors((prev) => ({ ...prev, [field]: "" }))
    }
  }

  return (
    <div className="min-h-screen bg-white">
      <Header />

      {/* Hero Section */}
      <section className="relative h-96 overflow-hidden">
        <Image
          src="/placeholder.svg?height=400&width=1200"
          alt="Veritas Dance Studio Exterior"
          fill
          className="object-cover"
          priority
        />
        <div className="absolute inset-0 bg-black/50"></div>
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="text-center text-white">
            <nav className="text-sm text-white/80 mb-4">
              <Link href="/" className="hover:text-white transition-colors">
                Home
              </Link>
              <span className="mx-2">&gt;</span>
              <span className="text-[#e5d5bc]">Contact</span>
            </nav>
            <h1 className="text-5xl md:text-6xl font-bold mb-4">Get In Touch</h1>
            <p className="text-xl text-gray-200">We'd love to hear from you and help you start your dance journey</p>
          </div>
        </div>
      </section>

      {/* Main Contact Section */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
            {/* Contact Form */}
            <div>
              <h2 className="text-3xl font-bold text-gray-900 mb-8">Send us a message</h2>

              {isSubmitted ? (
                <Card className="p-8 text-center border-green-200 bg-green-50">
                  <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
                  <h3 className="text-2xl font-bold text-green-800 mb-2">Message Sent!</h3>
                  <p className="text-green-700">Thank you for contacting us. We'll get back to you within 24 hours.</p>
                </Card>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">First Name *</label>
                      <Input
                        placeholder="Your first name"
                        value={formData.firstName}
                        onChange={(e) => handleInputChange("firstName", e.target.value)}
                        className={`border-gray-300 focus:border-[#949f7d] focus:ring-[#949f7d] ${
                          errors.firstName ? "border-red-500" : ""
                        }`}
                      />
                      {errors.firstName && <p className="text-red-500 text-sm mt-1">{errors.firstName}</p>}
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Last Name *</label>
                      <Input
                        placeholder="Your last name"
                        value={formData.lastName}
                        onChange={(e) => handleInputChange("lastName", e.target.value)}
                        className={`border-gray-300 focus:border-[#949f7d] focus:ring-[#949f7d] ${
                          errors.lastName ? "border-red-500" : ""
                        }`}
                      />
                      {errors.lastName && <p className="text-red-500 text-sm mt-1">{errors.lastName}</p>}
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Email *</label>
                    <Input
                      type="email"
                      placeholder="your.email@example.com"
                      value={formData.email}
                      onChange={(e) => handleInputChange("email", e.target.value)}
                      className={`border-gray-300 focus:border-[#949f7d] focus:ring-[#949f7d] ${
                        errors.email ? "border-red-500" : ""
                      }`}
                    />
                    {errors.email && <p className="text-red-500 text-sm mt-1">{errors.email}</p>}
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Phone</label>
                    <Input
                      type="tel"
                      placeholder="Your phone number"
                      value={formData.phone}
                      onChange={(e) => handleInputChange("phone", e.target.value)}
                      className="border-gray-300 focus:border-[#949f7d] focus:ring-[#949f7d]"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Subject *</label>
                    <Select value={formData.subject} onValueChange={(value) => handleInputChange("subject", value)}>
                      <SelectTrigger
                        className={`border-gray-300 focus:border-[#949f7d] focus:ring-[#949f7d] ${
                          errors.subject ? "border-red-500" : ""
                        }`}
                      >
                        <SelectValue placeholder="Select a subject" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="general">General Inquiry</SelectItem>
                        <SelectItem value="classes">Class Information</SelectItem>
                        <SelectItem value="private">Private Lessons</SelectItem>
                        <SelectItem value="membership">Membership</SelectItem>
                        <SelectItem value="events">Events & Workshops</SelectItem>
                        <SelectItem value="other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                    {errors.subject && <p className="text-red-500 text-sm mt-1">{errors.subject}</p>}
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Message *</label>
                    <Textarea
                      placeholder="Tell us about your dance goals and interests..."
                      rows={5}
                      value={formData.message}
                      onChange={(e) => handleInputChange("message", e.target.value)}
                      className={`border-gray-300 focus:border-[#949f7d] focus:ring-[#949f7d] ${
                        errors.message ? "border-red-500" : ""
                      }`}
                    />
                    {errors.message && <p className="text-red-500 text-sm mt-1">{errors.message}</p>}
                  </div>

                  <Button
                    type="submit"
                    size="lg"
                    disabled={isSubmitting}
                    className="bg-[#949f7d] hover:bg-[#949f7d]/90 text-white w-full"
                  >
                    {isSubmitting ? (
                      <>
                        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                        Sending...
                      </>
                    ) : (
                      <>
                        <Send className="w-4 h-4 mr-2" />
                        Send Message
                      </>
                    )}
                  </Button>
                </form>
              )}
            </div>

            {/* Contact Information */}
            <div className="space-y-8">
              <div>
                <h2 className="text-3xl font-bold text-gray-900 mb-8">Visit our studio</h2>

                <div className="space-y-6">
                  <Card className="p-6 hover:shadow-lg transition-all duration-300">
                    <div className="flex items-start space-x-4">
                      <div className="w-12 h-12 bg-[#949f7d] rounded-full flex items-center justify-center flex-shrink-0">
                        <MapPin className="w-6 h-6 text-white" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-gray-900 text-lg mb-2">Address</h3>
                        <p className="text-gray-600">
                        West bey,Cornish,borj almana,first floor
                        </p>
                      </div>
                    </div>
                  </Card>

                  <Card className="p-6 hover:shadow-lg transition-all duration-300">
                    <div className="flex items-start space-x-4">
                      <div className="w-12 h-12 bg-[#949f7d] rounded-full flex items-center justify-center flex-shrink-0">
                        <Phone className="w-6 h-6 text-white" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-gray-900 text-lg mb-2">Phone</h3>
                        <a href="tel:+15551234567" className="text-gray-600 hover:text-[#949f7d] transition-colors">
                          +97433228254
                        </a>
                      </div>
                    </div>
                  </Card>

                  <Card className="p-6 hover:shadow-lg transition-all duration-300">
                    <div className="flex items-start space-x-4">
                      <div className="w-12 h-12 bg-[#949f7d] rounded-full flex items-center justify-center flex-shrink-0">
                        <Mail className="w-6 h-6 text-white" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-gray-900 text-lg mb-2">Email</h3>
                        <a
                          href="mailto:info@veritasdance.com"
                          className="text-gray-600 hover:text-[#949f7d] transition-colors"
                        >
                          info@lumenstudio.com
                        </a>
                      </div>
                    </div>
                  </Card>

                  <Card className="p-6 hover:shadow-lg transition-all duration-300">
                    <div className="flex items-start space-x-4">
                      <div className="w-12 h-12 bg-[#949f7d] rounded-full flex items-center justify-center flex-shrink-0">
                        <Clock className="w-6 h-6 text-white" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-gray-900 text-lg mb-2">Hours</h3>
                        <div className="text-gray-600 space-y-1">
                          <p>Monday - Friday: 6:00 AM - 10:00 PM</p>
                          <p>Saturday: 8:00 AM - 8:00 PM</p>
                          <p>Sunday: 9:00 AM - 6:00 PM</p>
                        </div>
                      </div>
                    </div>
                  </Card>
                </div>
              </div>

              {/* Getting Here */}
              <Card className="p-6">
                <h3 className="font-bold text-gray-900 text-lg mb-4">Getting Here</h3>
                <div className="space-y-3 text-gray-600">
                  <p>
                    <strong>Parking:</strong> Free parking lot available with 50+ spaces
                  </p>
                  <p>
                    <strong>Public Transit:</strong> Bus routes 12, 34, and 56 stop within 2 blocks
                  </p>
                  <p>
                    <strong>Metro:</strong> Arts District station is a 5-minute walk
                  </p>
                </div>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Map Section */}
      <section className="py-16 bg-[#e5d5bc]/10">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Find Us</h2>
            <p className="text-gray-600">Located in the heart of the Arts District</p>
          </div>

          <div className="bg-gray-200 rounded-lg h-96 flex items-center justify-center">
            <div className="text-center text-gray-500">
              <MapPin className="w-16 h-16 mx-auto mb-4" />
              <p className="text-lg font-medium">Interactive Map</p>
              <p className="text-sm">West bey,Cornish,borj almana,first floor</p>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Frequently Asked Questions</h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Find answers to common questions about our classes, policies, and studio
            </p>
          </div>

          <div className="max-w-4xl mx-auto space-y-6">
            {faqs.map((faq, index) => (
              <Card key={index} className="p-6 hover:shadow-lg transition-all duration-300">
                <h3 className="font-bold text-lg text-gray-900 mb-3">{faq.question}</h3>
                <p className="text-gray-600 leading-relaxed">{faq.answer}</p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Meet the Team Mini Section */}
      <section className="py-16 bg-[#e5d5bc]/10">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Meet Our Instructors</h2>
            <p className="text-gray-600">Our passionate team is here to guide your dance journey</p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 max-w-4xl mx-auto">
            {instructors.map((instructor, index) => (
              <div key={index} className="text-center">
                <div className="w-20 h-20 mx-auto mb-4 rounded-full overflow-hidden border-4 border-[#949f7d]/20">
                  <Image
                    src={instructor.image || "/placeholder.svg"}
                    alt={instructor.name}
                    width={80}
                    height={80}
                    className="w-full h-full object-cover"
                  />
                </div>
                <h3 className="font-semibold text-gray-900">{instructor.name}</h3>
                <p className="text-sm text-[#949f7d]">{instructor.specialization}</p>
              </div>
            ))}
          </div>

          <div className="text-center mt-8">
            <Link href="/about">
              <Button
                variant="outline"
                className="border-[#949f7d] text-[#949f7d] hover:bg-[#949f7d] hover:text-white bg-transparent"
              >
                Meet All Our Instructors
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Back to Top Button */}
      {showBackToTop && (
        <button
          onClick={scrollToTop}
          className="fixed bottom-8 right-8 z-50 bg-[#949f7d] hover:bg-[#949f7d]/90 text-white p-3 rounded-full shadow-lg transition-all duration-300"
        >
          <ArrowUp className="w-5 h-5" />
        </button>
      )}

      <Footer />
    </div>
  )
}
