"use client"

import { useState, useEffect } from "react"
import { Search, Filter, Clock, Users, ArrowRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import Image from "next/image"
import Link from "next/link"

interface Class {
  id: number
  name: string
  description: string | null
  instructor: string
  instructorId: number
  schedule: string | null
  duration: number | null
  capacity: number | null
  enrolled: number | null
  price: number | null
  status: string
  level: string | null
  image: string | null
  createdAt: string
  updatedAt: string
}

export default function ClassesPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("All Classes")
  const [sortBy, setSortBy] = useState("popularity")
  const [classes, setClasses] = useState<Class[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const fetchClasses = async () => {
      try {
        setLoading(true)
        const response = await fetch('/api/classes')
        if (!response.ok) {
          throw new Error('Failed to fetch classes')
        }
        const classesData: Class[] = await response.json()
        setClasses(classesData)
      } catch (err) {
        setError(err instanceof Error ? err.message : 'An error occurred')
      } finally {
        setLoading(false)
      }
    }

    fetchClasses()
  }, [])

  // Get unique categories from classes
  const categories = ["All Classes", "Beginner Friendly", ...Array.from(new Set(classes.map(c => c.level).filter(Boolean)))]

  const filteredClasses = classes.filter((classItem) => {
    const matchesSearch =
      classItem.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (classItem.description && classItem.description.toLowerCase().includes(searchQuery.toLowerCase()))

    const matchesCategory =
      selectedCategory === "All Classes" ||
      classItem.level === selectedCategory ||
      (selectedCategory === "Beginner Friendly" && classItem.level === "Beginner")

    return matchesSearch && matchesCategory && classItem.status === 'active'
  })

  const sortedClasses = [...filteredClasses].sort((a, b) => {
    switch (sortBy) {
      case "price-low":
        return (a.price || 0) - (b.price || 0)
      case "price-high":
        return (b.price || 0) - (a.price || 0)
      case "difficulty":
        const difficultyOrder = { Beginner: 1, Intermediate: 2, Advanced: 3 }
        const aLevel = a.level as keyof typeof difficultyOrder
        const bLevel = b.level as keyof typeof difficultyOrder
        return (difficultyOrder[aLevel] || 0) - (difficultyOrder[bLevel] || 0)
      default:
        return 0
    }
  })

  const getDifficultyColor = (difficulty: string | null) => {
    switch (difficulty?.toLowerCase()) {
      case "beginner":
        return "bg-green-100 text-green-800"
      case "intermediate":
        return "bg-yellow-100 text-yellow-800"
      case "advanced":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  // Generate slug from class name
  const generateSlug = (name: string) => {
    return name.toLowerCase().replace(/\s+/g, '-')
  }

  // Loading state
  if (loading) {
    return (
      <div className="min-h-screen bg-white">
        <Header />
        <section className="py-20 bg-gradient-to-br from-[#e5d5bc]/20 to-white">
          <div className="container mx-auto px-4 text-center">
            <h1 className="text-5xl md:text-6xl font-bold text-gray-900 mb-4">Our Classes</h1>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">Find Your Perfect Dance Style</p>
          </div>
        </section>
        <section className="py-16">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {Array.from({ length: 6 }).map((_, i) => (
                <Card key={i} className="border-0 shadow-lg">
                  <div className="animate-pulse">
                    <div className="h-64 bg-gray-200 rounded-t-lg"></div>
                    <CardContent className="p-6">
                      <div className="h-6 bg-gray-200 rounded mb-3"></div>
                      <div className="h-4 bg-gray-200 rounded mb-2"></div>
                      <div className="h-4 bg-gray-200 rounded mb-2"></div>
                      <div className="h-4 bg-gray-200 rounded w-3/4 mb-4"></div>
                      <div className="h-8 bg-gray-200 rounded"></div>
                    </CardContent>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        </section>
        <Footer />
      </div>
    )
  }

  // Error state
  if (error) {
    return (
      <div className="min-h-screen bg-white">
        <Header />
        <section className="py-20 bg-gradient-to-br from-[#e5d5bc]/20 to-white">
          <div className="container mx-auto px-4 text-center">
            <h1 className="text-5xl md:text-6xl font-bold text-gray-900 mb-4">Our Classes</h1>
            <p className="text-xl text-red-600 mb-8">{error}</p>
            <Button 
              onClick={() => window.location.reload()} 
              className="bg-[#949f7d] hover:bg-[#949f7d]/90 text-white"
            >
              Try Again
            </Button>
          </div>
        </section>
        <Footer />
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-white">
      <Header />

      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-br from-[#e5d5bc]/20 to-white">
        <div className="container mx-auto px-4 text-center">
          <nav className="text-sm text-gray-600 mb-6">
            <Link href="/" className="hover:text-[#949f7d] transition-colors">
              Home
            </Link>
            <span className="mx-2">&gt;</span>
            <span className="text-[#949f7d]">Classes</span>
          </nav>
          <h1 className="text-5xl md:text-6xl font-bold text-gray-900 mb-4">Our Classes</h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">Find Your Perfect Dance Style</p>
        </div>
      </section>

      {/* Filters and Search */}
      <section className="py-8 bg-white border-b">
        <div className="container mx-auto px-4">
          <div className="flex flex-col lg:flex-row gap-6 items-center justify-between">
            {/* Search */}
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <Input
                placeholder="Search classes..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 border-gray-300 focus:border-[#949f7d] focus:ring-[#949f7d]"
              />
            </div>

            {/* Filters */}
            <div className="flex flex-wrap gap-4 items-center">
              <div className="flex items-center space-x-2">
                <Filter className="w-4 h-4 text-gray-600" />
                <span className="text-sm font-medium text-gray-600">Filter:</span>
              </div>

              {/* Category Filter */}
              <div className="flex flex-wrap gap-2">
                {categories.map((category) => (
                  <button
                    key={category}
                    onClick={() => setSelectedCategory(category)}
                    className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
                      selectedCategory === category
                        ? "bg-[#949f7d] text-white shadow-lg"
                        : "bg-gray-100 text-gray-600 hover:bg-gray-200"
                    }`}
                  >
                    {category}
                  </button>
                ))}
              </div>

              {/* Sort */}
              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger className="w-48 border-gray-300 focus:border-[#949f7d] focus:ring-[#949f7d]">
                  <SelectValue placeholder="Sort by" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="popularity">Popularity</SelectItem>
                  <SelectItem value="price-low">Price: Low to High</SelectItem>
                  <SelectItem value="price-high">Price: High to Low</SelectItem>
                  <SelectItem value="difficulty">Difficulty Level</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>
      </section>

      {/* Classes Grid */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          {sortedClasses.length === 0 ? (
            <div className="text-center py-16">
              <p className="text-xl text-gray-600 mb-4">No classes found matching your criteria.</p>
              <Button
                onClick={() => {
                  setSearchQuery("")
                  setSelectedCategory("All Classes")
                }}
                className="bg-[#949f7d] hover:bg-[#949f7d]/90 text-white"
              >
                Clear Filters
              </Button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {sortedClasses.map((classItem) => (
                <Card
                  key={classItem.id}
                  className="group hover:shadow-2xl transition-all duration-300 border-0 shadow-lg overflow-hidden"
                >
                  <div className="relative overflow-hidden">
                    <Image
                      src={classItem.image || "/placeholder.svg"}
                      alt={classItem.name}
                      width={400}
                      height={300}
                      className="w-full h-64 object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors duration-300"></div>
                    {classItem.level && (
                      <div
                        className={`absolute top-4 left-4 px-3 py-1 rounded-full text-sm font-medium ${getDifficultyColor(classItem.level)}`}
                      >
                        {classItem.level}
                      </div>
                    )}
                    <div className="absolute top-4 right-4 bg-[#949f7d] text-white px-3 py-1 rounded-full text-sm font-bold">
                      {classItem.price ? `$${classItem.price}` : 'Free'}
                    </div>
                  </div>

                  <CardContent className="p-6">
                    <h3 className="text-2xl font-bold text-gray-900 mb-3 group-hover:text-[#949f7d] transition-colors">
                      {classItem.name}
                    </h3>

                    <p className="text-gray-600 mb-4 line-clamp-3">
                      {classItem.description || `Join us for an amazing ${classItem.name} class! This class is perfect for dancers of all levels.`}
                    </p>

                    <div className="flex items-center justify-between text-sm text-gray-500 mb-4">
                      <div className="flex items-center space-x-1">
                        <Clock className="w-4 h-4" />
                        <span>{classItem.duration ? `${classItem.duration} min` : '60 min'}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Users className="w-4 h-4" />
                        <span>
                          {classItem.enrolled || 0}/{classItem.capacity || '∞'} students
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center space-x-3 mb-6">
                      <div className="w-8 h-8 bg-[#949f7d] rounded-full flex items-center justify-center">
                        <span className="text-xs font-medium text-white">{classItem.instructor.charAt(0)}</span>
                      </div>
                      <div>
                        <p className="text-sm font-medium text-gray-900">with {classItem.instructor}</p>
                        <p className="text-xs text-gray-500">Certified Instructor</p>
                      </div>
                    </div>

                    <div className="flex space-x-3">
                      <Link href={`/classes/${generateSlug(classItem.name)}`} className="flex-1">
                        <Button className="w-full bg-[#949f7d] hover:bg-[#949f7d]/90 text-white">Book Now</Button>
                      </Link>
                      <Link href={`/classes/${generateSlug(classItem.name)}`}>
                        <Button
                          variant="outline"
                          className="border-[#949f7d] text-[#949f7d] hover:bg-[#949f7d] hover:text-white bg-transparent"
                        >
                          Learn More
                          <ArrowRight className="w-4 h-4 ml-1" />
                        </Button>
                      </Link>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-16 bg-gradient-to-r from-[#949f7d] to-[#949f7d]/80">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Not Sure Which Class?</h2>
          <p className="text-xl text-white/90 mb-8 max-w-2xl mx-auto">
            Book a trial session and discover the perfect dance style for you. Our instructors will help you find your
            passion.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="bg-white text-[#949f7d] hover:bg-gray-100 px-8 py-3">
              Book Trial Session
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="border-white text-white hover:bg-white hover:text-[#949f7d] px-8 py-3 bg-transparent"
            >
              Contact Us
            </Button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  )
}
