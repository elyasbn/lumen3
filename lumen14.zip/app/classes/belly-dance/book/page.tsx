"use client"

import { useState } from "react"
import { ArrowLeft, Clock, Users, Star, CheckCircle, CreditCard } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Card } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { ClassCalendar } from "@/components/class-calendar"
import { SeatMap } from "@/components/seat-map"
import Image from "next/image"
import Link from "next/link"

interface ClassSession {
  id: string
  time: string
  instructor: string
  availableSpots: number
  totalSpots: number
  price: number
  duration: string
}

interface BookingForm {
  firstName: string
  lastName: string
  email: string
  phone: string
  emergencyContact: string
  medicalConditions: string
  experienceLevel: string
  specialRequirements: string
}

export default function BellyDanceBookingPage() {
  const [selectedDate, setSelectedDate] = useState<Date | null>(null)
  const [selectedSession, setSelectedSession] = useState<ClassSession | null>(null)
  const [selectedSeats, setSelectedSeats] = useState<number[]>([])
  const [currentStep, setCurrentStep] = useState(1)
  const [bookingForm, setBookingForm] = useState<BookingForm>({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    emergencyContact: "",
    medicalConditions: "",
    experienceLevel: "",
    specialRequirements: "",
  })
  const [acceptedTerms, setAcceptedTerms] = useState(false)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [bookingComplete, setBookingComplete] = useState(false)

  // Mock occupied seats for demonstration
  const occupiedSeats = [3, 7, 12, 18, 21]
  const reservedSeats = [5, 9]

  const handleSeatSelect = (seatId: number) => {
    setSelectedSeats((prev) => (prev.includes(seatId) ? prev.filter((id) => id !== seatId) : [...prev, seatId]))
  }

  const handleFormChange = (field: keyof BookingForm, value: string) => {
    setBookingForm((prev) => ({ ...prev, [field]: value }))
  }

  const calculateTotal = () => {
    if (!selectedSession) return 0
    return selectedSession.price * selectedSeats.length
  }

  const handleBookingSubmit = async () => {
    setIsSubmitting(true)
    // Simulate booking process
    await new Promise((resolve) => setTimeout(resolve, 2000))
    setIsSubmitting(false)
    setBookingComplete(true)
  }

  const canProceedToNextStep = () => {
    switch (currentStep) {
      case 1:
        return selectedDate && selectedSession
      case 2:
        return selectedSeats.length > 0
      case 3:
        return bookingForm.firstName && bookingForm.lastName && bookingForm.email && bookingForm.experienceLevel
      case 4:
        return acceptedTerms
      default:
        return false
    }
  }

  if (bookingComplete) {
    return (
      <div className="min-h-screen bg-white">
        <Header />
        <div className="container mx-auto px-4 py-20">
          <div className="max-w-2xl mx-auto text-center">
            <CheckCircle className="w-20 h-20 text-green-500 mx-auto mb-6" />
            <h1 className="text-4xl font-bold text-gray-900 mb-4">Booking Confirmed!</h1>
            <p className="text-xl text-gray-600 mb-8">
              Your Belly Dance class has been successfully booked. Check your email for confirmation details.
            </p>
            <div className="bg-gray-50 p-6 rounded-lg mb-8">
              <h3 className="font-bold text-lg mb-4">Booking Details</h3>
              <div className="space-y-2 text-left">
                <p>
                  <strong>Class:</strong> Belly Dance
                </p>
                <p>
                  <strong>Date:</strong> {selectedDate?.toLocaleDateString()}
                </p>
                <p>
                  <strong>Time:</strong> {selectedSession?.time}
                </p>
                <p>
                  <strong>Instructor:</strong> {selectedSession?.instructor}
                </p>
                <p>
                  <strong>Seats:</strong> {selectedSeats.join(", ")}
                </p>
                <p>
                  <strong>Total:</strong> ${calculateTotal()}
                </p>
              </div>
            </div>
            <div className="flex space-x-4 justify-center">
              <Link href="/">
                <Button className="bg-[#949f7d] hover:bg-[#949f7d]/90 text-white">Back to Home</Button>
              </Link>
              <Button
                variant="outline"
                className="border-[#949f7d] text-[#949f7d] hover:bg-[#949f7d] hover:text-white bg-transparent"
              >
                Book Another Class
              </Button>
            </div>
          </div>
        </div>
        <Footer />
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-white">
      <Header />

      {/* Hero Section */}
      <section className="relative h-80 overflow-hidden">
        <Image
          src="/placeholder.svg?height=320&width=1200"
          alt="Belly Dance Class"
          fill
          className="object-cover"
          priority
        />
        <div className="absolute inset-0 bg-black/50"></div>
        <div className="absolute inset-0 flex items-center">
          <div className="container mx-auto px-4">
            <nav className="text-sm text-white/80 mb-4">
              <Link href="/" className="hover:text-white transition-colors">
                Home
              </Link>
              <span className="mx-2">&gt;</span>
              <Link href="/#classes" className="hover:text-white transition-colors">
                Classes
              </Link>
              <span className="mx-2">&gt;</span>
              <span className="text-[#e5d5bc]">Book Belly Dance</span>
            </nav>
            <div className="flex items-center space-x-4 mb-4">
              <Link href="/#classes">
                <Button
                  variant="outline"
                  size="sm"
                  className="border-white text-white hover:bg-white hover:text-gray-900 bg-transparent"
                >
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Back to Classes
                </Button>
              </Link>
            </div>
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">Book Belly Dance</h1>
            <div className="flex items-center space-x-6 text-white/90">
              <div className="flex items-center space-x-1">
                <Clock className="w-5 h-5" />
                <span>60 minutes</span>
              </div>
              <div className="flex items-center space-x-1">
                <Users className="w-5 h-5" />
                <span>Up to 12 students</span>
              </div>
              <div className="flex items-center space-x-1">
                <Star className="w-5 h-5" />
                <span>All levels welcome</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Progress Indicator */}
      <div className="bg-gray-50 py-4">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-center space-x-4">
            {[1, 2, 3, 4].map((step) => (
              <div key={step} className="flex items-center">
                <div
                  className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                    currentStep >= step ? "bg-[#949f7d] text-white" : "bg-gray-200 text-gray-600"
                  }`}
                >
                  {step}
                </div>
                {step < 4 && (
                  <div className={`w-12 h-1 mx-2 ${currentStep > step ? "bg-[#949f7d]" : "bg-gray-200"}`}></div>
                )}
              </div>
            ))}
          </div>
          <div className="flex justify-center mt-2">
            <div className="text-sm text-gray-600">
              Step {currentStep} of 4:{" "}
              {currentStep === 1
                ? "Select Date & Time"
                : currentStep === 2
                  ? "Choose Seats"
                  : currentStep === 3
                    ? "Your Information"
                    : "Payment & Confirmation"}
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <section className="py-12">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Left Column - Calendar & Seat Map */}
            <div className="lg:col-span-2 space-y-6">
              {currentStep === 1 && (
                <ClassCalendar
                  className="Belly Dance"
                  onDateSelect={setSelectedDate}
                  onTimeSelect={setSelectedSession}
                  selectedDate={selectedDate}
                  selectedSession={selectedSession}
                />
              )}

              {currentStep === 2 && (
                <SeatMap
                  selectedSeats={selectedSeats}
                  onSeatSelect={handleSeatSelect}
                  occupiedSeats={occupiedSeats}
                  reservedSeats={reservedSeats}
                />
              )}

              {currentStep === 3 && (
                <Card className="p-6">
                  <h3 className="text-xl font-bold text-gray-900 mb-6">Your Information</h3>
                  <form className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">First Name *</label>
                        <Input
                          value={bookingForm.firstName}
                          onChange={(e) => handleFormChange("firstName", e.target.value)}
                          className="border-gray-300 focus:border-[#949f7d] focus:ring-[#949f7d]"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">Last Name *</label>
                        <Input
                          value={bookingForm.lastName}
                          onChange={(e) => handleFormChange("lastName", e.target.value)}
                          className="border-gray-300 focus:border-[#949f7d] focus:ring-[#949f7d]"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Email *</label>
                      <Input
                        type="email"
                        value={bookingForm.email}
                        onChange={(e) => handleFormChange("email", e.target.value)}
                        className="border-gray-300 focus:border-[#949f7d] focus:ring-[#949f7d]"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Phone</label>
                      <Input
                        type="tel"
                        value={bookingForm.phone}
                        onChange={(e) => handleFormChange("phone", e.target.value)}
                        className="border-gray-300 focus:border-[#949f7d] focus:ring-[#949f7d]"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Experience Level *</label>
                      <Select
                        value={bookingForm.experienceLevel}
                        onValueChange={(value) => handleFormChange("experienceLevel", value)}
                      >
                        <SelectTrigger className="border-gray-300 focus:border-[#949f7d] focus:ring-[#949f7d]">
                          <SelectValue placeholder="Select your experience level" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="beginner">Beginner</SelectItem>
                          <SelectItem value="intermediate">Intermediate</SelectItem>
                          <SelectItem value="advanced">Advanced</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Emergency Contact</label>
                      <Input
                        value={bookingForm.emergencyContact}
                        onChange={(e) => handleFormChange("emergencyContact", e.target.value)}
                        className="border-gray-300 focus:border-[#949f7d] focus:ring-[#949f7d]"
                        placeholder="Name and phone number"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Medical Conditions/Injuries
                      </label>
                      <Textarea
                        value={bookingForm.medicalConditions}
                        onChange={(e) => handleFormChange("medicalConditions", e.target.value)}
                        className="border-gray-300 focus:border-[#949f7d] focus:ring-[#949f7d]"
                        placeholder="Please let us know of any conditions we should be aware of"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Special Requirements</label>
                      <Textarea
                        value={bookingForm.specialRequirements}
                        onChange={(e) => handleFormChange("specialRequirements", e.target.value)}
                        className="border-gray-300 focus:border-[#949f7d] focus:ring-[#949f7d]"
                        placeholder="Any special accommodations needed"
                      />
                    </div>
                  </form>
                </Card>
              )}

              {currentStep === 4 && (
                <Card className="p-6">
                  <h3 className="text-xl font-bold text-gray-900 mb-6">Payment & Confirmation</h3>

                  <div className="space-y-6">
                    <div className="bg-gray-50 p-4 rounded-lg">
                      <h4 className="font-medium text-gray-900 mb-2">Payment Options</h4>
                      <div className="space-y-2">
                        <label className="flex items-center space-x-2">
                          <input type="radio" name="payment" defaultChecked className="text-[#949f7d]" />
                          <CreditCard className="w-4 h-4" />
                          <span>Credit/Debit Card</span>
                        </label>
                        <label className="flex items-center space-x-2">
                          <input type="radio" name="payment" className="text-[#949f7d]" />
                          <span>PayPal</span>
                        </label>
                      </div>
                    </div>

                    <div className="space-y-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">Card Number</label>
                        <Input
                          placeholder="1234 5678 9012 3456"
                          className="border-gray-300 focus:border-[#949f7d] focus:ring-[#949f7d]"
                        />
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">Expiry Date</label>
                          <Input
                            placeholder="MM/YY"
                            className="border-gray-300 focus:border-[#949f7d] focus:ring-[#949f7d]"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">CVV</label>
                          <Input
                            placeholder="123"
                            className="border-gray-300 focus:border-[#949f7d] focus:ring-[#949f7d]"
                          />
                        </div>
                      </div>
                    </div>

                    <div className="border-t pt-4">
                      <div className="flex items-start space-x-2">
                        <Checkbox
                          id="terms"
                          checked={acceptedTerms}
                          onCheckedChange={(checked) => setAcceptedTerms(checked as boolean)}
                        />
                        <label htmlFor="terms" className="text-sm text-gray-600">
                          I agree to the{" "}
                          <Link href="#" className="text-[#949f7d] hover:underline">
                            Terms and Conditions
                          </Link>{" "}
                          and{" "}
                          <Link href="#" className="text-[#949f7d] hover:underline">
                            Cancellation Policy
                          </Link>
                        </label>
                      </div>
                    </div>
                  </div>
                </Card>
              )}
            </div>

            {/* Right Column - Booking Summary */}
            <div className="lg:col-span-1">
              <Card className="p-6 sticky top-24">
                <h3 className="text-xl font-bold text-gray-900 mb-6">Booking Summary</h3>

                <div className="space-y-4">
                  <div className="flex items-center space-x-3">
                    <Image
                      src="/placeholder.svg?height=60&width=60"
                      alt="Belly Dance"
                      width={60}
                      height={60}
                      className="rounded-lg"
                    />
                    <div>
                      <h4 className="font-medium text-gray-900">Belly Dance</h4>
                      <p className="text-sm text-gray-600">with Amira Hassan</p>
                    </div>
                  </div>

                  {selectedDate && selectedSession && (
                    <div className="border-t pt-4 space-y-2">
                      <div className="flex justify-between">
                        <span className="text-gray-600">Date:</span>
                        <span className="font-medium">{selectedDate.toLocaleDateString()}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Time:</span>
                        <span className="font-medium">{selectedSession.time}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Duration:</span>
                        <span className="font-medium">{selectedSession.duration}</span>
                      </div>
                    </div>
                  )}

                  {selectedSeats.length > 0 && (
                    <div className="border-t pt-4 space-y-2">
                      <div className="flex justify-between">
                        <span className="text-gray-600">Seats:</span>
                        <span className="font-medium">{selectedSeats.join(", ")}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Price per seat:</span>
                        <span className="font-medium">${selectedSession?.price}</span>
                      </div>
                    </div>
                  )}

                  {selectedSession && selectedSeats.length > 0 && (
                    <div className="border-t pt-4">
                      <div className="flex justify-between text-lg font-bold">
                        <span>Total:</span>
                        <span className="text-[#949f7d]">${calculateTotal()}</span>
                      </div>
                    </div>
                  )}
                </div>

                <div className="mt-6 space-y-3">
                  {currentStep < 4 && (
                    <Button
                      onClick={() => setCurrentStep(currentStep + 1)}
                      disabled={!canProceedToNextStep()}
                      className="w-full bg-[#949f7d] hover:bg-[#949f7d]/90 text-white"
                    >
                      {currentStep === 1 ? "Choose Seats" : currentStep === 2 ? "Enter Information" : "Review & Pay"}
                    </Button>
                  )}

                  {currentStep === 4 && (
                    <Button
                      onClick={handleBookingSubmit}
                      disabled={!canProceedToNextStep() || isSubmitting}
                      className="w-full bg-[#949f7d] hover:bg-[#949f7d]/90 text-white"
                    >
                      {isSubmitting ? (
                        <>
                          <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                          Processing...
                        </>
                      ) : (
                        "Confirm Booking"
                      )}
                    </Button>
                  )}

                  {currentStep > 1 && (
                    <Button
                      onClick={() => setCurrentStep(currentStep - 1)}
                      variant="outline"
                      className="w-full border-[#949f7d] text-[#949f7d] hover:bg-[#949f7d] hover:text-white"
                    >
                      Back
                    </Button>
                  )}
                </div>

                {/* Class Info */}
                <div className="mt-6 pt-6 border-t">
                  <h4 className="font-medium text-gray-900 mb-3">What to Bring</h4>
                  <ul className="text-sm text-gray-600 space-y-1">
                    <li>• Comfortable, stretchy clothing</li>
                    <li>• Water bottle</li>
                    <li>• Bare feet or dance shoes</li>
                    <li>• Hip scarf (optional)</li>
                  </ul>
                </div>
              </Card>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  )
}
