"use client"

import { useState, useEffect } from "react"
import { Clock, Users, Star, MapPin, Calendar, ArrowLeft, Heart, Share2, CheckCircle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { ClassCalendar } from "@/components/class-calendar"
import { SeatMap } from "@/components/seat-map"
import Image from "next/image"
import Link from "next/link"
import { useParams } from "next/navigation"

interface Class {
  id: number
  name: string
  description: string | null
  instructor: string
  instructorId: number
  schedule: string | null
  duration: number | null
  capacity: number | null
  enrolled: number | null
  price: number | null
  status: string
  level: string | null
  image: string | null
  createdAt: string
  updatedAt: string
}

interface ClassSession {
  id: string
  time: string
  instructor: string
  availableSpots: number
  totalSpots: number
  price: number
  duration: string
}

export default function ClassPage() {
  const params = useParams()
  const slug = params.slug as string
  
  const [classData, setClassData] = useState<Class | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [selectedDate, setSelectedDate] = useState<Date | null>(null)
  const [selectedSession, setSelectedSession] = useState<ClassSession | null>(null)
  const [selectedSeats, setSelectedSeats] = useState<number[]>([])
  const [currentStep, setCurrentStep] = useState(1)
  const [isFavorited, setIsFavorited] = useState(false)
  const [showBooking, setShowBooking] = useState(false)

  useEffect(() => {
    const fetchClass = async () => {
      try {
        setLoading(true)
        const response = await fetch('/api/classes')
        if (!response.ok) {
          throw new Error('Failed to fetch classes')
        }
        const classes: Class[] = await response.json()
        
        // Find class by slug (assuming slug is derived from name)
        const classItem = classes.find(c => 
          c.name.toLowerCase().replace(/\s+/g, '-') === slug ||
          c.name.toLowerCase().replace(/\s+/g, '-').includes(slug)
        )
        
        if (!classItem) {
          setError('Class not found')
          return
        }
        
        setClassData(classItem)
      } catch (err) {
        setError(err instanceof Error ? err.message : 'An error occurred')
      } finally {
        setLoading(false)
      }
    }

    if (slug) {
      fetchClass()
    }
  }, [slug])

  const handleSeatSelect = (seatId: number) => {
    setSelectedSeats((prev) => (prev.includes(seatId) ? prev.filter((id) => id !== seatId) : [...prev, seatId]))
  }

  const calculateTotal = () => {
    if (!selectedSession || !classData?.price) return 0
    return classData.price * selectedSeats.length
  }

  const getLevelColor = (level: string | null) => {
    switch (level?.toLowerCase()) {
      case 'beginner':
        return 'bg-green-500 text-white'
      case 'intermediate':
        return 'bg-yellow-500 text-white'
      case 'advanced':
        return 'bg-red-500 text-white'
      default:
        return 'bg-gray-500 text-white'
    }
  }

  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case 'active':
        return 'bg-green-500 text-white'
      case 'inactive':
        return 'bg-gray-500 text-white'
      case 'full':
        return 'bg-red-500 text-white'
      default:
        return 'bg-gray-500 text-white'
    }
  }

  // Loading state
  if (loading) {
    return (
      <div className="min-h-screen bg-white">
        <Header />
        <div className="container mx-auto px-4 py-16">
          <div className="max-w-4xl mx-auto">
            <div className="animate-pulse">
              <div className="h-96 bg-gray-200 rounded-lg mb-8"></div>
              <div className="h-8 bg-gray-200 rounded mb-4"></div>
              <div className="h-4 bg-gray-200 rounded mb-2"></div>
              <div className="h-4 bg-gray-200 rounded mb-2"></div>
              <div className="h-4 bg-gray-200 rounded w-3/4"></div>
            </div>
          </div>
        </div>
        <Footer />
      </div>
    )
  }

  // Error state
  if (error || !classData) {
    return (
      <div className="min-h-screen bg-white">
        <Header />
        <div className="container mx-auto px-4 py-16">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl font-bold text-gray-900 mb-4">Class Not Found</h1>
            <p className="text-gray-600 mb-8">{error || "The class you're looking for doesn't exist."}</p>
            <Link href="/classes">
              <Button className="bg-[#949f7d] hover:bg-[#949f7d]/90 text-white">
                Back to Classes
              </Button>
            </Link>
          </div>
        </div>
        <Footer />
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-white">
      <Header />

      {/* Hero Section */}
      <section className="relative h-96 overflow-hidden">
        <Image 
          src={classData.image || "/placeholder.svg"} 
          alt={classData.name} 
          fill 
          className="object-cover" 
          priority 
        />
        <div className="absolute inset-0 bg-black/50"></div>
        <div className="absolute inset-0 flex items-end">
          <div className="container mx-auto px-4 pb-8">
            <nav className="text-sm text-white/80 mb-4">
              <Link href="/" className="hover:text-white transition-colors">
                Home
              </Link>
              <span className="mx-2">&gt;</span>
              <Link href="/classes" className="hover:text-white transition-colors">
                Classes
              </Link>
              <span className="mx-2">&gt;</span>
              <span className="text-[#e5d5bc]">{classData.name}</span>
            </nav>
            <div className="flex items-center space-x-4 mb-4">
              <Link href="/classes">
                <Button
                  variant="outline"
                  size="sm"
                  className="border-white text-white hover:bg-white hover:text-gray-900 bg-transparent"
                >
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Back to Classes
                </Button>
              </Link>
            </div>
            <div className="flex items-center space-x-4 mb-4">
              {classData.level && (
                <Badge className={getLevelColor(classData.level)}>
                  {classData.level}
                </Badge>
              )}
              <Badge className={getStatusColor(classData.status)}>
                {classData.status}
              </Badge>
            </div>
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">{classData.name}</h1>
            <div className="flex items-center space-x-6 text-white/90">
              <div className="flex items-center space-x-1">
                <Clock className="w-5 h-5" />
                <span>{classData.duration ? `${classData.duration} minutes` : '60 minutes'}</span>
              </div>
              <div className="flex items-center space-x-1">
                <Users className="w-5 h-5" />
                <span>
                  {classData.enrolled || 0}/{classData.capacity || 'Unlimited'} students
                </span>
              </div>
              <div className="flex items-center space-x-1">
                <Star className="w-5 h-5" />
                <span>with {classData.instructor}</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
              {/* Main Content */}
              <div className="lg:col-span-2 space-y-8">
                {/* Class Description */}
                <Card className="p-6">
                  <h2 className="text-2xl font-bold text-gray-900 mb-4">About This Class</h2>
                  <p className="text-gray-700 leading-relaxed">
                    {classData.description || `Join us for an amazing ${classData.name} class! This class is perfect for dancers of all levels and will help you improve your technique while having fun.`}
                  </p>
                </Card>

                {/* Class Details */}
                <Card className="p-6">
                  <h3 className="text-xl font-bold text-gray-900 mb-4">Class Details</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="flex items-center space-x-3">
                      <Clock className="w-5 h-5 text-[#949f7d]" />
                      <div>
                        <p className="font-medium text-gray-900">Duration</p>
                        <p className="text-gray-600">{classData.duration ? `${classData.duration} minutes` : '60 minutes'}</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-3">
                      <Users className="w-5 h-5 text-[#949f7d]" />
                      <div>
                        <p className="font-medium text-gray-900">Capacity</p>
                        <p className="text-gray-600">{classData.capacity || 'Unlimited'} students</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-3">
                      <Star className="w-5 h-5 text-[#949f7d]" />
                      <div>
                        <p className="font-medium text-gray-900">Instructor</p>
                        <p className="text-gray-600">{classData.instructor}</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-3">
                      <Calendar className="w-5 h-5 text-[#949f7d]" />
                      <div>
                        <p className="font-medium text-gray-900">Schedule</p>
                        <p className="text-gray-600">{classData.schedule || 'Check calendar for times'}</p>
                      </div>
                    </div>
                  </div>
                </Card>

                {/* Booking Section */}
                {!showBooking ? (
                  <Card className="p-6">
                    <h3 className="text-xl font-bold text-gray-900 mb-4">Ready to Book?</h3>
                    <p className="text-gray-600 mb-6">
                      Reserve your spot in this amazing class. Choose your preferred date and time, then select your seats.
                    </p>
                    <div className="flex space-x-4">
                      <Button 
                        onClick={() => setShowBooking(true)}
                        className="bg-[#949f7d] hover:bg-[#949f7d]/90 text-white"
                      >
                        Book This Class
                      </Button>
                      <Button
                        variant="outline"
                        onClick={() => setIsFavorited(!isFavorited)}
                        className="border-[#949f7d] text-[#949f7d] hover:bg-[#949f7d] hover:text-white"
                      >
                        <Heart className={`w-4 h-4 mr-2 ${isFavorited ? 'fill-current' : ''}`} />
                        {isFavorited ? 'Favorited' : 'Add to Favorites'}
                      </Button>
                    </div>
                  </Card>
                ) : (
                  <div className="space-y-6">
                    {/* Progress Indicator */}
                    <div className="bg-gray-50 py-4 rounded-lg">
                      <div className="flex items-center justify-center space-x-4">
                        {[1, 2, 3].map((step) => (
                          <div key={step} className="flex items-center">
                            <div
                              className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                                currentStep >= step ? "bg-[#949f7d] text-white" : "bg-gray-200 text-gray-600"
                              }`}
                            >
                              {step}
                            </div>
                            {step < 3 && (
                              <div className={`w-12 h-1 mx-2 ${currentStep > step ? "bg-[#949f7d]" : "bg-gray-200"}`}></div>
                            )}
                          </div>
                        ))}
                      </div>
                      <div className="flex justify-center mt-2">
                        <div className="text-sm text-gray-600">
                          Step {currentStep} of 3:{" "}
                          {currentStep === 1
                            ? "Select Date & Time"
                            : currentStep === 2
                              ? "Choose Seats"
                              : "Review & Confirm"}
                        </div>
                      </div>
                    </div>

                    {/* Booking Steps */}
                    {currentStep === 1 && (
                      <ClassCalendar
                        className={classData.name}
                        onDateSelect={setSelectedDate}
                        onTimeSelect={setSelectedSession}
                        selectedDate={selectedDate}
                        selectedSession={selectedSession}
                      />
                    )}

                    {currentStep === 2 && (
                      <SeatMap
                        selectedSeats={selectedSeats}
                        onSeatSelect={handleSeatSelect}
                        occupiedSeats={[]}
                        reservedSeats={[]}
                      />
                    )}

                    {currentStep === 3 && (
                      <Card className="p-6">
                        <h3 className="text-xl font-bold text-gray-900 mb-6">Confirm Your Booking</h3>
                        <div className="space-y-4">
                          <div className="bg-gray-50 p-4 rounded-lg">
                            <h4 className="font-medium text-gray-900 mb-2">Booking Summary</h4>
                            <div className="space-y-2">
                              <p><strong>Class:</strong> {classData.name}</p>
                              <p><strong>Date:</strong> {selectedDate?.toLocaleDateString()}</p>
                              <p><strong>Time:</strong> {selectedSession?.time}</p>
                              <p><strong>Seats:</strong> {selectedSeats.join(", ")}</p>
                              <p><strong>Total:</strong> ${calculateTotal()}</p>
                            </div>
                          </div>
                          <div className="flex space-x-4">
                            <Button
                              onClick={() => {
                                // Handle booking confirmation
                                alert('Booking confirmed! Check your email for details.')
                                setShowBooking(false)
                                setCurrentStep(1)
                                setSelectedDate(null)
                                setSelectedSession(null)
                                setSelectedSeats([])
                              }}
                              className="bg-[#949f7d] hover:bg-[#949f7d]/90 text-white"
                            >
                              <CheckCircle className="w-4 h-4 mr-2" />
                              Confirm Booking
                            </Button>
                            <Button
                              onClick={() => setCurrentStep(2)}
                              variant="outline"
                              className="border-[#949f7d] text-[#949f7d] hover:bg-[#949f7d] hover:text-white"
                            >
                              Back
                            </Button>
                          </div>
                        </div>
                      </Card>
                    )}
                  </div>
                )}
              </div>

              {/* Sidebar */}
              <div className="lg:col-span-1">
                <div className="sticky top-24 space-y-6">
                  {/* Class Info Card */}
                  <Card className="p-6">
                    <h3 className="text-xl font-bold text-gray-900 mb-4">Class Information</h3>
                    <div className="space-y-4">
                      <div className="flex items-center space-x-3">
                        <Image
                          src={classData.image || "/placeholder.svg"}
                          alt={classData.name}
                          width={60}
                          height={60}
                          className="rounded-lg"
                        />
                        <div>
                          <h4 className="font-medium text-gray-900">{classData.name}</h4>
                          <p className="text-sm text-gray-600">with {classData.instructor}</p>
                        </div>
                      </div>

                      <div className="space-y-2">
                        <div className="flex justify-between">
                          <span className="text-gray-600">Price:</span>
                          <span className="font-medium">
                            {classData.price ? `$${classData.price}` : 'Free'}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">Duration:</span>
                          <span className="font-medium">
                            {classData.duration ? `${classData.duration} min` : '60 min'}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">Level:</span>
                          <span className="font-medium">{classData.level || 'All levels'}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">Available:</span>
                          <span className="font-medium">
                            {classData.capacity ? `${(classData.capacity - (classData.enrolled || 0))} spots` : 'Unlimited'}
                          </span>
                        </div>
                      </div>
                    </div>
                  </Card>

                  {/* What to Bring */}
                  <Card className="p-6">
                    <h4 className="font-medium text-gray-900 mb-3">What to Bring</h4>
                    <ul className="text-sm text-gray-600 space-y-1">
                      <li>• Comfortable, stretchy clothing</li>
                      <li>• Water bottle</li>
                      <li>• Dance shoes or bare feet</li>
                      <li>• Positive energy!</li>
                    </ul>
                  </Card>

                  {/* Share */}
                  <Card className="p-6">
                    <h4 className="font-medium text-gray-900 mb-3">Share This Class</h4>
                    <div className="flex space-x-2">
                      <Button
                        variant="outline"
                        size="sm"
                        className="flex-1 border-blue-200 text-blue-600 hover:bg-blue-50"
                      >
                        <Share2 className="w-4 h-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </Card>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  )
}
