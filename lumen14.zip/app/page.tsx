"use client"

import { useState, useEffect } from "react"
import {
  ChevronLeft,
  ChevronRight,
  Calendar,
  Clock,
  MapPin,
  Phone,
  Mail,
  Facebook,
  Instagram,
  Twitter,
  Youtube,
  ArrowUp,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import Image from "next/image"
import Link from "next/link"

interface DanceClass {
  id: number
  name: string
  description: string | null
  instructor: string
  instructorId: number
  schedule: string | null
  duration: number | null
  capacity: number | null
  enrolled: number | null
  price: number | null
  status: string
  level: string | null
  image: string | null
  createdAt: string
  updatedAt: string
}

interface Coach {
  id: number
  name: string
  email: string
  phone: string | null
  specialties: string[] | null
  experience: string | null
  rating: number | null
  students: number | null
  status: string
  avatar: string | null
  bio: string | null
  certifications: string[] | null
  joinedAt: string
  socialMedia: any
}

interface Product {
  id: number
  name: string
  slug: string
  category: string | null
  price: number
  originalPrice: number | null
  stock: number
  sold: number
  rating: number | null
  reviewCount: number | null
  status: string
  featured: boolean
  badge: string | null
  image: string | null
  images: string[] | null
  description: string | null
  features: string[] | null
  sizes: string[] | null
  colors: string[] | null
  tags: string[] | null
  createdAt: string
  updatedAt: string
}

interface Event {
  id: number
  title: string
  slug: string
  date: string
  time: string | null
  endTime: string | null
  location: string | null
  address: string | null
  type: string | null
  capacity: number | null
  registered: number
  price: number | null
  status: string
  featured: boolean
  description: string | null
  image: string | null
  instructors: string[] | null
  tags: string[] | null
  createdAt: string
  updatedAt: string
}

interface BlogPost {
  id: number
  title: string
  slug: string
  excerpt: string | null
  content: string | null
  author: string
  authorId: number
  publishedAt: string
  updatedAt: string
  status: string
  category: string | null
  tags: string[] | null
  readTime: string | null
  views: number
  featured: boolean
  image: string | null
  seo: any
}

// Fallback data in case APIs fail to load
const fallbackClasses: DanceClass[] = [
  {
    id: 1,
    name: "Belly Dance",
    description: "Discover the ancient art of belly dance with fluid movements and graceful expressions that celebrate femininity and strength.",
    instructor: "Maria Rodriguez",
    instructorId: 1,
    schedule: null,
    duration: 60,
    capacity: 20,
    enrolled: 15,
    price: 25,
    status: "active",
    level: "Beginner Friendly",
    image: "https://images.unsplash.com/photo-1547153760-18fc86324498?q=80&w=687&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 2,
    name: "Khaleej Dance",
    description: "Experience the traditional Gulf dance with elegant hair movements and cultural rhythms that tell stories of heritage.",
    instructor: "Fatima Al-Zahra",
    instructorId: 2,
    schedule: null,
    duration: 75,
    capacity: 15,
    enrolled: 12,
    price: 30,
    status: "active",
    level: "Beginner Friendly",
    image: "https://images.unsplash.com/photo-1611879531844-24b7ddf40b26?q=80&w=1170&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 3,
    name: "Latina Dance",
    description: "Feel the passion and energy of Latin rhythms with salsa, bachata, and merengue that ignite your soul.",
    instructor: "Carlos Mendez",
    instructorId: 3,
    schedule: null,
    duration: 90,
    capacity: 25,
    enrolled: 20,
    price: 35,
    status: "active",
    level: "Intermediate",
    image: "https://images.unsplash.com/photo-1650465811226-de19b0502e94?q=80&w=687&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
]

const fallbackCoaches: Coach[] = [
  {
    id: 1,
    name: "Sofia Martinez",
    email: "sofia@lumen.com",
    phone: "+1234567890",
    specialties: ["Latina Dance", "Salsa"],
    experience: "15+ years",
    rating: 4.8,
    students: 150,
    status: "active",
    avatar: "https://images.unsplash.com/photo-1494790108755-2616c6d4e6e8?q=80&w=687&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
    bio: "Professional dancer with 15+ years experience in Latin dance styles.",
    certifications: ["Professional Salsa Instructor", "Bachata Specialist"],
    joinedAt: new Date().toISOString(),
    socialMedia: null,
  },
  {
    id: 2,
    name: "Amira Hassan",
    email: "amira@lumen.com",
    phone: "+1234567891",
    specialties: ["Belly Dance", "Khaleej"],
    experience: "12+ years",
    rating: 4.9,
    students: 120,
    status: "active",
    avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?q=80&w=1170&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
    bio: "Master instructor specializing in Middle Eastern dance traditions.",
    certifications: ["Certified Belly Dance Instructor", "Cultural Dance Specialist"],
    joinedAt: new Date().toISOString(),
    socialMedia: null,
  },
  {
    id: 3,
    name: "Elena Petrov",
    email: "elena@lumen.com",
    phone: "+1234567892",
    specialties: ["Ballet", "Contemporary"],
    experience: "20+ years",
    rating: 4.7,
    students: 200,
    status: "active",
    avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?q=80&w=688&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
    bio: "Former principal dancer with international ballet companies.",
    certifications: ["Royal Academy of Dance", "Vaganova Method"],
    joinedAt: new Date().toISOString(),
    socialMedia: null,
  },
]

export default function DanceStudioHomepage() {
  const [danceClasses, setDanceClasses] = useState<DanceClass[]>([])
  const [coaches, setCoaches] = useState<Coach[]>([])
  const [products, setProducts] = useState<Product[]>([])
  const [events, setEvents] = useState<Event[]>([])
  const [blogPosts, setBlogPosts] = useState<BlogPost[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const [currentSlide, setCurrentSlide] = useState(0)
  const [currentCoach, setCurrentCoach] = useState(0)
  const [showBackToTop, setShowBackToTop] = useState(false)
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  useEffect(() => {
    const loadData = async () => {
      try {
        setLoading(true)
        setError(null)

        const [classesRes, coachesRes, productsRes, eventsRes, blogRes] = await Promise.all([
          fetch("/api/classes"),
          fetch("/api/coaches"),
          fetch("/api/products"),
          fetch("/api/events"),
          fetch("/api/blog"),
        ])

        // Load classes
        if (classesRes?.ok) {
          const classesData = await classesRes.json()
          const activeClasses = classesData.filter((cls: DanceClass) => cls.status === 'active')
          setDanceClasses(activeClasses)
        } else {
          console.error("Failed to load classes")
        }

        // Load coaches
        if (coachesRes?.ok) {
          const coachesData = await coachesRes.json()
          const activeCoaches = coachesData.filter((coach: Coach) => coach.status === 'active')
          setCoaches(activeCoaches)
        } else {
          console.error("Failed to load coaches")
        }

        // Load products
        if (productsRes?.ok) {
          const productsData = await productsRes.json()
          const activeProducts = productsData.filter((product: Product) => product.status === 'active')
          setProducts(activeProducts.slice(0, 6)) // Show first 6 products
        } else {
          console.error("Failed to load products")
        }

        // Load events
        if (eventsRes?.ok) {
          const eventsData = await eventsRes.json()
          const upcomingEvents = eventsData.filter((event: Event) =>
            event.status === 'active' && new Date(event.date) >= new Date()
          )
          setEvents(upcomingEvents.slice(0, 4)) // Show first 4 upcoming events
        } else {
          console.error("Failed to load events")
        }

        // Load blog posts
        if (blogRes?.ok) {
          const blogData = await blogRes.json()
          const publishedPosts = blogData.filter((post: BlogPost) => post.status === "published")
          setBlogPosts(publishedPosts.slice(0, 4)) // Show first 4 published posts
        } else {
          console.error("Failed to load blog posts")
        }
      } catch (error) {
        console.error("Error loading data:", error)
        setError("Failed to load some data. Please refresh the page.")
        // Use fallback data for critical sections
        setDanceClasses(fallbackClasses)
        setCoaches(fallbackCoaches)
      } finally {
        setLoading(false)
      }
    }

    loadData()
  }, [])

  useEffect(() => {
    if (danceClasses.length > 0) {
      const timer = setInterval(() => {
        setCurrentSlide((prev) => (prev + 1) % danceClasses.length)
      }, 5000)
      return () => clearInterval(timer)
    }
  }, [danceClasses.length])

  useEffect(() => {
    const handleScroll = () => {
      setShowBackToTop(window.scrollY > 300)
    }
    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % danceClasses.length)
  }

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + danceClasses.length) % danceClasses.length)
  }

  const nextCoach = () => {
    setCurrentCoach((prev) => (prev + 1) % coaches.length)
  }

  const prevCoach = () => {
    setCurrentCoach((prev) => (prev - 1 + coaches.length) % coaches.length)
  }

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" })
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
    })
  }

  // Generate slug from name
  const generateSlug = (name: string) => {
    return name.toLowerCase().replace(/\s+/g, '-')
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-[#949f7d] mx-auto mb-4"></div>
          <p className="text-gray-600">Loading Lumen Studio...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-white font-sans">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-white/95 backdrop-blur-sm border-b border-[#e5d5bc]/20">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <div className="w-10 h-10 bg-[#949f7d] rounded-full flex items-center justify-center">
                <span className="text-white font-bold text-lg">L</span>
              </div>
              <span className="text-2xl font-bold text-[#949f7d]">Lumen</span>
            </div>

            <nav className="hidden md:flex items-center space-x-8">
              <Link href="/" className="text-gray-700 hover:text-[#949f7d] transition-colors">
                Home
              </Link>
              <Link href="/about" className="text-gray-700 hover:text-[#949f7d] transition-colors">
                About
              </Link>
              <Link href="/classes" className="text-gray-700 hover:text-[#949f7d] transition-colors">
                Classes
              </Link>
              <Link href="#coaches" className="text-gray-700 hover:text-[#949f7d] transition-colors">
                Coaches
              </Link>
              <Link href="#shop" className="text-gray-700 hover:text-[#949f7d] transition-colors">
                Shop
              </Link>
              <Link href="/blog" className="text-gray-700 hover:text-[#949f7d] transition-colors">
                Blog
              </Link>
              <Link href="/contact" className="text-gray-700 hover:text-[#949f7d] transition-colors">
                Contact
              </Link>
            </nav>

            <Button className="hidden md:block bg-[#949f7d] hover:bg-[#949f7d]/90 text-white">
              <Link href="/classes">Book Now</Link>
            </Button>

            <button className="md:hidden" onClick={() => setIsMenuOpen(!isMenuOpen)}>
              <div className="w-6 h-6 flex flex-col justify-center space-y-1">
                <div className="w-full h-0.5 bg-gray-700"></div>
                <div className="w-full h-0.5 bg-gray-700"></div>
                <div className="w-full h-0.5 bg-gray-700"></div>
              </div>
            </button>
          </div>

          {/* Mobile Menu */}
          {isMenuOpen && (
            <div className="md:hidden mt-4 pb-4 border-t border-[#e5d5bc]/20">
              <nav className="flex flex-col space-y-4 mt-4">
                <Link href="/" className="text-gray-700 hover:text-[#949f7d] transition-colors">
                  Home
                </Link>
                <Link href="/about" className="text-gray-700 hover:text-[#949f7d] transition-colors">
                  About
                </Link>
                <Link href="#classes" className="text-gray-700 hover:text-[#949f7d] transition-colors">
                  Classes
                </Link>
                <Link href="#coaches" className="text-gray-700 hover:text-[#949f7d] transition-colors">
                  Coaches
                </Link>
                <Link href="#shop" className="text-gray-700 hover:text-[#949f7d] transition-colors">
                  Shop
                </Link>
                <Link href="#events" className="text-gray-700 hover:text-[#949f7d] transition-colors">
                  Events
                </Link>
                <Link href="/blog" className="text-gray-700 hover:text-[#949f7d] transition-colors">
                  Blog
                </Link>
                <Link href="/contact" className="text-gray-700 hover:text-[#949f7d] transition-colors">
                  Contact
                </Link>
                <Button className="bg-[#949f7d] hover:bg-[#949f7d]/90 text-white w-full">Book Now</Button>
              </nav>
            </div>
          )}
        </div>
      </header>

      {/* Hero Section - Split Screen Design */}
      <section id="home" className="min-h-screen bg-gradient-to-br from-gray-50 to-white relative overflow-hidden">
        <div className="container mx-auto px-4 h-screen flex items-center">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center w-full">
            {/* Left Side - Content */}
            <div className="space-y-8 lg:pr-8">
              <div className="space-y-4">
                <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold text-gray-900 leading-tight">
                  Start Dancing
                  <span className="block text-[#e5d5bc] text-4xl md:text-5xl lg:text-6xl font-light mt-2">Today</span>
                </h1>
                <h2 className="text-2xl md:text-3xl text-[#e5d5bc] font-light">with our Classes</h2>
              </div>

              <p className="text-lg md:text-xl text-gray-600 leading-relaxed max-w-lg">
                Discover the perfect dance class for your style and skill level. From traditional belly dance to
                high-energy Zumba, our expert instructors will guide you through an incredible journey of movement and
                self-expression.
              </p>

              <Button
                size="lg"
                className="bg-[#949f7d] hover:bg-[#949f7d]/90 text-white px-8 py-4 rounded-full text-lg font-medium shadow-lg hover:shadow-xl transition-all duration-300"
              >
                <Link href="/classes">Explore Classes</Link>
              </Button>

              {/* Social Media Icons */}
              <div className="flex items-center space-x-6 pt-8">
                <span className="text-gray-500 text-sm font-medium">Follow Us</span>
                <div className="flex space-x-4">
                  <a href="https://www.facebook.com/share/1DtcPqmkyQ/?mibextid=wwXIfr" target="_blank" rel="noopener noreferrer">
                    <div className="w-10 h-10 bg-white shadow-md rounded-full flex items-center justify-center hover:bg-[#949f7d] hover:text-white transition-all duration-300 cursor-pointer">
                      <Facebook className="w-5 h-5" />
                    </div>
                  </a>
                  <a href="https://www.instagram.com/sunshine.doha/" target="_blank" rel="noopener noreferrer">
                    <div className="w-10 h-10 bg-white shadow-md rounded-full flex items-center justify-center hover:bg-[#949f7d] hover:text-white transition-all duration-300 cursor-pointer">
                      <Instagram className="w-5 h-5" />
                    </div>
                  </a>
                </div>
              </div>
            </div>

            {/* Right Side - Modern Card Slider */}
            <div className="relative h-[600px] lg:h-[700px]">
              {/* Main Slider Container */}
              <div className="relative h-full">
                {/* Background Cards Stack */}
                <div className="absolute inset-0">
                  {danceClasses.map((danceClass, index) => {
                    const isActive = index === currentSlide
                    const isPrev = index === (currentSlide - 1 + danceClasses.length) % danceClasses.length
                    const isNext = index === (currentSlide + 1) % danceClasses.length

                    let transform = "translateX(100%) scale(0.8)"
                    let zIndex = 1
                    let opacity = 0

                    if (isActive) {
                      transform = "translateX(0%) scale(1)"
                      zIndex = 10
                      opacity = 1
                    } else if (isPrev) {
                      transform = "translateX(-20%) scale(0.9)"
                      zIndex = 5
                      opacity = 0.6
                    } else if (isNext) {
                      transform = "translateX(20%) scale(0.9)"
                      zIndex = 5
                      opacity = 0.6
                    }

                    return (
                      <div
                        key={index}
                        className="absolute inset-0 transition-all duration-700 ease-out"
                        style={{
                          transform,
                          zIndex,
                          opacity,
                        }}
                      >
                        <Card className="h-full mx-4 overflow-hidden border-0 shadow-2xl group cursor-pointer relative bg-black">
                          <Link
                            href={`/classes/${generateSlug(danceClass.name)}`}
                            className="block h-full"
                          >
                            {/* BACKGROUND: image + overlay (fades only on non-active slides) */}
                            <div
                              className={`absolute inset-0 transition-opacity duration-700 ${index === currentSlide ? "opacity-100" : "opacity-60"
                                }`}
                            >
                              <Image
                                src={danceClass.image || "/placeholder.svg"}
                                alt={danceClass.name}
                                fill
                                className={`object-cover transition-transform duration-700 ${index === currentSlide ? "group-hover:scale-110" : ""
                                  }`}
                                priority={index === currentSlide}
                              />
                              {/* 50% black overlay for readability */}
                              <div className="absolute inset-0 bg-black/50" />
                            </div>

                            {/* FOREGROUND CONTENT: never transparent */}
                            <div className="relative z-20 h-full p-8 flex flex-col justify-between text-white">
                              {/* Top badges */}
                              <div className="flex justify-between">
                                <span className="bg-white/90 backdrop-blur-sm text-gray-900 px-4 py-2 rounded-full text-sm font-semibold shadow-lg">
                                  {danceClass.level || "All Levels"}
                                </span>
                                <span className="bg-[#949f7d]/90 backdrop-blur-sm text-white px-4 py-2 rounded-full text-sm font-semibold shadow-lg">
                                  {danceClass.duration || 60} min
                                </span>
                              </div>

                              {/* Title + description */}
                              <div>
                                <h3 className="text-2xl lg:text-3xl font-bold mb-3 group-hover:text-[#949f7d] transition-colors duration-300">
                                  {danceClass.name}
                                </h3>
                                <p className="text-white/90 text-sm lg:text-base leading-relaxed line-clamp-3 mb-4">
                                  {danceClass.description || `Join our ${danceClass.name} class and discover the joy of dance!`}
                                </p>
                              </div>

                              {/* Price + CTA */}
                              <div className="flex items-center justify-between">
                                <div className="flex items-center space-x-3">
                                  <span className="text-3xl font-bold text-[#949f7d]">
                                    {danceClass.price ? `$${danceClass.price}` : "Free"}
                                  </span>
                                  <span className="text-white text-sm">/class</span>
                                </div>
                                <Button
                                  className="bg-[#949f7d] hover:bg-[#949f7d]/90 text-white px-6 py-2 rounded-full font-medium shadow-lg hover:shadow-xl transition-all duration-300"
                                  size="sm"
                                >
                                  Book Now
                                </Button>
                              </div>
                            </div>
                          </Link>
                        </Card>
                      </div>
                    )
                  })}
                </div>

                {/* Navigation Controls */}
                <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex items-center space-x-6 bg-white/10 backdrop-blur-md rounded-full px-8 py-4 shadow-xl">
                  {/* Previous Button */}
                  <button
                    onClick={prevSlide}
                    className="w-12 h-12 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center hover:bg-[#949f7d] hover:text-white transition-all duration-300 text-white shadow-lg"
                  >
                    <ChevronLeft className="w-6 h-6" />
                  </button>

                  {/* Dots Indicator */}
                  <div className="flex space-x-2">
                    {danceClasses.map((_, index) => (
                      <button
                        key={index}
                        onClick={() => setCurrentSlide(index)}
                        className={`transition-all duration-300 ${index === currentSlide
                          ? "w-8 h-3 bg-[#949f7d] rounded-full shadow-lg"
                          : "w-3 h-3 bg-white/40 rounded-full hover:bg-white/70"
                          }`}
                      />
                    ))}
                  </div>

                  {/* Next Button */}
                  <button
                    onClick={nextSlide}
                    className="w-12 h-12 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center hover:bg-[#949f7d] hover:text-white transition-all duration-300 text-white shadow-lg"
                  >
                    <ChevronRight className="w-6 h-6" />
                  </button>
                </div>

                {/* Class Counter */}
                <div className="absolute top-8 left-8 bg-white/10 backdrop-blur-md rounded-full px-6 py-3 text-white shadow-xl">
                  <div className="flex items-center space-x-3">
                    <span className="text-sm font-medium opacity-80">Class</span>
                    <div className="flex items-center space-x-1">
                      <span className="text-2xl font-bold">{String(currentSlide + 1).padStart(2, "0")}</span>
                      <span className="text-white/60">/</span>
                      <span className="text-white/80">{String(danceClasses.length).padStart(2, "0")}</span>
                    </div>
                  </div>
                </div>

                {/* Auto-play Indicator */}
                <div className="absolute top-8 right-8 bg-white/10 backdrop-blur-md rounded-full p-3 text-white shadow-xl">
                  <div className="w-8 h-8 relative">
                    <div className="absolute inset-0 border-2 border-white/30 rounded-full"></div>
                    <div
                      className="absolute inset-0 border-2 border-[#949f7d] rounded-full border-t-transparent animate-spin"
                      style={{ animationDuration: "5s" }}
                    ></div>
                    <div className="absolute inset-2 bg-white/20 rounded-full flex items-center justify-center">
                      <div className="w-2 h-2 bg-white rounded-full"></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Decorative Elements */}
        <div className="absolute top-20 right-20 w-32 h-32 bg-[#e5d5bc]/10 rounded-full blur-3xl"></div>
        <div className="absolute bottom-20 left-20 w-48 h-48 bg-[#949f7d]/5 rounded-full blur-3xl"></div>
      </section >

      {/* Coaches Section */}
      < section id="coaches" className="py-20 bg-[#e5d5bc]/10" >
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <span className="text-[#949f7d] font-medium text-lg">Our Team</span>
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mt-2 mb-4">
              Meet Our <span className="text-[#949f7d]">Expert</span> Coaches
            </h2>
            <p className="text-gray-600 max-w-2xl mx-auto text-lg">
              Learn from world-class instructors who are passionate about sharing their expertise and helping you
              achieve your dance goals.
            </p>
          </div>

          <div className="relative">
            <div className="flex items-center justify-center">
              <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-8 items-center">
                {/* Show 5 coaches on desktop, 3 on tablet, 1 on mobile */}
                {coaches.slice(currentCoach, currentCoach + 5).map((coach, index) => {
                  const isCenter = index === 2
                  return (
                    <div
                      key={coach.id}
                      className={`text-center transition-all duration-300 ${isCenter ? "scale-110 z-10" : "scale-90 opacity-70"
                        } ${index > 2 ? "hidden lg:block" : ""} ${index > 0 ? "hidden md:block" : ""}`}
                    >
                      <Link href={`/coaches/${generateSlug(coach.name)}`}>
                        <div className="relative mb-4">
                          <div className="w-32 h-32 mx-auto rounded-full overflow-hidden border-4 border-[#949f7d]/20">
                            <Image
                              src={coach.avatar || "/placeholder.svg"}
                              alt={coach.name}
                              width={128}
                              height={128}
                              className="w-full h-full object-cover"
                            />
                          </div>
                          {isCenter && (
                            <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 bg-[#949f7d] text-white px-3 py-1 rounded-full text-sm">
                              Featured
                            </div>
                          )}
                        </div>
                        <h3 className="font-semibold text-lg text-gray-900 hover:text-[#949f7d] transition-colors">
                          {coach.name}
                        </h3>
                      </Link>
                      <p className="text-[#949f7d] font-medium mb-2">
                        {coach.specialties ? coach.specialties.join(", ") : "Dance Instructor"}
                      </p>
                      {isCenter && <p className="text-gray-600 text-sm">{coach.bio || `Meet ${coach.name}, a passionate dance instructor.`}</p>}
                    </div>
                  )
                })}
              </div>
            </div>

            {/* Navigation Buttons */}
            {coaches.length > 5 && (
              <>
                <button
                  onClick={prevCoach}
                  className="absolute left-0 top-1/2 -translate-y-1/2 bg-white shadow-lg rounded-full p-3 hover:bg-gray-50 transition-all"
                >
                  <ChevronLeft className="w-5 h-5 text-gray-600" />
                </button>
                <button
                  onClick={nextCoach}
                  className="absolute right-0 top-1/2 -translate-y-1/2 bg-white shadow-lg rounded-full p-3 hover:bg-gray-50 transition-all"
                >
                  <ChevronRight className="w-5 h-5 text-gray-600" />
                </button>
              </>
            )}

            {/* Dots Indicator */}
            {coaches.length > 5 && (
              <div className="flex justify-center mt-8 space-x-2">
                {Array.from({ length: Math.ceil(coaches.length / 5) }).map((_, index) => (
                  <button
                    key={index}
                    onClick={() => setCurrentCoach(index * 5)}
                    className={`w-2 h-2 rounded-full transition-all ${Math.floor(currentCoach / 5) === index ? "bg-[#949f7d]" : "bg-gray-300"
                      }`}
                  />
                ))}
              </div>
            )}
          </div>
          <div className="text-center mt-12">
            <Link href="/coaches">
              <Button
                variant="outline"
                className="border-[#949f7d] text-[#949f7d] hover:bg-[#949f7d] hover:text-white px-8 bg-transparent"
              >
                Meet All Our Instructors
              </Button>
            </Link>
          </div>
        </div>
      </section >

      {/* Error Banner */}
      {
        error && (
          <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4">
            <div className="container mx-auto px-4">
              <div className="flex">
                <div className="ml-3">
                  <p className="text-sm text-yellow-700">{error}</p>
                </div>
              </div>
            </div>
          </div>
        )
      }

      {/* Shop Section */}
      {
        products.length > 0 && (
          <section id="shop" className="py-20 bg-white">
            <div className="container mx-auto px-4">
              <div className="text-center mb-16">
                <span className="text-[#949f7d] font-medium text-lg">Shop</span>
                <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mt-2 mb-4">
                  Shop <span className="text-[#949f7d]">Selected</span> Products
                </h2>
                <p className="text-gray-600 max-w-2xl mx-auto text-lg">
                  Discover our curated collection of dance and fitness essentials, from professional equipment to stylish
                  dancewear.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
                {products.map((product) => (
                  <Card key={product.id} className="group hover:shadow-xl transition-all duration-300 border-0 shadow-lg">
                    <Link href={`/shop/${product.slug}`}>
                      <div className="relative overflow-hidden rounded-t-lg">
                        <Image
                          src={product.image || "/placeholder.svg"}
                          alt={product.name}
                          width={300}
                          height={300}
                          className="w-full h-64 object-cover group-hover:scale-105 transition-transform duration-300"
                        />
                        {product.badge && (
                          <div
                            className={`absolute top-4 left-4 px-3 py-1 rounded-full text-sm font-medium ${product.badge === "Sale"
                              ? "bg-red-500 text-white"
                              : product.badge === "New"
                                ? "bg-green-500 text-white"
                                : "bg-[#949f7d] text-white"
                              }`}
                          >
                            {product.badge}
                          </div>
                        )}
                      </div>
                    </Link>
                    <CardContent className="p-6">
                      <h3 className="font-semibold text-lg text-gray-900 mb-2">{product.name}</h3>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-2">
                          <span className="text-2xl font-bold text-[#949f7d]">${product.price}</span>
                          {product.originalPrice && (
                            <span className="text-gray-500 line-through">${product.originalPrice}</span>
                          )}
                        </div>
                        <Link href={`/shop/${product.slug}`}>
                          <Button size="sm" className="bg-[#949f7d] hover:bg-[#949f7d]/90 text-white">
                            View Product
                          </Button>
                        </Link>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              <div className="text-center">
                <Link href="/shop">
                  <Button
                    size="lg"
                    variant="outline"
                    className="border-[#949f7d] text-[#949f7d] hover:bg-[#949f7d] hover:text-white px-8 bg-transparent"
                  >
                    View All Products
                  </Button>
                </Link>
              </div>
            </div>
          </section>
        )
      }

      {/* Events Section */}
      {
        events.length > 0 && (
          <section id="events" className="py-20 bg-[#e5d5bc]/10">
            <div className="container mx-auto px-4">
              <div className="text-center mb-16">
                <span className="text-[#949f7d] font-medium text-lg">Events</span>
                <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mt-2 mb-4">
                  Upcoming <span className="text-[#949f7d]">Events</span>
                </h2>
                <p className="text-gray-600 max-w-2xl mx-auto text-lg">
                  Join our exciting workshops, masterclasses, and special events. Don't miss out on these amazing
                  opportunities to learn and grow.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {events.map((event) => (
                  <Card
                    key={event.id}
                    className="group hover:shadow-xl transition-all duration-300 border-0 shadow-lg overflow-hidden"
                  >
                    <div className="md:flex">
                      <div className="md:w-1/3">
                        <Image
                          src={event.image || "/placeholder.svg"}
                          alt={event.title}
                          width={300}
                          height={200}
                          className="w-full h-48 md:h-full object-cover group-hover:scale-105 transition-transform duration-300"
                        />
                      </div>
                      <CardContent className="md:w-2/3 p-6">
                        <div className="flex items-start justify-between mb-4">
                          <div>
                            <h3 className="font-bold text-xl text-gray-900 mb-2">{event.title}</h3>
                            <div className="flex items-center space-x-4 text-gray-600 mb-3">
                              <div className="flex items-center space-x-1">
                                <Calendar className="w-4 h-4" />
                                <span className="text-sm">{formatDate(event.date)}</span>
                              </div>
                              {event.time && (
                                <div className="flex items-center space-x-1">
                                  <Clock className="w-4 h-4" />
                                  <span className="text-sm">{event.time}</span>
                                </div>
                              )}
                            </div>
                          </div>
                          <div className="text-right">
                            <span className="text-2xl font-bold text-[#949f7d]">
                              {event.price ? `$${event.price}` : "Free"}
                            </span>
                          </div>
                        </div>
                        <p className="text-gray-600 mb-4">{event.description || `Join us for ${event.title}!`}</p>
                        <Button className="bg-[#949f7d] hover:bg-[#949f7d]/90 text-white w-full">Register Now</Button>
                      </CardContent>
                    </div>
                  </Card>
                ))}
              </div>

              <div className="text-center mt-12">
                <Link href="/#events">
                  <Button
                    size="lg"
                    variant="outline"
                    className="border-[#949f7d] text-[#949f7d] hover:bg-[#949f7d] hover:text-white px-8 bg-transparent"
                  >
                    View All Events
                  </Button>
                </Link>
              </div>
            </div>
          </section>
        )
      }

      {/* Blog Section */}
      {
        blogPosts.length > 0 && (
          <section id="blog" className="py-20 bg-white">
            <div className="container mx-auto px-4">
              <div className="text-center mb-16">
                <span className="text-[#949f7d] font-medium text-lg">Blog</span>
                <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mt-2 mb-4">
                  Our <span className="text-[#949f7d]">Blog</span> & News
                </h2>
                <p className="text-gray-600 max-w-2xl mx-auto text-lg">
                  Stay updated with the latest dance trends, health tips, and news from our studio community.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
                {blogPosts.map((post) => (
                  <Card key={post.id} className="group hover:shadow-xl transition-all duration-300 border-0 shadow-lg">
                    <Link href={`/blog/${post.slug}`}>
                      <div className="relative overflow-hidden rounded-t-lg">
                        <Image
                          src={post.image || "/placeholder.svg"}
                          alt={post.title}
                          width={300}
                          height={200}
                          className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                        />
                        {post.category && (
                          <div className="absolute top-4 left-4 bg-[#949f7d] text-white px-3 py-1 rounded-full text-sm font-medium">
                            {post.category}
                          </div>
                        )}
                      </div>
                      <CardContent className="p-6">
                        <div className="text-sm text-gray-500 mb-2">{formatDate(post.publishedAt)}</div>
                        <h3 className="font-bold text-lg text-gray-900 mb-3 line-clamp-2">{post.title}</h3>
                        <p className="text-gray-600 text-sm mb-4 line-clamp-3">
                          {post.excerpt || `Read more about ${post.title}...`}
                        </p>
                        <Button variant="ghost" className="text-[#949f7d] hover:text-[#949f7d]/80 p-0 h-auto font-medium">
                          Read More →
                        </Button>
                      </CardContent>
                    </Link>
                  </Card>
                ))}
              </div>

              <div className="text-center">
                <Link href="/blog">
                  <Button
                    size="lg"
                    variant="outline"
                    className="border-[#949f7d] text-[#949f7d] hover:bg-[#949f7d] hover:text-white px-8 bg-transparent"
                  >
                    View All Posts
                  </Button>
                </Link>
              </div>
            </div>
          </section>
        )
      }

      {/* Contact Section */}
      <section id="contact" className="py-20 bg-[#e5d5bc]/10">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <span className="text-[#949f7d] font-medium text-lg">Contact</span>
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mt-2 mb-4">
              Get In <span className="text-[#949f7d]">Touch</span>
            </h2>
            <p className="text-gray-600 max-w-2xl mx-auto text-lg">
              Ready to start your dance journey? Contact us today to book your first class or learn more about our
              programs.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            <div>
              <h3 className="text-2xl font-bold text-gray-900 mb-6">Send us a message</h3>
              <form className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">First Name</label>
                    <Input
                      placeholder="Your first name"
                      className="border-gray-300 focus:border-[#949f7d] focus:ring-[#949f7d]"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Last Name</label>
                    <Input
                      placeholder="Your last name"
                      className="border-gray-300 focus:border-[#949f7d] focus:ring-[#949f7d]"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Email</label>
                  <Input
                    type="email"
                    placeholder="your.email@example.com"
                    className="border-gray-300 focus:border-[#949f7d] focus:ring-[#949f7d]"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Phone</label>
                  <Input
                    type="tel"
                    placeholder="Your phone number"
                    className="border-gray-300 focus:border-[#949f7d] focus:ring-[#949f7d]"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Message</label>
                  <Textarea
                    placeholder="Tell us about your dance goals and interests..."
                    rows={5}
                    className="border-gray-300 focus:border-[#949f7d] focus:ring-[#949f7d]"
                  />
                </div>
                <Button size="lg" className="bg-[#949f7d] hover:bg-[#949f7d]/90 text-white w-full">
                  Send Message
                </Button>
              </form>
            </div>

            <div>
              <h3 className="text-2xl font-bold text-gray-900 mb-6">Visit our studio</h3>
              <div className="space-y-6">
                <div className="flex items-start space-x-4">
                  <MapPin className="w-6 h-6 text-[#949f7d] mt-1" />
                  <div>
                    <h4 className="font-semibold text-gray-900">Address</h4>
                    <p className="text-gray-600">West bey,Cornish,borj almana,first floor</p>
                  </div>
                </div>
                <div className="flex items-start space-x-4">
                  <Phone className="w-6 h-6 text-[#949f7d] mt-1" />
                  <div>
                    <h4 className="font-semibold text-gray-900">Phone</h4>
                    <p className="text-gray-600">33228254</p>
                  </div>
                </div>
                <div className="flex items-start space-x-4">
                  <Mail className="w-6 h-6 text-[#949f7d] mt-1" />
                  <div>
                    <h4 className="font-semibold text-gray-900">Email</h4>
                    <p className="text-gray-600">info@lumen.com</p>
                  </div>
                </div>
                <div className="flex items-start space-x-4">
                  <Clock className="w-6 h-6 text-[#949f7d] mt-1" />
                  <div>
                    <h4 className="font-semibold text-gray-900">Hours</h4>
                    <div className="text-gray-600">
                      <p>Monday - Friday: 6:00 AM - 10:00 PM</p>
                      <p>Saturday: 8:00 AM - 8:00 PM</p>
                      <p>Sunday: 9:00 AM - 6:00 PM</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-16">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <div className="w-10 h-10 bg-[#949f7d] rounded-full flex items-center justify-center">
                  <span className="text-white font-bold text-lg">L</span>
                </div>
                <span className="text-2xl font-bold text-white">Lumen</span>
              </div>
              <p className="text-gray-400 mb-4">
                Empowering dancers of all levels to express themselves through movement, fitness, and artistic
                excellence.
              </p>
              <div className="flex space-x-4">
                <a href="https://www.facebook.com/lumenstudio" target="_blank" rel="noopener noreferrer">
                  <Facebook className="w-5 h-5 text-gray-400 hover:text-[#949f7d] cursor-pointer transition-colors" />
                </a>
                <a href="https://www.instagram.com/lumenstudio" target="_blank" rel="noopener noreferrer">
                  <Instagram className="w-5 h-5 text-gray-400 hover:text-[#949f7d] cursor-pointer transition-colors" />
                </a>
                <a href="https://www.twitter.com/lumenstudio" target="_blank" rel="noopener noreferrer">
                  <Twitter className="w-5 h-5 text-gray-400 hover:text-[#949f7d] cursor-pointer transition-colors" />
                </a>
                <a href="https://www.youtube.com/lumenstudio" target="_blank" rel="noopener noreferrer">
                  <Youtube className="w-5 h-5 text-gray-400 hover:text-[#949f7d] cursor-pointer transition-colors" />
                </a>
              </div>
            </div>

            <div>
              <h4 className="font-bold text-lg mb-4">Quick Links</h4>
              <ul className="space-y-2">
                <li>
                  <Link href="/" className="text-gray-400 hover:text-[#949f7d] transition-colors">
                    Home
                  </Link>
                </li>
                <li>
                  <Link href="/about" className="text-gray-400 hover:text-[#949f7d] transition-colors">
                    About
                  </Link>
                </li>
                <li>
                  <Link href="#classes" className="text-gray-400 hover:text-[#949f7d] transition-colors">
                    Classes
                  </Link>
                </li>
                <li>
                  <Link href="#coaches" className="text-gray-400 hover:text-[#949f7d] transition-colors">
                    Coaches
                  </Link>
                </li>
                <li>
                  <Link href="/blog" className="text-gray-400 hover:text-[#949f7d] transition-colors">
                    Blog
                  </Link>
                </li>
                <li>
                  <Link href="/contact" className="text-gray-400 hover:text-[#949f7d] transition-colors">
                    Contact
                  </Link>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="font-bold text-lg mb-4">Information</h4>
              <ul className="space-y-2">
                <li>
                  <Link href="#" className="text-gray-400 hover:text-[#949f7d] transition-colors">
                    About Us
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-gray-400 hover:text-[#949f7d] transition-colors">
                    Pricing
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-gray-400 hover:text-[#949f7d] transition-colors">
                    Membership
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-gray-400 hover:text-[#949f7d] transition-colors">
                    Private Lessons
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-gray-400 hover:text-[#949f7d] transition-colors">
                    Gift Cards
                  </Link>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="font-bold text-lg mb-4">Resources</h4>
              <ul className="space-y-2">
                <li>
                  <Link href="#" className="text-gray-400 hover:text-[#949f7d] transition-colors">
                    Class Schedule
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-gray-400 hover:text-[#949f7d] transition-colors">
                    Student Portal
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-gray-400 hover:text-[#949f7d] transition-colors">
                    FAQs
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-gray-400 hover:text-[#949f7d] transition-colors">
                    Contact
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-gray-400 hover:text-[#949f7d] transition-colors">
                    Support
                  </Link>
                </li>
              </ul>
            </div>
          </div>

          <div className="border-t border-gray-800 pt-8">
            <div className="flex flex-col md:flex-row justify-between items-center">
              <p className="text-gray-400 text-sm">© 2024 Lumen Dance Studio. All rights reserved.</p>
              <div className="flex space-x-6 mt-4 md:mt-0">
                <Link href="#" className="text-gray-400 hover:text-[#949f7d] text-sm transition-colors">
                  Privacy Policy
                </Link>
                <Link href="#" className="text-gray-400 hover:text-[#949f7d] text-sm transition-colors">
                  Terms of Service
                </Link>
                <Link href="#" className="text-gray-400 hover:text-[#949f7d] text-sm transition-colors">
                  Cookie Policy
                </Link>
              </div>
            </div>
          </div>
        </div>
      </footer>

      {/* Back to Top Button */}
      {
        showBackToTop && (
          <button
            onClick={scrollToTop}
            className="fixed bottom-8 right-8 z-50 bg-[#949f7d] hover:bg-[#949f7d]/90 text-white p-3 rounded-full shadow-lg transition-all duration-300"
          >
            <ArrowUp className="w-5 h-5" />
          </button>
        )
      }
    </div >
  )
}
