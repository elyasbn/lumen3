"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

export default function ClassesPage() {
  const [items, setItems] = useState<any[]>([])

  useEffect(() => {
    fetch("/api/user/enrollments").then((r) => r.json()).then((d) => setItems(d.items || [])).catch(() => setItems([]))
  }, [])

  return (
    <div className="container mx-auto p-6">
      <Card className="border-0 shadow-sm">
        <CardHeader>
          <CardTitle>Your Classes</CardTitle>
          <CardDescription>Active and past enrollments</CardDescription>
        </CardHeader>
        <CardContent>
          <ul className="space-y-2">
            {items.map((e) => (
              <li key={e.id} className="text-sm">Class #{e.classId} • {e.status}</li>
            ))}
            {!items.length && <p className="text-sm text-muted-foreground">No enrollments yet.</p>}
          </ul>
        </CardContent>
      </Card>
    </div>
  )
}
