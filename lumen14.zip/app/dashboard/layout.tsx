"use client"

import type React from "react"
import Link from "next/link"

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen grid grid-cols-1 md:grid-cols-[260px_1fr]">
      <aside className="border-r bg-white hidden md:block">
        <div className="p-6 border-b">
          <h2 className="text-xl font-semibold">My Dashboard</h2>
          <p className="text-sm text-muted-foreground">Manage your account</p>
        </div>
        <nav className="p-4 space-y-1">
          <DashboardNavLink href="/dashboard">Overview</DashboardNavLink>
          <DashboardNavLink href="/dashboard/workouts">Workouts</DashboardNavLink>
          <DashboardNavLink href="/dashboard/purchases">Purchases</DashboardNavLink>
          <DashboardNavLink href="/dashboard/classes">Classes</DashboardNavLink>
          <DashboardNavLink href="/dashboard/request-workout">Request Workout Plan</DashboardNavLink>
        </nav>
      </aside>
      <main className="bg-gray-50/40">
        {children}
      </main>
    </div>
  )
}

function DashboardNavLink({ href, children }: { href: string; children: React.ReactNode }) {
  return (
    <Link href={href} className="block px-3 py-2 rounded-md text-sm hover:bg-gray-100">
      {children}
    </Link>
  )
}
