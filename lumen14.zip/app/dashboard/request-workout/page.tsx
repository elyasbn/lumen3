"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Alert, AlertDescription } from "@/components/ui/alert"

export default function RequestWorkoutPage() {
  const [goals, setGoals] = useState("")
  const [experience, setExperience] = useState("")
  const [preferences, setPreferences] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState("")
  const [success, setSuccess] = useState("")

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setError("")
    setSuccess("")
    const res = await fetch("/api/user/workout-request", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ goals, experience, preferences }),
    })
    const data = await res.json().catch(() => ({}))
    setIsLoading(false)
    if (!res.ok) {
      setError(data?.message || "Request failed")
      return
    }
    setSuccess("Request submitted successfully")
    setGoals("")
    setExperience("")
    setPreferences("")
  }

  return (
    <div className="container mx-auto p-6">
      <Card className="border-0 shadow-sm">
        <CardHeader>
          <CardTitle>Request a Workout Plan</CardTitle>
          <CardDescription>Tell us your goals and preferences</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={onSubmit} className="space-y-4">
            {error && (
              <Alert variant="destructive"><AlertDescription>{error}</AlertDescription></Alert>
            )}
            {success && (
              <Alert><AlertDescription>{success}</AlertDescription></Alert>
            )}
            <div>
              <Label htmlFor="goals">Goals</Label>
              <Textarea id="goals" value={goals} onChange={(e) => setGoals(e.target.value)} required />
            </div>
            <div>
              <Label htmlFor="experience">Experience</Label>
              <Input id="experience" value={experience} onChange={(e) => setExperience(e.target.value)} placeholder="Beginner / Intermediate / Advanced" required />
            </div>
            <div>
              <Label htmlFor="preferences">Preferences (optional)</Label>
              <Textarea id="preferences" value={preferences} onChange={(e) => setPreferences(e.target.value)} />
            </div>
            <Button type="submit" disabled={isLoading}>{isLoading ? "Submitting..." : "Submit Request"}</Button>
          </form>
        </CardContent>
      </Card>
    </div>
  )
}


