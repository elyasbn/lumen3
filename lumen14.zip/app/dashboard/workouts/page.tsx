"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

export default function WorkoutsPage() {
  const [items, setItems] = useState<any[]>([])

  useEffect(() => {
    fetch("/api/user/workouts").then((r) => r.json()).then((d) => setItems(d.items || [])).catch(() => setItems([]))
  }, [])

  return (
    <div className="container mx-auto p-6">
      <Card className="border-0 shadow-sm">
        <CardHeader>
          <CardTitle>Workout Plans</CardTitle>
          <CardDescription>Your custom plans</CardDescription>
        </CardHeader>
        <CardContent>
          <ul className="space-y-2">
            {items.map((w) => (
              <li key={w.id} className="text-sm">{w.title}</li>
            ))}
            {!items.length && <p className="text-sm text-muted-foreground">No plans yet.</p>}
          </ul>
        </CardContent>
      </Card>
    </div>
  )
}
