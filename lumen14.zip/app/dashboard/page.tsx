"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"

export default function DashboardPage() {
  const [workouts, setWorkouts] = useState<any[]>([])
  const [purchases, setPurchases] = useState<any[]>([])
  const [enrollments, setEnrollments] = useState<any[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    let isMounted = true
    const load = async () => {
      try {
        const empty = { items: [] as any[] }
        const [w, p, e] = await Promise.all([
          fetch("/api/user/workouts").then((r) => r.json()).catch(() => empty),
          fetch("/api/user/purchases").then((r) => r.json()).catch(() => empty),
          fetch("/api/user/enrollments").then((r) => r.json()).catch(() => empty),
        ])
        if (!isMounted) return
        setWorkouts(w?.items || [])
        setPurchases(p?.items || [])
        setEnrollments(e?.items || [])
        setLoading(false)
      } catch {
        if (!isMounted) return
        setWorkouts([])
        setPurchases([])
        setEnrollments([])
        setLoading(false)
      }
    }
    load()
    return () => {
      isMounted = false
    }
  }, [])

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-[#949f7d]"></div>
      </div>
    )
  }

  return (
    <div className="container mx-auto p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Your Dashboard</h1>
          <p className="text-muted-foreground mt-1">Overview of your activity and plans</p>
        </div>
      </div>

      {/* Stats */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card className="border-0 shadow-sm">
          <CardHeader className="pb-2">
            <CardDescription>Total Workout Plans</CardDescription>
            <CardTitle className="text-3xl">{workouts.length}</CardTitle>
          </CardHeader>
          <CardContent className="text-sm text-muted-foreground">Customized for your goals</CardContent>
        </Card>
        <Card className="border-0 shadow-sm">
          <CardHeader className="pb-2">
            <CardDescription>Total Purchases</CardDescription>
            <CardTitle className="text-3xl">{purchases.length}</CardTitle>
          </CardHeader>
          <CardContent className="text-sm text-muted-foreground">Products and memberships</CardContent>
        </Card>
        <Card className="border-0 shadow-sm">
          <CardHeader className="pb-2">
            <CardDescription>Active Classes</CardDescription>
            <CardTitle className="text-3xl">{enrollments.filter((e:any)=>e.status==="active").length}</CardTitle>
          </CardHeader>
          <CardContent className="text-sm text-muted-foreground">Currently enrolled</CardContent>
        </Card>
      </div>

      {/* Content */}
      <div className="grid gap-6 md:grid-cols-3">
        <Card className="md:col-span-1 border-0 shadow-sm">
        <CardHeader>
          <CardTitle>Workout Plans</CardTitle>
          <CardDescription>Your current plans</CardDescription>
        </CardHeader>
        <CardContent>
          <ul className="space-y-2">
            {workouts.map((w: any) => (
              <li key={w.id} className="text-sm">{w.title}</li>
            ))}
            {!workouts.length && <p className="text-sm text-gray-500">No plans yet.</p>}
          </ul>
        </CardContent>
        </Card>

        <Card className="md:col-span-1 border-0 shadow-sm">
        <CardHeader>
          <CardTitle>Purchases</CardTitle>
          <CardDescription>Recent orders</CardDescription>
        </CardHeader>
        <CardContent>
          <ul className="space-y-2">
            {purchases.map((p: any) => (
              <li key={p.id} className="text-sm">#{p.id} • ${p.amount.toFixed(2)}</li>
            ))}
            {!purchases.length && <p className="text-sm text-gray-500">No purchases yet.</p>}
          </ul>
        </CardContent>
        </Card>

        <Card className="md:col-span-1 border-0 shadow-sm">
        <CardHeader>
          <CardTitle>Classes</CardTitle>
          <CardDescription>Your enrollments</CardDescription>
        </CardHeader>
        <CardContent>
          <ul className="space-y-2">
            {enrollments.map((e: any) => (
              <li key={e.id} className="text-sm">Class #{e.classId} • {e.status}</li>
            ))}
            {!enrollments.length && <p className="text-sm text-gray-500">No enrollments yet.</p>}
          </ul>
        </CardContent>
        </Card>
      </div>
    </div>
  )
}
