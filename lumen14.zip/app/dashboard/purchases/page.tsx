"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

export default function PurchasesPage() {
  const [items, setItems] = useState<any[]>([])

  useEffect(() => {
    fetch("/api/user/purchases").then((r) => r.json()).then((d) => setItems(d.items || [])).catch(() => setItems([]))
  }, [])

  return (
    <div className="container mx-auto p-6">
      <Card className="border-0 shadow-sm">
        <CardHeader>
          <CardTitle>Purchases</CardTitle>
          <CardDescription>Order history</CardDescription>
        </CardHeader>
        <CardContent>
          <ul className="space-y-2">
            {items.map((p) => (
              <li key={p.id} className="text-sm">#{p.id} • ${p.amount.toFixed(2)}</li>
            ))}
            {!items.length && <p className="text-sm text-muted-foreground">No purchases yet.</p>}
          </ul>
        </CardContent>
      </Card>
    </div>
  )
}
